import React, { useState } from 'react';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logout } from '../services/authService';
import { 
  MdDashboard, 
  MdInventory, 
  MdHistory, 
  MdReceipt, 
  MdPeople, 
  MdAssessment, 
  MdSettings, 
  MdLogout,
  MdShoppingCart,
  MdTrendingDown,
  MdMenu,
  MdNotifications,
  MdPerson,
  MdClose,
  MdChevronRight,
  MdLayers
} from 'react-icons/md';

import ExpensesPage from '../pages/admin/Expenses/ExpensesPage';
import Login from '../pages/auth/Login';
import Register from '../pages/auth/Register';

// Admin Pages
import AdminDashboard from '../pages/admin/Dashboard/AdminDashboard';
import AddProduct from '../pages/admin/Products/AddProduct';
import ProductList from '../pages/admin/Products/ProductList';
import ReviewBills from '../pages/admin/Bills/ReviewBills';
import StockHistory from '../pages/admin/StockHistory/StockHistory';
import UsersPage from '../pages/admin/Users/UsersPage';
import CategoriesPage from '../pages/admin/Categories/CategoriesPage';
import ReportsPage from '../pages/admin/Reports/ReportsPage';
import SettingsPage from '../pages/admin/Settings/SettingsPage';

// Seller Pages
import SellerDashboard from '../pages/seller/Dashboard/SellerDashboard';
import BillingHistory from '../pages/seller/Bills/BillingHistory';
import Profile from '../pages/seller/Profile/Profile';

const SidebarLink = ({ to, icon: Icon, label, badge, hasSubmenu, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`flex items-center justify-between px-6 py-3 text-[13px] font-bold transition-all duration-200 group ${
        isActive 
          ? 'bg-blue-50 text-blue-700' 
          : 'text-gray-500 hover:text-blue-700 hover:bg-gray-50'
      }`}
    >
      <div className="flex items-center gap-3">
        <Icon size={20} className={`${isActive ? 'text-blue-700' : 'text-gray-400 group-hover:text-blue-700'} transition-colors`} />
        <span>{label}</span>
      </div>
      <div className="flex items-center gap-2">
        {badge && (
          <span className="bg-red-500 text-white px-2 py-0.5 rounded-full text-[9px] font-black min-w-[18px] text-center shadow-lg shadow-red-100">
            {badge}
          </span>
        )}
        {hasSubmenu && (
           <MdChevronRight className={`text-gray-300 transition-transform ${isActive ? 'rotate-90' : 'group-hover:translate-x-1'}`} size={16} />
        )}
      </div>
    </Link>
  );
};

const Layout = ({ children }) => {
  const { user, role } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const closeMenu = () => setIsMobileMenuOpen(false);
  
  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col md:flex-row overflow-hidden">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between px-6 py-5 bg-white border-b border-gray-100 sticky top-0 z-[100] shadow-sm">
        <div className="flex items-center gap-3">
           <div className="w-9 h-9 bg-blue-900 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-100">M</div>
           <span className="text-xl font-black text-blue-900 tracking-tighter uppercase">Marble Pro</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 text-gray-400 hover:text-blue-900 transition-colors">
          <MdMenu size={28} />
        </button>
      </div>

      {/* Sidebar Overlay */}
      <div 
        className={`fixed inset-0 bg-blue-900/40 backdrop-blur-sm z-[110] md:hidden transition-opacity duration-300 ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={closeMenu}
      ></div>

      {/* Sidebar */}
      <aside className={`
        fixed md:sticky top-0 left-0 z-[120] h-screen w-[280px] bg-white border-r border-gray-100 flex flex-col
        transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1)
        ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="p-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-blue-900 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-xl shadow-blue-100">M</div>
             <span className="text-2xl font-black text-blue-900 tracking-tighter uppercase">Marble Pro</span>
          </div>
          <button onClick={closeMenu} className="md:hidden p-2 text-gray-300 hover:text-red-500 transition-colors">
            <MdClose size={24} />
          </button>
        </div>

        {/* User Profile Section */}
        <div className="px-6 mb-8">
           <div className="flex items-center gap-4 p-4 bg-gray-50 border border-gray-100 rounded-3xl group cursor-pointer hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="w-11 h-11 rounded-2xl overflow-hidden border-2 border-white shadow-md shrink-0 transition-transform group-hover:scale-105">
                 <img src={`https://ui-avatars.com/api/?name=${user?.email}&background=00458b&color=fff&bold=true`} alt="user" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                 <p className="text-sm font-black text-gray-900 truncate leading-tight mb-0.5">{user?.email?.split('@')[0]}</p>
                 <div className="flex items-center gap-1.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${role === 'admin' ? 'bg-blue-600' : 'bg-green-500'}`}></div>
                    <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{role}</p>
                 </div>
              </div>
           </div>
        </div>

        <nav className="flex-1 overflow-y-auto custom-scrollbar px-2 space-y-1">
          {role === 'admin' ? (
            <>
              <div className="px-6 py-4 text-[10px] font-black text-gray-300 uppercase tracking-[0.3em] opacity-80">Operations Control</div>
              <SidebarLink to="/admin" icon={MdDashboard} label="Enterprise Overview" onClick={closeMenu} />
              <SidebarLink to="/admin/inventory" icon={MdInventory} label="Global Inventory" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/admin/categories" icon={MdLayers} label="Category Logistics" onClick={closeMenu} />
              <SidebarLink to="/admin/history" icon={MdHistory} label="Stock Movements" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/admin/review-bills" icon={MdReceipt} label="Bill Authorizations" badge="NEW" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/admin/expenses" icon={MdTrendingDown} label="Expense Tracker" hasSubmenu onClick={closeMenu} />
              
              <div className="px-6 py-6 text-[10px] font-black text-gray-300 uppercase tracking-[0.3em] opacity-80">System Management</div>
              <SidebarLink to="/admin/users" icon={MdPeople} label="Personnel Access" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/admin/reports" icon={MdAssessment} label="Analytical Insights" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/admin/settings" icon={MdSettings} label="Global Config" onClick={closeMenu} />
            </>
          ) : (
            <>
              <div className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] opacity-60">Point of Sale</div>
              <SidebarLink to="/seller" icon={MdDashboard} label="Sales Terminal" onClick={closeMenu} />
              <SidebarLink to="/seller/history" icon={MdHistory} label="Transaction History" hasSubmenu onClick={closeMenu} />
              <SidebarLink to="/seller/profile" icon={MdPerson} label="My Terminal Profile" onClick={closeMenu} />
            </>
          )}
        </nav>

        <div className="p-6 border-t border-gray-50">
          <button 
            onClick={() => { logout(); closeMenu(); }}
            className="flex items-center gap-3 w-full px-6 py-4 rounded-2xl text-[13px] font-black text-gray-400 hover:text-red-600 hover:bg-red-50 transition-all duration-300 group"
          >
            <MdLogout size={20} className="group-hover:-translate-x-1 transition-transform" />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto h-screen w-full custom-scrollbar animate-slide-up">
        {children}
      </main>
    </div>
  );
};

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, role } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to={role === 'admin' ? '/admin' : '/seller'} replace />;
  }
  return <Layout>{children}</Layout>;
};

const AppRoutes = () => {
  const { user, role } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      {/* Admin Routes */}
      <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/inventory" element={<ProtectedRoute allowedRoles={['admin']}><ProductList /></ProtectedRoute>} />
      <Route path="/admin/categories" element={<ProtectedRoute allowedRoles={['admin']}><CategoriesPage /></ProtectedRoute>} />
      <Route path="/admin/add-product" element={<ProtectedRoute allowedRoles={['admin']}><AddProduct /></ProtectedRoute>} />
      <Route path="/admin/review-bills" element={<ProtectedRoute allowedRoles={['admin']}><ReviewBills /></ProtectedRoute>} />
      <Route path="/admin/history" element={<ProtectedRoute allowedRoles={['admin']}><StockHistory /></ProtectedRoute>} />
      <Route path="/admin/users" element={<ProtectedRoute allowedRoles={['admin']}><UsersPage /></ProtectedRoute>} />
      <Route path="/admin/reports" element={<ProtectedRoute allowedRoles={['admin']}><ReportsPage /></ProtectedRoute>} />
      <Route path="/admin/settings" element={<ProtectedRoute allowedRoles={['admin']}><SettingsPage /></ProtectedRoute>} />
      <Route path="/admin/expenses" element={<ProtectedRoute allowedRoles={['admin']}><ExpensesPage /></ProtectedRoute>} />
      
      {/* Seller Routes */}
      <Route path="/seller" element={<ProtectedRoute allowedRoles={['seller']}><SellerDashboard /></ProtectedRoute>} />
      <Route path="/seller/history" element={<ProtectedRoute allowedRoles={['seller']}><BillingHistory /></ProtectedRoute>} />
      <Route path="/seller/profile" element={<ProtectedRoute allowedRoles={['seller']}><Profile /></ProtectedRoute>} />
      
      <Route path="/" element={
        !user ? <Navigate to="/login" replace /> :
        role === 'admin' ? <Navigate to="/admin" replace /> : 
        role === 'seller' ? <Navigate to="/seller" replace /> : 
        <Navigate to="/login" replace />
      } />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
