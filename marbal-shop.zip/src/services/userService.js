import {
  collection, addDoc, getDocs, updateDoc,
  doc, serverTimestamp, query, where
} from 'firebase/firestore';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../firebase/config';

// ─── GET ALL USERS ───────────────────────────────────────────
export const getUsers = async () => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (error) {
    throw error;
  }
};

// ─── GET SELLERS ONLY ────────────────────────────────────────
export const getSellers = async () => {
  try {
    const q = query(collection(db, 'users'), where('role', '==', 'seller'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (error) {
    throw error;
  }
};

// ─── CREATE SELLER ACCOUNT ───────────────────────────────────
export const createSeller = async (email, password, name) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    await addDoc(collection(db, 'users'), {
      uid: user.uid,
      email,
      name,
      role: 'seller',
      createdAt: serverTimestamp(),
    });

    return user;
  } catch (error) {
    throw error;
  }
};

// ─── UPDATE USER ─────────────────────────────────────────────
export const updateUser = async (id, data) => {
  try {
    const userRef = doc(db, 'users', id);
    await updateDoc(userRef, data);
  } catch (error) {
    throw error;
  }
};
