import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { collection, getDocs, query, orderBy, where, Timestamp } from 'firebase/firestore';
import { db } from '../firebase/config';

// ─── PROFESSIONAL GST INVOICE GENERATOR ──────────────────────
export const generateInvoice = (bill) => {
  const doc = new jsPDF();
  const brandBlue = [0, 69, 139];
  const accentLight = [240, 247, 255];

  // 1. Header & Branding
  doc.setFillColor(...brandBlue);
  doc.rect(0, 0, 210, 40, 'F');
  
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('MARBLE PRO', 20, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Premium Stone & Inventory Solutions', 20, 32);

  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('GST INVOICE', 190, 25, { align: 'right' });
  
  // 2. Billing Details Grid
  doc.setTextColor(0);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('SOLD BY:', 20, 55);
  doc.setFont('helvetica', 'normal');
  doc.text('Marble Pro Headquarters', 20, 61);
  doc.text('Industrial Estate, Sector 12', 20, 66);
  doc.text('GSTIN: 24AAACM1234F1Z5', 20, 71);

  doc.setFont('helvetica', 'bold');
  doc.text('BILL TO:', 110, 55);
  doc.setFont('helvetica', 'normal');
  doc.text(`Customer: ${bill.customerName || 'Walk-in Customer'}`, 110, 61);
  doc.text(`Contact: ${bill.customerContact || 'N/A'}`, 110, 66);
  doc.text(`Address: ${bill.customerAddress || 'N/A'}`, 110, 71, { maxWidth: 80 });

  // 3. Document Metadata
  doc.setFillColor(...accentLight);
  doc.rect(20, 80, 170, 15, 'F');
  doc.setFont('helvetica', 'bold');
  doc.text(`Invoice #: ${bill.id.slice(0, 10).toUpperCase()}`, 25, 89);
  doc.text(`Date: ${bill.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(bill.createdAt.toDate()) : new Date().toLocaleDateString()}`, 85, 89);
  doc.text(`Payment: ${bill.paymentMode || 'Cash'}`, 145, 89);

  // 4. Items Table
  const tableColumn = ['Description', 'SKU ID', 'Unit Price', 'Qty', 'Total'];
  const tableRows = (bill.items || []).map(item => [
    item.name,
    item.sku || 'N/A',
    `₹${parseFloat(item.price).toLocaleString()}`,
    item.quantity,
    `₹${(item.price * item.quantity).toLocaleString()}`,
  ]);

  // Using the instance method which is safer after side-effect import
  if (typeof doc.autoTable === 'function') {
    doc.autoTable({
      startY: 100,
      head: [tableColumn],
      body: tableRows,
      theme: 'striped',
      headStyles: { fillColor: brandBlue, textColor: 255, fontStyle: 'bold', halign: 'center' },
      columnStyles: {
        0: { cellWidth: 70 },
        2: { halign: 'right' },
        3: { halign: 'center' },
        4: { halign: 'right' },
      },
      styles: { fontSize: 9, cellPadding: 5 },
    });
  }

  // 5. Financial Summary
  const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY + 15 : 150;
  
  doc.setDrawColor(230);
  doc.line(130, finalY, 190, finalY);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Subtotal:', 140, finalY + 10);
  doc.text(`₹${parseFloat(bill.totalAmount).toLocaleString()}`, 185, finalY + 10, { align: 'right' });
  
  doc.text('Tax (0% GST):', 140, finalY + 18);
  doc.text('₹0.00', 185, finalY + 18, { align: 'right' });

  doc.setFillColor(...brandBlue);
  doc.rect(130, finalY + 25, 66, 12, 'F');
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255);
  doc.text(`NET TOTAL: ₹${parseFloat(bill.totalAmount).toLocaleString()}`, 135, finalY + 33);

  // 6. Terms & Footer
  doc.setTextColor(150);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'italic');
  doc.text('Terms & Conditions:', 20, 260);
  doc.text('1. Goods once sold will not be taken back.', 20, 265);
  doc.text('2. All disputes are subject to local jurisdiction.', 20, 270);
  
  doc.setFont('helvetica', 'normal');
  doc.text('This is a digitally generated invoice. No signature required.', 105, 285, { align: 'center' });
  doc.setTextColor(...brandBlue);
  doc.setFont('helvetica', 'bold');
  doc.text('THANK YOU FOR YOUR BUSINESS!', 105, 290, { align: 'center' });

  const safeName = (bill.customerName || 'Walk-in_Customer').replace(/\s+/g, '_');
  doc.save(`GST_Invoice_${safeName}_${bill.id.slice(0, 6)}.pdf`);
};

// ─── PREMIUM WHATSAPP BILLING ────────────────────────────────
export const shareOnWhatsApp = (bill) => {
  const line = '------------------------------------------';
  const header = `*MARBLE PRO INVOICE*`;
  const customer = `*Customer:* ${bill.customerName}`;
  const invId = `*Bill ID:* #${bill.id.slice(0, 8).toUpperCase()}`;
  const date = `*Date:* ${new Date().toLocaleDateString()}`;
  
  const itemsHead = `*ITEMIZED BREAKDOWN:*`;
  const itemsList = bill.items.map(i => `- ${i.name} (x${i.quantity}) - ₹${(i.price * i.quantity).toLocaleString()}`).join('%0A');
  
  const total = `*TOTAL AMOUNT: ₹${bill.totalAmount.toLocaleString()}*`;
  const payment = `*Payment Mode:* ${bill.paymentMode}`;
  const footer = `_Thank you for choosing Marble Pro!_`;

  const message = `${header}%0A${line}%0A${customer}%0A${invId}%0A${date}%0A${line}%0A${itemsHead}%0A${itemsList}%0A${line}%0A${total}%0A${payment}%0A%0A${footer}`;
  
  const phone = bill.customerContact ? bill.customerContact.replace(/\D/g, '') : '';
  const url = `https://wa.me/${phone}?text=${message}`;
  window.open(url, '_blank');
};

// ─── MASTER DOWNLOAD HANDLERS ────────────────────────────────
export const downloadInventoryReport = async (format = 'pdf') => {
  try {
    const snapshot = await getDocs(collection(db, 'products'));
    const products = snapshot.docs.map(d => d.data());
    
    if (format === 'pdf') {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('INVENTORY MASTER REPORT', 105, 15, { align: 'center' });
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 24);

      if (typeof doc.autoTable === 'function') {
        doc.autoTable({
          startY: 30,
          head: [['Product', 'SKU', 'Category', 'Price', 'Stock', 'Status']],
          body: products.map(p => [
            p.name, p.sku || 'N/A', p.category || 'N/A',
            `₹${p.price}`, p.quantity,
            p.quantity < 10 ? 'LOW' : 'OK'
          ]),
          theme: 'grid',
          headStyles: { fillColor: [0, 69, 139] },
        });
      }
      doc.save('Inventory_Report.pdf');
    } else {
      const data = products.map(p => ({
        Name: p.name, SKU: p.sku || 'N/A', Category: p.category || 'N/A',
        Price: p.price, Stock: p.quantity, Status: p.quantity < 10 ? 'LOW STOCK' : 'OK'
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Inventory');
      XLSX.writeFile(wb, 'Inventory_Report.xlsx');
    }
  } catch (error) {
    console.error(error);
  }
};

export const downloadBillingReport = async (format = 'pdf') => {
  try {
    const q = query(collection(db, 'bills'), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const bills = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

    if (format === 'pdf') {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('REVENUE & BILLING LEDGER', 105, 15, { align: 'center' });
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 24);

      if (typeof doc.autoTable === 'function') {
        doc.autoTable({
          startY: 30,
          head: [['Bill ID', 'Seller', 'Category', 'Amount', 'Status', 'Date']],
          body: bills.map(b => [
            b.id.slice(0, 8), b.sellerName || 'N/A', b.category || 'General',
            `₹${b.totalAmount}`, b.status,
            b.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(b.createdAt.toDate()) : 'N/A'
          ]),
          theme: 'grid',
          headStyles: { fillColor: [0, 69, 139] },
        });
      }
      doc.save('Billing_Report.pdf');
    } else {
      const data = bills.map(b => ({
        'Bill ID': b.id.slice(0, 8), Seller: b.sellerName || 'N/A',
        Category: b.category || 'General', Amount: b.totalAmount,
        Status: b.status,
        Date: b.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(b.createdAt.toDate()) : 'N/A'
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Bills');
      XLSX.writeFile(wb, 'Billing_Report.xlsx');
    }
  } catch (error) {
    console.error(error);
  }
};

// ─── DYNAMIC BILLING REPORTS (Daily, Weekly, etc) ──────────────
export const getReportData = async (type = 'daily') => {
  const now = new Date();
  let startTime;

  switch(type) {
    case 'daily':
      startTime = new Date(now.setHours(0, 0, 0, 0));
      break;
    case 'weekly':
      startTime = new Date(now.setDate(now.getDate() - 7));
      break;
    case 'monthly':
      startTime = new Date(now.setMonth(now.getMonth() - 1));
      break;
    case 'yearly':
      startTime = new Date(now.setFullYear(now.getFullYear() - 1));
      break;
    default:
      startTime = new Date(now.setHours(0, 0, 0, 0));
  }

  const q = query(
    collection(db, 'bills'),
    where('createdAt', '>=', Timestamp.fromDate(startTime)),
    orderBy('createdAt', 'desc')
  );

  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
};
