import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, getDoc, serverTimestamp, query, where } from 'firebase/firestore';
import { db } from '../firebase/config';
import { v4 as uuidv4 } from 'uuid';

const productsCollection = collection(db, 'products');

export const addProduct = async (productData) => {
  try {
    // Auto-generate SKU if not provided
    const sku = productData.sku || `MRB-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    const docData = {
      ...productData,
      sku,
      createdAt: serverTimestamp(),
    };

    const docRef = await addDoc(productsCollection, docData);
    return { id: docRef.id, ...docData };
  } catch (error) {
    throw error;
  }
};

export const getProducts = async () => {
  try {
    const querySnapshot = await getDocs(productsCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    throw error;
  }
};

export const getProductBySKU = async (sku) => {
  try {
    const q = query(productsCollection, where('sku', '==', sku));
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return { id: snap.docs[0].id, ...snap.docs[0].data() };
  } catch (error) {
    throw error;
  }
};

export const updateProduct = async (id, updateData) => {
  try {
    const productRef = doc(db, 'products', id);
    await updateDoc(productRef, updateData);
  } catch (error) {
    throw error;
  }
};

export const deleteProduct = async (id) => {
  try {
    const productRef = doc(db, 'products', id);
    await deleteDoc(productRef);
  } catch (error) {
    throw error;
  }
};
