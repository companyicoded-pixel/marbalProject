import { 
  collection, addDoc, getDocs, updateDoc, deleteDoc, 
  doc, serverTimestamp, query, orderBy 
} from 'firebase/firestore';
import { db } from '../firebase/config';

const expensesCollection = collection(db, 'expenses');

export const addExpense = async (expenseData) => {
  try {
    const docRef = await addDoc(expensesCollection, {
      ...expenseData,
      createdAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    throw error;
  }
};

export const getExpenses = async () => {
  try {
    const q = query(expensesCollection, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (error) {
    throw error;
  }
};

export const deleteExpense = async (id) => {
  try {
    await deleteDoc(doc(db, 'expenses', id));
  } catch (error) {
    throw error;
  }
};
