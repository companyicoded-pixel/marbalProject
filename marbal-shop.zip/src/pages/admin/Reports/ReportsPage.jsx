import React, { useState, useEffect } from 'react';
import { getReportData, downloadBillingReport } from '../../../services/reportService';
import { 
  MdAssessment, MdFileDownload, MdTrendingUp, 
  MdAccountBalance, MdTimeline, MdToday 
} from 'react-icons/md';

const ReportStat = ({ label, value, sub, color }) => (
  <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm flex flex-col gap-4">
    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{label}</p>
    <div>
       <p className={`text-3xl font-black tracking-tighter ${color}`}>{value}</p>
       <p className="text-[11px] text-gray-400 font-bold mt-1">{sub}</p>
    </div>
  </div>
);

const ReportsPage = () => {
  const [reportType, setReportType] = useState('daily');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const res = await getReportData(reportType);
      setData(res);
      setLoading(false);
    };
    fetch();
  }, [reportType]);

  const totalRevenue = data.filter(b => b.status === 'approved').reduce((sum, b) => sum + b.totalAmount, 0);
  const pendingAmount = data.filter(b => b.status === 'pending').reduce((sum, b) => sum + b.totalAmount, 0);
  const totalBills = data.length;

  return (
    <div className="p-6 md:p-12 max-w-[1600px] mx-auto space-y-12">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
           <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl shadow-sm"><MdAssessment size={24} /></div>
              <h1 className="text-4xl font-black text-blue-900 tracking-tight">Financial Intelligence</h1>
           </div>
           <p className="text-base text-gray-500 max-w-xl font-medium">Aggregated settlement data and revenue liquidity analysis across temporal benchmarks.</p>
        </div>

        <div className="flex p-2 bg-white border border-gray-100 rounded-2xl shadow-sm">
           {['daily', 'weekly', 'monthly', 'yearly'].map((t) => (
             <button
               key={t}
               onClick={() => setReportType(t)}
               className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                 reportType === t ? 'bg-blue-900 text-white shadow-lg' : 'text-gray-400 hover:text-blue-900'
               }`}
             >
               {t}
             </button>
           ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <ReportStat label="Temporal Revenue" value={`₹${totalRevenue.toLocaleString()}`} sub={`Approved settlements in ${reportType} window`} color="text-green-600" />
        <ReportStat label="Pipeline Volume" value={`₹${pendingAmount.toLocaleString()}`} sub="Pending authorizations" color="text-orange-500" />
        <ReportStat label="Transaction Count" value={totalBills} sub="Total generated invoices" color="text-blue-900" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
        <div className="bg-white rounded-[40px] border border-gray-100 p-10 space-y-10">
           <div className="flex justify-between items-center">
              <h3 className="text-xl font-black text-gray-900 flex items-center gap-3">
                 <MdTimeline className="text-blue-600" /> Settlement Distribution
              </h3>
              <button onClick={() => downloadBillingReport('pdf')} className="flex items-center gap-2 text-xs font-black text-blue-600 uppercase tracking-widest hover:underline">
                 <MdFileDownload size={18} /> Export Audit
              </button>
           </div>

           <div className="space-y-6">
              {data.slice(0, 5).map((bill, idx) => (
                <div key={bill.id} className="relative">
                   <div className="flex justify-between text-xs font-bold text-gray-400 mb-2 uppercase tracking-widest">
                      <span>{bill.customerName || 'Walk-in'}</span>
                      <span>₹{bill.totalAmount.toLocaleString()}</span>
                   </div>
                   <div className="h-3 bg-gray-50 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-1000 ${
                          bill.status === 'approved' ? 'bg-green-500' : 'bg-orange-400'
                        }`} 
                        style={{ width: `${(bill.totalAmount / (totalRevenue || 1)) * 100}%` }}
                      ></div>
                   </div>
                </div>
              ))}
              {data.length === 0 && (
                <div className="py-20 text-center bg-gray-50 rounded-3xl">
                   <p className="text-[10px] font-black text-gray-300 uppercase tracking-[0.3em]">Temporal window empty</p>
                </div>
              )}
           </div>
        </div>

        <div className="bg-blue-900 rounded-[48px] p-10 text-white relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32 transition-transform group-hover:scale-110"></div>
           <div className="relative z-10 h-full flex flex-col justify-between">
              <div>
                 <div className="w-16 h-16 bg-white/10 rounded-3xl flex items-center justify-center mb-8"><MdAccountBalance size={32} /></div>
                 <h3 className="text-3xl font-black tracking-tighter mb-4">Liquidity Forecast</h3>
                 <p className="text-blue-100/60 text-sm font-medium leading-relaxed max-w-xs">Based on current transaction volume, your terminal efficiency is optimized for the next fiscal cycle.</p>
              </div>
              
              <div className="mt-12 flex gap-4">
                 <button className="flex-1 bg-white text-blue-900 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-50 transition-all">Audit Terminal</button>
                 <button className="px-6 border-2 border-white/20 rounded-2xl hover:bg-white/10 transition-all"><MdTrendingUp size={20} /></button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;
