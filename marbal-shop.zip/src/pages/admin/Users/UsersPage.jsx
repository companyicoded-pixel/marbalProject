import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdPersonAdd, MdShield, MdBadge, MdDelete } from 'react-icons/md';
import toast from 'react-hot-toast';

const UsersPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUsers(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="p-8 lg:p-12 max-w-6xl mx-auto h-screen overflow-y-auto custom-scrollbar">
      <div className="flex justify-between items-end mb-12">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tighter">Staff Accounts</h1>
          <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mt-1">Authorized System Access</p>
        </div>
        <button className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-200 hover:bg-slate-800 transition active:scale-95">
           Provision New Account
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {users.map(user => (
          <div key={user.id} className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 group relative">
            <div className="flex items-center gap-5 mb-6">
              <div className={`w-14 h-14 rounded-[20px] flex items-center justify-center text-xl font-black ${
                user.role === 'admin' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-slate-100 text-slate-600'
              }`}>
                {user.email?.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="font-black text-slate-900 leading-tight">{user.name || user.email?.split('@')[0]}</h3>
                <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mt-1">{user.role}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-slate-50/50 rounded-xl border border-slate-50">
                <MdBadge className="text-slate-400" />
                <span className="text-[10px] font-bold text-slate-500 truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 p-3 bg-slate-50/50 rounded-xl border border-slate-50">
                <MdShield className="text-slate-400" />
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">
                  {user.role === 'admin' ? 'Privileged Access' : 'Operational Access'}
                </span>
              </div>
            </div>

            <button className="absolute top-6 right-6 p-2 text-slate-200 hover:text-red-500 transition opacity-0 group-hover:opacity-100">
               <MdDelete size={18} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UsersPage;
