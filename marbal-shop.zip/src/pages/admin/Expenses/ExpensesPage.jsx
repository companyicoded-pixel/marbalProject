import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { addExpense, deleteExpense } from '../../../services/expenseService';
import toast from 'react-hot-toast';
import { MdAdd, MdDelete, MdReceiptLong, MdTrendingDown } from 'react-icons/md';

const ExpensesPage = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ title: '', amount: '', category: 'Utility' });

  useEffect(() => {
    const q = query(collection(db, 'expenses'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setExpenses(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addExpense({ ...formData, amount: parseFloat(formData.amount) });
      toast.success('Expense recorded');
      setShowModal(false);
      setFormData({ title: '', amount: '', category: 'Utility' });
    } catch {
      toast.error('Failed to save');
    }
  };

  const totalExpenses = expenses.reduce((sum, ex) => sum + (ex.amount || 0), 0);

  if (loading) return <div className="p-8">Loading...</div>;

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Shop Expenses</h1>
          <p className="text-sm text-gray-400 font-bold mt-1 uppercase tracking-widest">Track your business costs</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-red-500 text-white px-6 py-3 rounded-2xl font-black shadow-lg shadow-red-100 hover:bg-red-600 transition flex items-center gap-2"
        >
          <MdAdd size={24} /> Record Expense
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm flex items-center gap-6">
          <div className="p-4 bg-red-50 text-red-500 rounded-2xl"><MdTrendingDown size={32} /></div>
          <div>
            <p className="text-xs font-black uppercase text-gray-400 tracking-widest">Total Outflow</p>
            <p className="text-4xl font-black text-gray-900">₹{totalExpenses.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm flex items-center gap-6">
          <div className="p-4 bg-gray-50 text-gray-500 rounded-2xl"><MdReceiptLong size={32} /></div>
          <div>
            <p className="text-xs font-black uppercase text-gray-400 tracking-widest">Entries</p>
            <p className="text-4xl font-black text-gray-900">{expenses.length}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50/50 border-b border-gray-50">
              <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Description</th>
              <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Category</th>
              <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Amount</th>
              <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {expenses.map(ex => (
              <tr key={ex.id} className="hover:bg-gray-50/60 transition group">
                <td className="px-8 py-5 font-bold text-gray-800">{ex.title}</td>
                <td className="px-8 py-5">
                  <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-[10px] font-black uppercase">
                    {ex.category}
                  </span>
                </td>
                <td className="px-8 py-5 font-black text-red-500">₹{ex.amount.toLocaleString()}</td>
                <td className="px-8 py-5 text-right">
                  <button 
                    onClick={() => deleteExpense(ex.id)}
                    className="p-2 text-gray-300 hover:text-red-500 transition opacity-0 group-hover:opacity-100"
                  >
                    <MdDelete size={20} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-[32px] p-8 shadow-2xl">
            <h2 className="text-2xl font-black text-gray-900 mb-6">New Expense</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">Description</label>
                <input 
                  type="text" required
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-red-500 outline-none font-bold"
                  value={formData.title}
                  onChange={e => setFormData({...formData, title: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">Amount (₹)</label>
                  <input 
                    type="number" required
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-red-500 outline-none font-bold"
                    value={formData.amount}
                    onChange={e => setFormData({...formData, amount: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">Category</label>
                  <select 
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:ring-2 focus:ring-red-500 outline-none font-bold"
                    value={formData.category}
                    onChange={e => setFormData({...formData, category: e.target.value})}
                  >
                    <option>Utility</option>
                    <option>Salary</option>
                    <option>Rent</option>
                    <option>Transport</option>
                    <option>Others</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-4 font-black text-gray-400 hover:text-gray-600">Cancel</button>
                <button type="submit" className="flex-[2] py-4 bg-red-500 text-white rounded-2xl font-black shadow-lg shadow-red-100 hover:bg-red-600 transition">Save Entry</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpensesPage;
