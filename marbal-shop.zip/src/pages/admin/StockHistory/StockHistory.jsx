import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdHistory, MdSwapHoriz, MdTrendingUp, MdTrendingDown } from 'react-icons/md';

const StockHistory = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'stockHistory'), orderBy('createdAt', 'desc'), limit(100));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setLogs(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      <div className="px-10 py-10 search-container shrink-0">
        <h1 className="text-2xl font-black text-blue-900 mb-2">Inventory Audit Logs</h1>
        <p className="text-sm text-gray-500 mb-8">Real-time tracking of marble stock movements across all warehouses.</p>
        
        <div className="flex gap-4">
           <div className="bg-white px-6 py-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
              <div className="p-2 bg-green-50 text-green-600 rounded-lg"><MdTrendingUp size={24} /></div>
              <div>
                 <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Total Inward</p>
                 <p className="text-xl font-black text-gray-900">{logs.filter(l => l.type === 'IN').length}</p>
              </div>
           </div>
           <div className="bg-white px-6 py-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
              <div className="p-2 bg-red-50 text-red-500 rounded-lg"><MdTrendingDown size={24} /></div>
              <div>
                 <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Total Outward</p>
                 <p className="text-xl font-black text-gray-900">{logs.filter(l => l.type === 'OUT').length}</p>
              </div>
           </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Movement Type</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Product Details</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Qty Change</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Operator</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-sm">
              {logs.map(log => (
                <tr key={log.id} className="hover:bg-gray-50/50 transition">
                  <td className="px-8 py-5">
                    <div className={`flex items-center gap-2 font-black text-[10px] uppercase tracking-widest ${
                      log.type === 'IN' ? 'text-green-600' : 'text-red-500'
                    }`}>
                      {log.type === 'IN' ? <MdTrendingUp size={18} /> : <MdTrendingDown size={18} />}
                      {log.type === 'IN' ? 'Stock Added' : 'Stock Sale'}
                    </div>
                  </td>
                  <td className="px-8 py-5 font-bold text-gray-800">{log.productName}</td>
                  <td className="px-8 py-5 text-center font-black text-gray-900">
                    <span className={log.type === 'IN' ? 'text-green-600' : 'text-red-500'}>
                      {log.type === 'IN' ? '+' : '-'}{log.quantity}
                    </span>
                  </td>
                  <td className="px-8 py-5 font-medium text-gray-500">{log.updatedBy}</td>
                  <td className="px-8 py-5 text-right text-[10px] font-bold text-gray-400">
                    {log.createdAt?.toDate().toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {logs.length === 0 && <div className="py-20 text-center text-gray-400 uppercase text-[10px] font-black tracking-widest">No history recorded</div>}
        </div>
      </div>
    </div>
  );
};

export default StockHistory;
