import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { Link } from 'react-router-dom';
import {
  MdInventory, MdPendingActions, MdTrendingUp,
  MdWarning, MdArrowForward, MdTrendingDown
} from 'react-icons/md';

const StatCard = ({ icon: Icon, label, value, color, sub, to }) => (
  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col gap-4 hover:shadow-md transition-all group">
    <div className="flex items-center justify-between">
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon size={22} />
      </div>
      {to && <Link to={to} className="text-gray-300 hover:text-blue-600 transition"><MdArrowForward size={20} /></Link>}
    </div>
    <div>
      <p className="text-[11px] font-bold uppercase text-gray-400 tracking-wider">{label}</p>
      <p className="text-2xl font-black text-gray-900 mt-1 tracking-tight">{value}</p>
      {sub && <p className="text-[10px] text-gray-400 font-medium mt-1">{sub}</p>}
    </div>
  </div>
);

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    products: 0, pending: 0, revenue: 0, lowStock: 0, expenses: 0
  });
  const [recentBills, setRecentBills] = useState([]);

  useEffect(() => {
    const unsubBills = onSnapshot(collection(db, 'bills'), (snapshot) => {
      const all = snapshot.docs.map(d => d.data());
      setStats(prev => ({
        ...prev,
        pending: all.filter(b => b.status === 'pending').length,
        revenue: all.filter(b => b.status === 'approved').reduce((s, b) => s + (b.totalAmount || 0), 0)
      }));
    });

    const unsubExpenses = onSnapshot(collection(db, 'expenses'), (snapshot) => {
      const total = snapshot.docs.reduce((sum, doc) => sum + (doc.data().amount || 0), 0);
      setStats(prev => ({ ...prev, expenses: total }));
    });

    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const prods = snapshot.docs.map(d => d.data());
      setStats(prev => ({
        ...prev,
        products: prods.length,
        lowStock: prods.filter(p => (p.quantity || 0) < 10).length
      }));
    });

    const q = query(collection(db, 'bills'), orderBy('createdAt', 'desc'), limit(5));
    const unsubRecent = onSnapshot(q, (snap) => {
      setRecentBills(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => { unsubBills(); unsubExpenses(); unsubProducts(); unsubRecent(); };
  }, []);

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto space-y-10 h-screen overflow-y-auto custom-scrollbar">
      {/* Search Style Header */}
      <div className="search-container -mx-6 md:-mx-10 -mt-6 md:-mt-10 px-6 md:px-10 py-10 mb-8 shrink-0">
        <h1 className="text-2xl font-black text-blue-900 mb-2">Executive Overview</h1>
        <p className="text-sm text-gray-500 max-w-2xl">
          Real-time analysis of your marble enterprise terminals and stock liquidity.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon={MdTrendingUp} label="Total Revenue" value={`₹${stats.revenue.toLocaleString()}`} color="bg-green-50 text-green-600" to="/admin/reports" />
        <StatCard icon={MdTrendingDown} label="Total Expenses" value={`₹${stats.expenses.toLocaleString()}`} color="bg-red-50 text-red-500" to="/admin/expenses" />
        <StatCard icon={MdPendingActions} label="Pending Bills" value={stats.pending} color="bg-orange-50 text-orange-500" sub="Awaiting Authorization" to="/admin/review-bills" />
        <StatCard icon={MdWarning} label="Low Stock" value={stats.lowStock} color="bg-red-50 text-red-600" sub="Items needing restock" to="/admin/inventory" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h2 className="text-lg font-bold text-gray-900">Recent Activity</h2>
            <Link to="/admin/review-bills" className="text-xs font-bold text-blue-600 hover:underline">View All</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50/50">
                  <th className="px-8 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Bill Ref</th>
                  <th className="px-8 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                  <th className="px-8 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {recentBills.map(bill => (
                  <tr key={bill.id} className="hover:bg-gray-50/50 transition duration-150">
                    <td className="px-8 py-5 font-mono text-[10px] font-bold text-gray-400">#{bill.id.slice(0, 10).toUpperCase()}</td>
                    <td className="px-8 py-5">
                      <span className={`px-2.5 py-1 rounded text-[9px] font-black uppercase tracking-widest ${bill.status === 'approved' ? 'bg-green-100 text-green-700' :
                          bill.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'
                        }`}>{bill.status}</span>
                    </td>
                    <td className="px-8 py-5 text-right font-black text-gray-900">₹{bill.totalAmount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-blue-900 rounded-2xl p-8 text-white flex flex-col justify-between shadow-xl shadow-blue-100">
          <div>
            <h3 className="text-xl font-black leading-tight tracking-tight mb-4">Inventory Liquidity</h3>
            <p className="text-blue-100 text-sm font-medium opacity-70 leading-relaxed">
              Your stock health index is performing at {Math.round((stats.products / 100) * 100)}% efficiency based on target benchmarks.
            </p>
          </div>
          <div className="mt-10">
            <div className="flex justify-between items-end mb-3">
              <span className="text-4xl font-black tracking-tighter">{stats.products}</span>
              <span className="text-[10px] font-bold uppercase tracking-widest opacity-50">Total SKUs</span>
            </div>
            <div className="h-2.5 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-white rounded-full" style={{ width: '70%' }}></div>
            </div>
            <div className="mt-12 flex gap-4">
              <Link to="/admin/review-bills" className="flex-1 bg-white text-blue-900 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-50 transition-all text-center flex items-center justify-center">Audit Terminal</Link>
              <Link to="/admin/reports" className="px-6 border-2 border-white/20 rounded-2xl hover:bg-white/10 transition-all text-white flex items-center justify-center"><MdTrendingUp size={20} /></Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
