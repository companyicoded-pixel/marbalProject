import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { approveBill, rejectBill, BILL_CATEGORIES } from '../../../services/billService';
import { generateInvoice, shareOnWhatsApp } from '../../../services/reportService';
import toast from 'react-hot-toast';
import { 
  MdCheck, MdClose, MdVisibility, MdFilterList, 
  MdSearch, MdPerson, MdPhone, MdShare 
} from 'react-icons/md';

const ReviewBills = () => {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'bills'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setBills(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleApprove = async (bill) => {
    try {
      await approveBill(bill.id, bill.items, 'Admin');
      toast.success('Bill Approved & Stock Updated');
      generateInvoice(bill);
    } catch { toast.error('Approval failed'); }
  };

  const handleReject = async (id) => {
    const note = window.prompt('Enter rejection reason:');
    if (note === null) return;
    try {
      await rejectBill(id, 'Admin', note);
      toast.success('Bill Rejected');
    } catch { toast.error('Rejection failed'); }
  };

  const filtered = bills.filter(b => 
    (filter === 'all' || b.status === filter) && 
    (categoryFilter === 'All' || b.category === categoryFilter) &&
    (b.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
     b.customerContact?.includes(searchTerm))
  );

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      <div className="px-6 md:px-12 py-10 md:py-16 search-container shrink-0">
        <h1 className="text-3xl font-black text-blue-900 tracking-tight mb-3">Billing & Authorization Center</h1>
        <p className="text-base text-gray-500 mb-10 max-w-2xl font-medium">Audit transaction logs, authorize stock movements, and synchronize financial settlements.</p>

        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center max-w-6xl">
           <div className="flex-1 flex flex-wrap gap-4 bg-white p-3 rounded-3xl shadow-xl shadow-blue-100/50 border border-gray-100 items-center w-full">
              <div className="flex-1 flex items-center gap-4 px-6 py-3 border-r border-gray-50 min-w-[200px]">
                <MdSearch className="text-gray-400" size={24} />
                <input 
                  type="text"
                  placeholder="Search by Customer Name or Contact..."
                  className="w-full text-sm font-bold outline-none bg-transparent"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex items-center gap-4 px-6 py-3 border-r border-gray-50">
                <MdFilterList className="text-gray-400" size={20} />
                <select 
                  className="text-sm font-black text-blue-900 uppercase tracking-widest outline-none bg-transparent cursor-pointer"
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                >
                  <option value="pending">Pending</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                  <option value="all">All</option>
                </select>
              </div>

              <select 
                className="px-6 py-3 text-sm font-black text-gray-600 outline-none bg-transparent cursor-pointer"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="All">All Sectors</option>
                {BILL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
           </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-12 custom-scrollbar">
        <div className="max-w-7xl mx-auto space-y-6">
          {filtered.map(bill => (
            <div key={bill.id} className="bg-white rounded-[40px] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden group">
               <div className="p-10 flex flex-col lg:flex-row gap-10">
                  <div className="lg:w-1/4 space-y-4">
                     <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-50 text-gray-400 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase">#{bill.id.slice(0, 2)}</div>
                        <div>
                           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Reference ID</p>
                           <p className="text-sm font-black text-gray-900 font-mono tracking-tighter uppercase">{bill.id.slice(0, 14)}</p>
                        </div>
                     </div>
                     <div className={`px-4 py-2 rounded-2xl inline-flex items-center gap-2 ${
                       bill.status === 'approved' ? 'bg-green-50 text-green-600' :
                       bill.status === 'pending' ? 'bg-orange-50 text-orange-500' : 'bg-red-50 text-red-600'
                     }`}>
                        <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                          bill.status === 'approved' ? 'bg-green-500' :
                          bill.status === 'pending' ? 'bg-orange-500' : 'bg-red-500'
                        }`}></div>
                        <span className="text-[10px] font-black uppercase tracking-widest">{bill.status}</span>
                     </div>
                  </div>

                  <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-8 border-x border-gray-50 px-0 lg:px-10">
                     <div className="space-y-4">
                        <div className="flex items-center gap-3">
                           <MdPerson className="text-blue-600" size={20} />
                           <div>
                              <p className="text-sm font-black text-gray-900">{bill.customerName}</p>
                              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{bill.customerContact || 'No Contact Data'}</p>
                           </div>
                        </div>
                        <p className="text-xs text-gray-400 font-medium leading-relaxed italic">"{bill.customerAddress || 'No shipping address provided'}"</p>
                     </div>
                     <div className="space-y-4">
                        <div className="flex justify-between items-center">
                           <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Settlement</span>
                           <span className="text-sm font-black text-blue-900 uppercase tracking-widest">{bill.paymentMode || 'Cash'}</span>
                        </div>
                        <div className="flex justify-between items-center">
                           <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Date</span>
                           <span className="text-sm font-black text-gray-600">{bill.createdAt?.toDate().toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between items-center">
                           <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Staff</span>
                           <span className="text-sm font-black text-gray-600">{bill.sellerName}</span>
                        </div>
                     </div>
                  </div>

                  <div className="lg:w-1/4 flex flex-col justify-between items-end gap-6">
                     <div className="text-right">
                        <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mb-1">Settlement Amount</p>
                        <p className="text-4xl font-black text-blue-900 tracking-tighter leading-none">₹{bill.totalAmount.toLocaleString()}</p>
                     </div>
                     
                     <div className="flex gap-3">
                        {bill.status === 'pending' ? (
                          <>
                            <button onClick={() => handleApprove(bill)} className="p-4 bg-green-50 text-green-600 rounded-2xl hover:bg-green-600 hover:text-white transition shadow-sm active:scale-95"><MdCheck size={24} /></button>
                            <button onClick={() => handleReject(bill.id)} className="p-4 bg-red-50 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition shadow-sm active:scale-95"><MdClose size={24} /></button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => generateInvoice(bill)} className="p-4 bg-blue-50 text-blue-600 rounded-2xl hover:bg-blue-600 hover:text-white transition shadow-sm active:scale-95"><MdVisibility size={24} /></button>
                            {bill.customerContact && (
                              <button onClick={() => shareOnWhatsApp(bill)} className="p-4 bg-green-50 text-green-600 rounded-2xl hover:bg-green-600 hover:text-white transition shadow-sm active:scale-95"><MdShare size={24} /></button>
                            )}
                          </>
                        )}
                     </div>
                  </div>
               </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="py-20 text-center bg-white rounded-[40px] border border-gray-100">
              <p className="text-gray-300 font-black uppercase text-xs tracking-[0.4em]">No transaction records found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReviewBills;
