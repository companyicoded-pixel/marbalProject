import React from 'react';
import { MdSettings, MdColorLens, MdNotificationsActive, MdSecurity, MdLanguage, MdHelpOutline } from 'react-icons/md';

const SettingItem = ({ icon: Icon, title, desc, action }) => (
  <div className="flex items-center justify-between p-6 bg-white border border-gray-100 rounded-[28px] shadow-sm hover:shadow-md transition group">
    <div className="flex items-center gap-6">
      <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition">
        <Icon size={24} />
      </div>
      <div>
        <h3 className="text-sm font-black text-gray-900 uppercase tracking-tight">{title}</h3>
        <p className="text-[11px] text-gray-400 font-medium leading-relaxed mt-1">{desc}</p>
      </div>
    </div>
    <button className="px-6 py-2 border border-gray-100 text-[10px] font-black uppercase tracking-widest text-gray-400 hover:border-blue-600 hover:text-blue-600 rounded-xl transition">
      {action || 'Configure'}
    </button>
  </div>
);

const SettingsPage = () => {
  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      <div className="px-10 py-10 search-container shrink-0">
        <h1 className="text-2xl font-black text-blue-900 mb-2">Terminal Configuration</h1>
        <p className="text-sm text-gray-500 mb-8">Manage system preferences and authorized access protocols.</p>
      </div>

      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar max-w-4xl">
        <div className="space-y-6">
          <div className="mb-4">
            <h2 className="text-[10px] font-black text-gray-300 uppercase tracking-[0.25em] ml-2">Personalization</h2>
          </div>
          <SettingItem icon={MdColorLens} title="Visual Theme" desc="Adjust the interface appearance for low-light environments." action="Marble Mode" />
          <SettingItem icon={MdLanguage} title="Region & Language" desc="Set the system localization for currency and date formats." action="English (IN)" />
          
          <div className="mb-4 mt-10">
            <h2 className="text-[10px] font-black text-gray-300 uppercase tracking-[0.25em] ml-2">Security & Network</h2>
          </div>
          <SettingItem icon={MdSecurity} title="Two-Factor Auth" desc="Enhance terminal security with mobile verification." action="Enabled" />
          <SettingItem icon={MdNotificationsActive} title="Alert Thresholds" desc="Configure low-stock and high-value sale notifications." />
          
          <div className="mb-4 mt-10">
            <h2 className="text-[10px] font-black text-gray-300 uppercase tracking-[0.25em] ml-2">Support</h2>
          </div>
          <SettingItem icon={MdHelpOutline} title="System Audit" desc="Generate a diagnostic report of the terminal health." action="Start Audit" />
        </div>
        
        <div className="mt-12 p-8 bg-blue-900 rounded-[32px] text-white">
           <p className="text-xs font-bold uppercase tracking-[0.2em] opacity-60">Software Version</p>
           <p className="text-3xl font-black tracking-tighter mt-1">Marble Pro v4.6.2</p>
           <p className="text-[10px] font-medium opacity-40 mt-4 leading-relaxed">
             This terminal is part of the Marble Pro Network. All transactions are end-to-end encrypted and audited by the central server.
           </p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
