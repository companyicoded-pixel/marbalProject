import React, { useEffect, useState, useRef } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { deleteProduct } from '../../../services/productService';
import toast from 'react-hot-toast';
import AddProductModal from './AddProductModal';
import EditProductModal from './EditProductModal';
import ProductTile from './ProductTile';
import QRCodeModal from './QRCodeModal';
import { 
  MdSearch, MdFilterList, MdAdd, MdViewModule, 
  MdViewList, MdLayers, MdTune, MdFileDownload 
} from 'react-icons/md';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import QRCode from 'qrcode';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [isDownloading, setIsDownloading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All Materials');
  const canvasRef = useRef(null);

  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    const qCats = query(collection(db, 'categories'), orderBy('createdAt', 'desc'));
    const unsubCats = onSnapshot(qCats, (snapshot) => {
      setCategories(snapshot.docs.map(d => d.data().name));
    });

    return () => { unsubscribe(); unsubCats(); };
  }, []);

  const downloadAllQRs = async () => {
    if (products.length === 0) return;
    setIsDownloading(true);
    const doc = new jsPDF();
    const canvas = canvasRef.current;
    
    // Page Header
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 69, 139);
    doc.text('PRODUCT LABEL REPOSITORY', 105, 20, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(150);
    doc.text(`Generated on ${new Date().toLocaleString()}`, 105, 28, { align: 'center' });
    doc.line(20, 32, 190, 32);

    let x = 20;
    let y = 45;
    const qrSize = 45;
    const margin = 15;
    const itemsPerPage = 9;

    for (let i = 0; i < products.length; i++) {
      const p = products[i];
      
      if (i > 0 && i % itemsPerPage === 0) {
        doc.addPage();
        x = 20;
        y = 45;
      }

      try {
        // Robust QR generation using a physical (but hidden) canvas
        await QRCode.toCanvas(canvas, p.sku, { 
          margin: 1, 
          width: 200,
          color: { dark: '#00458b', light: '#ffffff' }
        });
        const qrDataUrl = canvas.toDataURL('image/png');

        doc.setDrawColor(240);
        doc.setFillColor(252, 252, 252);
        doc.roundedRect(x - 2, y - 10, qrSize + 4, qrSize + 22, 3, 3, 'FD');

        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0);
        doc.text(p.name.substring(0, 22), x, y - 4);

        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(100);
        doc.text(`SKU: ${p.sku}`, x, y);

        doc.addImage(qrDataUrl, 'PNG', x, y + 2, qrSize, qrSize);

        doc.setFontSize(6);
        doc.setTextColor(180);
        doc.text('SCAN TO BILL', x + (qrSize/2), y + qrSize + 8, { align: 'center' });

        x += qrSize + margin;
        if (x > 160) {
          x = 20;
          y += qrSize + margin + 15;
        }
      } catch (err) {
        console.error(`QR Gen Failed for SKU ${p.sku}:`, err);
      }
    }

    doc.save(`MarblePro_Labels_${Date.now()}.pdf`);
    setIsDownloading(false);
    toast.success('Labels processed successfully');
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All Materials' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (loading) return (
    <div className="h-screen flex items-center justify-center bg-[#f8fafc]">
       <div className="flex flex-col items-center gap-6">
          <div className="w-16 h-16 border-4 border-blue-900 border-t-transparent rounded-full animate-spin shadow-xl"></div>
          <p className="text-[11px] font-black text-gray-400 uppercase tracking-[0.4em]">Initializing Repository...</p>
       </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-[#f8fafc]">
      {/* Hidden Canvas for QR Generation */}
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      <div className="px-6 md:px-12 py-10 md:py-16 search-container shrink-0 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-900 opacity-[0.02] rounded-full -mr-32 -mt-32"></div>
        <div className="relative z-10 max-w-[1600px] mx-auto w-full">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-blue-50 text-blue-700 rounded-lg shadow-sm"><MdLayers size={20} /></div>
                 <h1 className="text-3xl md:text-4xl font-black text-blue-900 tracking-tight">Global Inventory</h1>
              </div>
              <p className="text-sm md:text-base text-gray-500 max-w-2xl font-medium leading-relaxed">
                Management of <span className="text-blue-900 font-black">{products.length} active SKUs</span>. Synchronized across all regional distribution terminals.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
               <button 
                 onClick={downloadAllQRs}
                 disabled={isDownloading}
                 className="flex items-center justify-center gap-3 bg-white border-2 border-gray-100 text-gray-400 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:border-blue-600 hover:text-blue-600 transition-all shadow-sm group active:scale-95 disabled:opacity-50"
               >
                 <MdFileDownload size={22} className={isDownloading ? 'animate-bounce' : 'group-hover:-translate-y-1 transition-transform'} />
                 {isDownloading ? 'Processing...' : 'Download Labels'}
               </button>
               <button 
                 onClick={() => setIsAddModalOpen(true)}
                 className="flex items-center justify-center gap-3 bg-blue-900 text-white px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition-all shadow-2xl shadow-blue-100 group active:scale-95"
               >
                 <MdAdd size={22} className="group-hover:rotate-90 transition-transform duration-300" />
                 Provision New SKU
               </button>
            </div>
          </div>

          <div className="mt-12 flex flex-col lg:flex-row gap-4">
            <div className="flex-1 flex items-center gap-4 bg-white px-8 py-5 rounded-3xl shadow-xl shadow-blue-100/50 border border-gray-100 focus-within:ring-4 focus-within:ring-blue-50 transition-all group">
              <MdSearch className="text-gray-300 group-focus-within:text-blue-600 transition-colors" size={26} />
              <input 
                type="text" 
                placeholder="Search repository by Name, Category, or SKU ID..." 
                className="w-full text-sm md:text-base outline-none font-bold text-gray-700 placeholder:text-gray-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex flex-wrap gap-4">
              <div className="bg-white px-6 py-5 rounded-3xl shadow-xl shadow-blue-100/50 border border-gray-100 flex items-center gap-3">
                 <MdFilterList className="text-gray-400" size={20} />
                 <select 
                   className="text-xs md:text-sm font-black text-gray-500 uppercase tracking-widest outline-none bg-transparent cursor-pointer hover:text-blue-700 transition-colors"
                   value={selectedCategory}
                   onChange={(e) => setSelectedCategory(e.target.value)}
                 >
                   <option value="All Materials">All Materials</option>
                   {categories.map(c => <option key={c} value={c}>{c}</option>)}
                 </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-12 custom-scrollbar">
        <div className="max-w-[1600px] mx-auto w-full">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
             <div className="flex gap-2 p-1.5 bg-white border border-gray-100 rounded-2xl shadow-sm">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
                    viewMode === 'grid' ? 'bg-blue-900 text-white shadow-lg shadow-blue-100' : 'text-gray-400 hover:text-blue-700'
                  }`}
                >
                   <MdViewModule size={18} /> Grid
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
                    viewMode === 'list' ? 'bg-blue-900 text-white shadow-lg shadow-blue-100' : 'text-gray-400 hover:text-blue-700'
                  }`}
                >
                   <MdViewList size={18} /> List
                </button>
             </div>
             <div className="flex items-center gap-4 px-6 py-3 bg-blue-50/50 rounded-2xl border border-blue-100/50">
                <span className="text-[10px] font-black text-blue-900 uppercase tracking-[0.2em]">Live Results:</span>
                <span className="text-sm font-black text-blue-900 tracking-tighter">{filteredProducts.length} Entries</span>
             </div>
          </div>

          <div className={`grid gap-8 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
              : 'grid-cols-1'
          }`}>
             {filteredProducts.map(product => (
               <ProductTile 
                 key={product.id} 
                 product={product} 
                 viewMode={viewMode}
                 onEdit={(p) => { setSelectedProduct(p); setIsEditModalOpen(true); }}
                 onViewQR={(p) => { setSelectedProduct(p); setIsQRModalOpen(true); }}
               />
             ))}
          </div>
        </div>
      </div>

      <AddProductModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onProductAdded={() => {}} 
      />
      <EditProductModal 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)} 
        product={selectedProduct}
        onProductUpdated={() => setIsEditModalOpen(false)}
      />
      <QRCodeModal
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
        product={selectedProduct}
      />
    </div>
  );
};

export default ProductList;
