import React from 'react';
import { MdLocationOn, MdFullscreen, MdCircle, MdQrCodeScanner, MdCategory, MdLayers } from 'react-icons/md';

const ProductTile = ({ product, onEdit, onViewQR, viewMode }) => {
  const isLowStock = (product.quantity || 0) < 10;

  if (viewMode === 'list') {
     return (
        <div className="bg-white rounded-3xl border border-gray-100 p-6 flex items-center gap-8 group hover:shadow-xl hover:shadow-blue-100/30 transition-all duration-300">
           <div className="w-24 h-24 bg-gray-50 rounded-2xl overflow-hidden shrink-0">
              <img 
                src={product.image || `https://ui-avatars.com/api/?name=${product.name}&background=eff6ff&color=00458b&bold=true&size=128`} 
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
           </div>
           <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                 <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded-full">{product.category}</span>
                 <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest font-mono">#{product.sku}</span>
              </div>
              <h3 className="text-xl font-black text-gray-900 tracking-tight">{product.name}</h3>
              <p className="text-xs text-gray-400 font-medium mt-1 truncate max-w-md">{product.description || 'No technical specifications provided.'}</p>
           </div>
           <div className="flex items-center gap-12 border-x border-gray-50 px-12">
              <div className="text-center">
                 <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mb-1">Price</p>
                 <p className="text-lg font-black text-blue-900">₹{product.price?.toLocaleString()}</p>
              </div>
              <div className="text-center">
                 <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mb-1">In Stock</p>
                 <p className={`text-lg font-black ${isLowStock ? 'text-red-500' : 'text-gray-900'}`}>{product.quantity} <span className="text-[10px] opacity-40">Units</span></p>
              </div>
           </div>
           <div className="flex gap-3">
              <button onClick={() => onViewQR(product)} className="w-12 h-12 flex items-center justify-center bg-gray-50 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-2xl transition-all"><MdQrCodeScanner size={20} /></button>
              <button onClick={() => onEdit(product)} className="w-12 h-12 flex items-center justify-center bg-blue-900 text-white rounded-2xl hover:bg-blue-800 transition-all shadow-lg shadow-blue-100"><MdFullscreen size={24} /></button>
           </div>
        </div>
     );
  }

  return (
    <div className="bg-white rounded-[32px] overflow-hidden border border-gray-100 shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 group">
      {/* Image Area */}
      <div className="relative h-56 bg-gray-50 overflow-hidden">
        <img 
          src={product.image || `https://ui-avatars.com/api/?name=${product.name}&background=eff6ff&color=00458b&bold=true&size=256`} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4">
          <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
            isLowStock ? 'bg-red-500 text-white shadow-lg shadow-red-100' : 'bg-green-500 text-white shadow-lg shadow-green-100'
          }`}>
            <MdCircle size={8} className="animate-pulse" />
            {isLowStock ? 'Low Stock' : 'Active'}
          </span>
        </div>
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full border border-white/50 text-[10px] font-black text-blue-900 uppercase tracking-widest shadow-sm">
           {product.category}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-8">
        <div className="flex items-center gap-2 text-gray-300 text-[9px] font-black uppercase tracking-[0.2em] mb-3">
          <MdLocationOn size={14} className="text-blue-600" />
          <span>Warehouse Terminal 1</span>
        </div>
        <h3 className="text-lg font-black text-gray-900 tracking-tight mb-6 leading-tight group-hover:text-blue-900 transition-colors">{product.name}</h3>

        <div className="grid grid-cols-2 gap-4 mb-8">
           <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
              <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest mb-1 flex items-center gap-1.5"><MdLayers size={12} /> Stock</p>
              <p className={`text-sm font-black ${isLowStock ? 'text-red-500' : 'text-gray-900'}`}>{product.quantity} <span className="text-[10px] opacity-40">Units</span></p>
           </div>
           <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
              <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest mb-1 flex items-center gap-1.5"><MdCategory size={12} /> SKU</p>
              <p className="text-sm font-black text-gray-900 font-mono tracking-tighter uppercase">{product.sku?.slice(0, 8) || 'N/A'}</p>
           </div>
        </div>

        <div className="flex justify-between items-end border-t border-gray-50 pt-6">
           <div>
              <p className="text-[10px] text-gray-300 font-black uppercase tracking-widest mb-1">Settlement Price</p>
              <p className="text-2xl font-black text-blue-900 tracking-tighter">₹{product.price?.toLocaleString()}</p>
           </div>
           <div className="flex gap-2">
              <button onClick={() => onViewQR(product)} className="w-11 h-11 bg-gray-50 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all flex items-center justify-center" title="Provision QR">
                 <MdQrCodeScanner size={20} />
              </button>
              <button onClick={() => onEdit(product)} className="w-11 h-11 bg-blue-900 text-white rounded-xl hover:bg-blue-800 transition-all flex items-center justify-center shadow-lg shadow-blue-100" title="Terminal Config">
                 <MdFullscreen size={24} />
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ProductTile;
