import React, { useState, useEffect } from 'react';
import { addProduct } from '../../../services/productService';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import toast from 'react-hot-toast';
import { 
  MdAddCircle, MdClose, MdCloudUpload, 
  MdCheckCircle, MdPrint, MdImage 
} from 'react-icons/md';
import { QRCodeSVG } from 'qrcode.react';

const AddProductModal = ({ isOpen, onClose, onProductAdded }) => {
  const [formData, setFormData] = useState({
    name: '', price: '', quantity: '', category: '', description: '', image: ''
  });
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [createdProduct, setCreatedProduct] = useState(null);

  useEffect(() => {
    if (isOpen) {
      const q = query(collection(db, 'categories'), orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const cats = snapshot.docs.map(d => d.data().name);
        setCategories(cats);
        if (cats.length > 0 && !formData.category) {
          setFormData(prev => ({ ...prev, category: cats[0] }));
        }
      });
      return () => unsubscribe();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.category) {
      toast.error('Please select or create a category first');
      return;
    }
    setLoading(true);
    try {
      const newProduct = await addProduct({
        ...formData,
        price: parseFloat(formData.price),
        quantity: parseInt(formData.quantity)
      });
      
      setCreatedProduct(newProduct); 
      toast.success('Inventory Synchronized');
      onProductAdded();
      setFormData({ name: '', price: '', quantity: '', category: categories[0] || '', description: '', image: '' });
    } catch { 
      toast.error('Provisioning failed'); 
    } finally { 
      setLoading(false); 
    }
  };

  const handleClose = () => {
    setCreatedProduct(null);
    onClose();
  };

  const printQR = () => {
    const printWindow = window.open('', '_blank');
    const qrSvg = document.getElementById('new-product-qr').outerHTML;
    printWindow.document.write(`
      <html>
        <head><title>Print QR - ${createdProduct.name}</title></head>
        <body style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:sans-serif;">
          <h2 style="margin-bottom:10px;">${createdProduct.name}</h2>
          ${qrSvg}
          <p style="margin-top:10px; font-weight:bold; font-size:20px;">SKU: ${createdProduct.sku}</p>
          <script>window.onload = () => { window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-blue-900/60 backdrop-blur-md p-4 transition-all">
      <div className={`bg-white w-full max-w-lg rounded-[48px] shadow-2xl p-10 relative overflow-hidden transition-all duration-700 transform ${createdProduct ? 'scale-105' : 'scale-100'}`}>
        <div className="absolute top-0 left-0 w-full h-2 bg-blue-600"></div>
        
        {createdProduct ? (
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-green-100 rounded-full animate-ping opacity-25"></div>
                <div className="relative p-5 bg-green-50 text-green-600 rounded-full">
                  <MdCheckCircle size={54} />
                </div>
              </div>
            </div>
            
            <h2 className="text-3xl font-black text-gray-900 mb-1 tracking-tight">Product Provisioned</h2>
            <p className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em] mb-8">SKU: {createdProduct.sku}</p>
            
            <div className="bg-[#f8fafc] p-10 rounded-[40px] border border-gray-100 flex flex-col items-center mb-8 shadow-inner">
               <div className="bg-white p-6 rounded-3xl shadow-xl mb-6 ring-8 ring-blue-50">
                  <QRCodeSVG id="new-product-qr" value={createdProduct.sku} size={160} />
               </div>
               <div className="text-center">
                  <p className="text-[9px] font-black text-blue-900/40 uppercase tracking-[0.3em] mb-1">Encoded Data (SKU)</p>
                  <p className="text-lg font-black text-blue-900 tracking-tighter">{createdProduct.sku}</p>
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <button 
                 onClick={printQR} 
                 className="flex items-center justify-center gap-3 border-2 border-gray-100 text-gray-500 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:border-blue-600 hover:text-blue-600 transition"
               >
                  <MdPrint size={20} /> Print Label
               </button>
               <button 
                 onClick={handleClose} 
                 className="bg-blue-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition shadow-xl shadow-blue-100 active:scale-95"
               >
                  Finish Audit
               </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-center mb-10">
              <div className="flex items-center gap-4">
                 <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl shadow-sm"><MdAddCircle size={28} /></div>
                 <div>
                    <h2 className="text-2xl font-black text-gray-900 tracking-tight leading-none">Provision SKU</h2>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1.5">New Inventory Entry</p>
                 </div>
              </div>
              <button onClick={onClose} className="p-2 text-gray-300 hover:text-gray-900 transition"><MdClose size={28} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6 overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
              <div className="space-y-5">
                <div className="flex flex-col items-center gap-4 p-6 border-2 border-dashed border-gray-100 rounded-[32px] bg-gray-50/50 hover:bg-blue-50/30 transition duration-300 cursor-pointer relative group">
                   <input type="file" accept="image/*" onChange={handleImageChange} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                   {formData.image ? (
                     <img src={formData.image} alt="Preview" className="w-24 h-24 object-cover rounded-2xl shadow-lg" />
                   ) : (
                     <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center text-gray-300 shadow-sm group-hover:text-blue-600 group-hover:scale-110 transition-all duration-300">
                        <MdImage size={40} />
                     </div>
                   )}
                   <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest group-hover:text-blue-900 transition-colors">Click to Upload Product Image</p>
                </div>

                <div className="group">
                  <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 ml-1 group-focus-within:text-blue-600 transition-colors">Product Nomenclature</label>
                  <input
                    type="text" required
                    className="w-full px-6 py-4 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-4 focus:ring-blue-100 focus:bg-white focus:border-blue-600 outline-none font-bold text-sm transition-all"
                    placeholder="e.g. Italian Statuario White"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-5">
                  <div className="group">
                    <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 ml-1 group-focus-within:text-blue-600 transition-colors">Unit Price (₹)</label>
                    <input
                      type="number" step="0.01" required
                      className="w-full px-6 py-4 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-4 focus:ring-blue-100 focus:bg-white focus:border-blue-600 outline-none font-bold text-sm transition-all"
                      placeholder="0.00"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                    />
                  </div>
                  <div className="group">
                    <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 ml-1 group-focus-within:text-blue-600 transition-colors">Initial Qty</label>
                    <input
                      type="number" required
                      className="w-full px-6 py-4 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-4 focus:ring-blue-100 focus:bg-white focus:border-blue-600 outline-none font-bold text-sm transition-all"
                      placeholder="0"
                      value={formData.quantity}
                      onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="group">
                  <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 ml-1 group-focus-within:text-blue-600 transition-colors">Material Category</label>
                  <select
                    className="w-full px-6 py-4 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-4 focus:ring-blue-100 focus:bg-white focus:border-blue-600 outline-none font-bold text-sm transition-all appearance-none cursor-pointer"
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                  >
                    {categories.length > 0 ? (
                      categories.map(c => <option key={c} value={c}>{c}</option>)
                    ) : (
                      <option disabled>No categories found. Create one first.</option>
                    )}
                  </select>
                </div>

                <div className="group">
                  <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 ml-1 group-focus-within:text-blue-600 transition-colors">Description / Notes</label>
                  <textarea
                    className="w-full px-6 py-4 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-4 focus:ring-blue-100 focus:bg-white focus:border-blue-600 outline-none font-bold text-sm transition-all min-h-[100px]"
                    placeholder="Technical specifications, origin, etc."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                  />
                </div>
              </div>
              
              <button
                type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-3 bg-blue-900 text-white py-5 rounded-[24px] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95 disabled:opacity-50 mt-4 overflow-hidden relative group"
              >
                <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                <MdCloudUpload size={22} />
                {loading ? 'Synchronizing...' : 'Commit to Inventory'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default AddProductModal;
