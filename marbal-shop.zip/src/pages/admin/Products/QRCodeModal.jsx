import React from 'react';
import { MdClose, MdPrint, MdQrCodeScanner } from 'react-icons/md';
import { QRCodeSVG } from 'qrcode.react';

const QRCodeModal = ({ isOpen, onClose, product }) => {
  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-blue-900/60 backdrop-blur-md p-4 transition-all">
      <div className="bg-white w-full max-w-sm rounded-[48px] shadow-2xl p-10 relative overflow-hidden transition-all duration-700 transform scale-100">
        <div className="absolute top-0 left-0 w-full h-2 bg-blue-600"></div>
        
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
             <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl shadow-sm"><MdQrCodeScanner size={24} /></div>
             <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight leading-none">Product QR</h2>
             </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-300 hover:text-gray-900 transition"><MdClose size={24} /></button>
        </div>

        <div className="text-center">
          <p className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">{product.name}</p>
          
          <div className="bg-[#f8fafc] p-8 rounded-[40px] border border-gray-100 flex flex-col items-center mb-8 shadow-inner">
             <div className="bg-white p-4 rounded-3xl shadow-xl mb-6 ring-8 ring-blue-50" id={`qr-print-${product.sku}`}>
                <QRCodeSVG value={product.sku} size={160} />
             </div>
             <div className="text-center">
                <p className="text-[9px] font-black text-blue-900/40 uppercase tracking-[0.3em] mb-1">Encoded Data (SKU)</p>
                <p className="text-lg font-black text-blue-900 tracking-tighter">{product.sku}</p>
             </div>
          </div>

          <button 
            onClick={() => window.print()} 
            className="w-full flex items-center justify-center gap-3 bg-blue-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition shadow-xl shadow-blue-100 active:scale-95"
          >
             <MdPrint size={20} /> Print Label
          </button>
        </div>
      </div>
    </div>
  );
};

export default QRCodeModal;
