import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, addDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdCategory, MdAdd, MdDelete, MdLayers } from 'react-icons/md';
import toast from 'react-hot-toast';

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newCategory, setNewCategory] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'categories'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setCategories(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newCategory.trim()) return;
    try {
      await addDoc(collection(db, 'categories'), {
        name: newCategory.trim(),
        createdAt: serverTimestamp()
      });
      setNewCategory('');
      toast.success('Category Added');
    } catch { toast.error('Failed to add category'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this category?')) return;
    try {
      await deleteDoc(doc(db, 'categories', id));
      toast.success('Category Removed');
    } catch { toast.error('Failed to remove'); }
  };

  return (
    <div className="p-8 lg:p-12 max-w-4xl mx-auto space-y-12 animate-slide-up">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-blue-900 tracking-tight">Category Logistics</h1>
          <p className="text-sm text-gray-500 font-medium mt-2">Manage material classifications across your global inventory.</p>
        </div>
        <div className="bg-blue-50 px-6 py-3 rounded-2xl border border-blue-100 flex items-center gap-3">
           <span className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Active Sectors:</span>
           <span className="text-lg font-black text-blue-900 tracking-tighter">{categories.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Add Category Form */}
        <div className="bg-white p-10 rounded-[40px] border border-gray-100 shadow-sm space-y-8 h-fit">
           <div className="flex items-center gap-4">
              <div className="p-4 bg-blue-900 text-white rounded-3xl shadow-xl shadow-blue-100"><MdAdd size={28} /></div>
              <h2 className="text-xl font-black text-gray-900 tracking-tight">Provision Sector</h2>
           </div>
           
           <form onSubmit={handleAdd} className="space-y-6">
              <div>
                 <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Category Nomenclature</label>
                 <input 
                   type="text" required
                   placeholder="e.g. Italian Granite"
                   className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-100 transition-all font-bold text-sm"
                   value={newCategory}
                   onChange={e => setNewCategory(e.target.value)}
                 />
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-900 text-white py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95"
              >
                 Commit to Registry
              </button>
           </form>
        </div>

        {/* Categories List */}
        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
           {categories.map((cat) => (
             <div key={cat.id} className="bg-white p-6 rounded-[32px] border border-gray-100 flex justify-between items-center group hover:border-blue-600 hover:shadow-xl hover:shadow-blue-100/30 transition-all duration-300">
                <div className="flex items-center gap-4">
                   <div className="p-3 bg-gray-50 text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-600 rounded-xl transition-colors"><MdLayers size={20} /></div>
                   <span className="font-black text-gray-800 tracking-tight group-hover:text-blue-900 transition-colors">{cat.name}</span>
                </div>
                <button 
                  onClick={() => handleDelete(cat.id)}
                  className="p-3 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                >
                   <MdDelete size={20} />
                </button>
             </div>
           ))}
           {categories.length === 0 && !loading && (
             <div className="text-center py-20 bg-gray-50 rounded-[40px] border-2 border-dashed border-gray-100">
                <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Registry Empty</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default CategoriesPage;
