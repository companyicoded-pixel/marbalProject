import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../../services/authService';
import toast from 'react-hot-toast';
import { MdEmail, MdLock, MdLogin } from 'react-icons/md';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Access Granted');
      navigate('/');
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] font-sans px-6">
      <div className="max-w-md w-full">
        {/* Logo Area */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-2">
             <div className="w-12 h-12 bg-blue-900 rounded-xl flex items-center justify-center text-white text-xl font-black shadow-2xl shadow-blue-100">M</div>
             <span className="text-3xl font-black text-blue-900 tracking-tighter uppercase">Marble Pro</span>
          </div>
          <p className="text-sm text-gray-400 font-bold uppercase tracking-[0.2em]">Enterprise Terminal</p>
        </div>

        <div className="bg-white p-10 rounded-[40px] border border-gray-100 shadow-2xl shadow-blue-50">
          <div className="mb-8 text-center">
            <h2 className="text-2xl font-black text-gray-900 mb-1">Authentication</h2>
            <p className="text-sm text-gray-400">Please enter your credentials to proceed</p>
          </div>

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
                <div className="relative">
                  <MdEmail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input
                    type="email" required
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Password</label>
                <div className="relative">
                  <MdLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input
                    type="password" required
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <button
              type="submit" disabled={loading}
              className="w-full flex justify-center items-center gap-2 py-4 bg-blue-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-800 transition-all active:scale-95 disabled:opacity-50"
            >
              {loading ? 'Processing...' : (
                <>
                  <MdLogin size={20} />
                  Enter Terminal
                </>
              )}
            </button>

            <div className="text-center pt-6">
              <p className="text-[11px] text-gray-400 font-bold uppercase tracking-widest">
                New Staff Member?{' '}
                <Link to="/register" className="text-blue-600 hover:underline">
                  Apply for Access
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
