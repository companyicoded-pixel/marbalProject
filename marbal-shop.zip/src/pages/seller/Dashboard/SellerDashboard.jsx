import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { useAuth } from '../../../context/AuthContext';
import { createBill } from '../../../services/billService';
import { logout } from '../../../services/authService';
import { generateInvoice, shareOnWhatsApp } from '../../../services/reportService';
import toast from 'react-hot-toast';

import { 
  MdQrCodeScanner, MdShoppingCart, MdHistory, MdPerson,
  MdSearch, MdNotifications, MdLogout, MdArrowForward,
  MdCheckCircle, MdFileDownload, MdShare, MdClose
} from 'react-icons/md';

import SellerStatsCards from '../components/SellerStatsCards';
import ProductScanner from '../components/ProductScanner';
import CartPreview from '../components/CartPreview';
import RecentBills from '../components/RecentBills';

const QuickAction = ({ icon: Icon, label, onClick, color }) => (
  <button 
    onClick={onClick}
    className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col items-center gap-4 flex-1 min-w-[140px]"
  >
    <div className={`p-4 rounded-2xl ${color} group-hover:scale-110 transition-transform`}>
      <Icon size={28} />
    </div>
    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 group-hover:text-blue-900 transition-colors">{label}</span>
  </button>
);

const SellerDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cart, setCart] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [lastCreatedBill, setLastCreatedBill] = useState(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [stats, setStats] = useState({ todaysSales: 0, todaysBills: 0, cartItems: 0, pendingBills: 0 });

  useEffect(() => {
    if (!user) return;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const qBills = query(collection(db, 'bills'), where('sellerId', '==', user.uid));
    const unsubBills = onSnapshot(qBills, (snapshot) => {
      const allBills = snapshot.docs.map(doc => doc.data());
      const todayBills = allBills.filter(b => b.createdAt?.toDate() >= today);
      
      setStats(prev => ({
        ...prev,
        todaysSales: todayBills.filter(b => b.status === 'approved').reduce((s, b) => s + (b.totalAmount || 0), 0),
        todaysBills: todayBills.length,
        pendingBills: allBills.filter(b => b.status === 'pending').length
      }));
    });

    return () => unsubBills();
  }, [user]);

  useEffect(() => {
    setStats(prev => ({ ...prev, cartItems: cart.reduce((s, i) => s + (i.quantity || 0), 0) }));
  }, [cart]);

  const handleAddToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.quantity) {
          toast.error(`Only ${product.quantity} units available`);
          return prev;
        }
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      
      if (product.quantity <= 0) {
        toast.error('Item Out of Stock');
        return prev;
      }
      
      return [...prev, { ...product, quantity: 1, stockQuantity: product.quantity, sku: product.sku }];
    });
    toast.success(`${product.name} identified`);
  };

  const handleUpdateQuantity = (id, delta) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        if (delta > 0 && newQty > item.stockQuantity) {
           toast.error('Exceeds available stock');
           return item;
        }
        return { ...item, quantity: Math.max(1, newQty) };
      }
      return item;
    }));
  };

  const handleRemoveItem = (id) => setCart(prev => prev.filter(i => i.id !== id));

  const handleCheckout = async (customerInfo) => {
    if (cart.length === 0) return;
    setIsCreating(true);
    try {
      const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const billData = {
        sellerId: user.uid,
        sellerName: user.email?.split('@')[0] || 'Seller',
        items: cart.map(({ id, name, price, quantity, sku }) => ({ id, name, price, quantity, sku })),
        totalAmount,
        category: 'General',
        customerName: customerInfo.name || 'Walk-in',
        customerContact: customerInfo.contact || '',
        customerAddress: customerInfo.address || '',
        paymentMode: customerInfo.paymentMode || 'Cash',
      };
      
      const billId = await createBill(billData);
      const finalBill = { id: billId, ...billData };
      
      setLastCreatedBill(finalBill);
      setShowSuccessModal(true);
      toast.success('Bill submitted for approval');
      setCart([]);
    } catch (err) {
      toast.error('Failed to create bill');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      {/* Header Area */}
      <div className="px-10 py-10 search-container shrink-0">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-black text-blue-900 tracking-tight">POS Sales Terminal</h1>
            <p className="text-sm text-gray-500 mt-1">Ready for transaction. System synchronized with cloud inventory.</p>
          </div>
          <div className="flex gap-3">
             <button className="p-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-gray-400 hover:text-blue-600 transition"><MdNotifications size={24} /></button>
             <button onClick={logout} className="p-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-gray-400 hover:text-red-500 transition"><MdLogout size={24} /></button>
          </div>
        </div>

        <div className="flex gap-4 bg-white p-2 rounded-[24px] shadow-xl border border-gray-100 max-w-4xl">
           <div className="flex-1 flex items-center gap-4 px-6">
              <MdSearch className="text-gray-300" size={24} />
              <input type="text" placeholder="Scan SKU or Search Manually..." className="w-full bg-transparent outline-none font-medium text-gray-600" />
           </div>
           <button className="bg-blue-900 text-white px-10 py-3 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-blue-800 transition">Search</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
          <div className="xl:col-span-2 space-y-10">
            <div className="flex flex-wrap gap-6">
              <QuickAction icon={MdQrCodeScanner} label="Scan Product" color="bg-blue-50 text-blue-600" onClick={() => document.getElementById('scanner')?.scrollIntoView({ behavior: 'smooth' })} />
              <QuickAction icon={MdShoppingCart} label="Active Cart" color="bg-green-50 text-green-600" onClick={() => document.getElementById('cart')?.scrollIntoView({ behavior: 'smooth' })} />
              <QuickAction icon={MdHistory} label="Billing History" color="bg-orange-50 text-orange-500" onClick={() => navigate('/seller/history')} />
              <QuickAction icon={MdPerson} label="My Profile" color="bg-purple-50 text-purple-600" onClick={() => navigate('/seller/profile')} />
            </div>

            <SellerStatsCards stats={stats} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
               <div id="scanner" className="space-y-6">
                  <div className="flex justify-between items-center px-2">
                     <h2 className="text-sm font-black text-gray-900 uppercase tracking-widest">Optical Terminal</h2>
                     <span className="flex items-center gap-1.5 text-[10px] font-black text-green-500 uppercase tracking-widest"><div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div> Cam Ready</span>
                  </div>
                  <ProductScanner onAddToCart={handleAddToCart} />
               </div>
              <div className="space-y-6">
                 <RecentBills sellerId={user?.uid} />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <CartPreview 
              cart={cart} 
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onCheckout={handleCheckout} 
              isProcessing={isCreating}
            />
          </div>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-blue-900/60 backdrop-blur-md p-4">
           <div className="bg-white w-full max-w-md rounded-[48px] p-10 text-center shadow-2xl relative animate-slide-up">
              <button onClick={() => setShowSuccessModal(false)} className="absolute top-8 right-8 text-gray-300 hover:text-gray-900 transition"><MdClose size={28} /></button>
              
              <div className="flex justify-center mb-8">
                 <div className="w-24 h-24 bg-green-50 text-green-600 rounded-[32px] flex items-center justify-center shadow-xl shadow-green-100">
                    <MdCheckCircle size={56} />
                 </div>
              </div>
              
              <h2 className="text-3xl font-black text-gray-900 mb-2 tracking-tight">Bill Generated</h2>
              <p className="text-sm text-gray-400 font-medium mb-10 leading-relaxed px-4">Transaction recorded successfully. You can now share or download the invoice.</p>
              
              <div className="space-y-4">
                 <button 
                   onClick={() => generateInvoice(lastCreatedBill)}
                   className="w-full flex items-center justify-center gap-3 bg-blue-900 text-white py-5 rounded-3xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95"
                 >
                    <MdFileDownload size={22} /> Download PDF Invoice
                 </button>
                 
                 {lastCreatedBill?.customerContact && (
                    <button 
                      onClick={() => shareOnWhatsApp(lastCreatedBill)}
                      className="w-full flex items-center justify-center gap-3 bg-green-500 text-white py-5 rounded-3xl font-black text-xs uppercase tracking-widest shadow-xl shadow-green-100 hover:bg-green-600 transition active:scale-95"
                    >
                       <MdShare size={22} /> Share on WhatsApp
                    </button>
                 )}
                 
                 <button 
                   onClick={() => setShowSuccessModal(false)}
                   className="w-full py-4 text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] hover:text-gray-600 transition"
                 >
                    Next Transaction
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default SellerDashboard;
