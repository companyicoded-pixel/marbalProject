import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { useAuth } from '../../../context/AuthContext';
import { MdHistory, MdReceipt, MdDownload } from 'react-icons/md';
import { generateInvoice } from '../../../services/reportService';

/**
 * Seller's Billing History Page
 * Note: Uses in-memory sorting to avoid Firestore composite index requirement.
 */
const BillingHistory = () => {
  const { user } = useAuth();
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    // Simple query to avoid index requirement
    const q = query(
      collection(db, 'bills'),
      where('sellerId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      // In-memory sort by date descending
      const sorted = data.sort((a, b) => {
        const timeA = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
        const timeB = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
        return timeB - timeA;
      });

      setBills(sorted);
      setLoading(false);
    }, (error) => {
      console.error("Firestore Error in BillingHistory:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-10">
        <h1 className="text-4xl font-black text-gray-900 tracking-tight flex items-center gap-4">
          <MdHistory className="text-indigo-600" /> Billing History
        </h1>
        <p className="text-sm text-gray-400 font-bold mt-1 uppercase tracking-widest">View and track all your submitted bills</p>
      </div>

      <div className="bg-white rounded-[32px] shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Bill ID</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Date</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Amount</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {bills.map(bill => (
                <tr key={bill.id} className="hover:bg-gray-50/60 transition group">
                  <td className="px-8 py-5">
                    <p className="font-mono text-xs font-bold text-gray-500">#{bill.id.slice(0, 10)}</p>
                  </td>
                  <td className="px-8 py-5 text-sm font-medium text-gray-600">
                    {bill.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(bill.createdAt.toDate()) : 'N/A'}
                  </td>
                  <td className="px-8 py-5">
                    <p className="font-black text-gray-900">₹{bill.totalAmount?.toLocaleString()}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      bill.status === 'approved' ? 'bg-green-100 text-green-700' :
                      bill.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'
                    }`}>
                      {bill.status}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    {bill.status === 'approved' && (
                      <button 
                        onClick={() => generateInvoice(bill)}
                        className="p-2 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg transition shadow-sm"
                      >
                        <MdDownload size={18} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {bills.length === 0 && (
                <tr>
                  <td colSpan="5" className="px-8 py-20 text-center">
                    <div className="text-4xl mb-4 text-gray-300"><MdReceipt /></div>
                    <p className="text-gray-400 font-bold uppercase text-xs tracking-widest">No bills found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BillingHistory;
