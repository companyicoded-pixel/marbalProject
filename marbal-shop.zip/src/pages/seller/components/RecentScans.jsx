import React from 'react';
import { MdAccessTime } from 'react-icons/md';

/**
 * Props
 *   scans: Array of {
 *     id: string,
 *     name: string,
 *     quantity: number,
 *     price: number,
 *     scannedAt: Timestamp (Firestore) or Date
 *   }
 */
const RecentScans = ({ scans }) => {
  return (
    <div className="bg-white rounded-[28px] border border-gray-100 shadow-sm overflow-hidden mb-8">
      <div className="px-6 py-4 border-b border-gray-50 flex items-center">
        <h2 className="font-black text-gray-900 text-lg">Recent Scanned Products</h2>
      </div>
      {scans.length === 0 ? (
        <div className="p-6 text-center text-gray-400">No products scanned yet.</div>
      ) : (
        <ul className="divide-y divide-gray-50 max-h-[300px] overflow-y-auto">
          {scans.map((s) => (
            <li key={s.id} className="px-6 py-4 flex justify-between items-center">
              <div>
                <p className="font-bold text-gray-800">{s.name}</p>
                <p className="text-xs text-gray-400">Qty: {s.quantity} • ₹{s.price}</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <MdAccessTime size={16} />
                <span>{
                  s.scannedAt?.toDate
                    ? new Intl.DateTimeFormat('en-IN', { hour: 'numeric', minute: 'numeric', hour12: true }).format(s.scannedAt.toDate())
                    : new Intl.DateTimeFormat('en-IN', { hour: 'numeric', minute: 'numeric', hour12: true }).format(new Date())
                }</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default RecentScans;
