import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { getProductBySKU } from '../../../services/productService';
import { MdQrCodeScanner, MdAddCircle, MdSearch, MdCameraAlt, MdClose } from 'react-icons/md';
import toast from 'react-hot-toast';

const ProductScanner = ({ onAddToCart }) => {
  const [sku, setSku] = useState('');
  const [loading, setLoading] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const scannerRef = useRef(null);

  useEffect(() => {
    if (showCamera) {
      const scanner = new Html5QrcodeScanner("reader", { 
        fps: 10, 
        qrbox: { width: 250, height: 250 },
        rememberLastUsedCamera: true
      });

      scanner.render(onScanSuccess, onScanFailure);
      scannerRef.current = scanner;
    } else {
      if (scannerRef.current) {
        scannerRef.current.clear();
        scannerRef.current = null;
      }
    }

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear();
      }
    };
  }, [showCamera]);

  async function onScanSuccess(decodedText) {
    if (loading) return;
    setLoading(true);
    try {
      const product = await getProductBySKU(decodedText);
      if (product) {
        // Stock Validation Logic
        if (product.quantity <= 0) {
           toast.error('Out of Stock!');
        } else {
           onAddToCart(product);
           toast.success(`${product.name} Identified`);
           setShowCamera(false); // Close camera on success
        }
      } else {
        toast.error('Unknown Product SKU');
      }
    } catch (err) {
      toast.error('Database sync error');
    } finally {
      setLoading(false);
    }
  }

  function onScanFailure(error) {
    // Silent failure for continuous scanning
  }

  const handleManualSubmit = async (e) => {
    e.preventDefault();
    if (!sku.trim()) return;
    setLoading(true);
    try {
      const product = await getProductBySKU(sku.trim());
      if (product) {
        if (product.quantity <= 0) {
           toast.error('Out of Stock!');
        } else {
           onAddToCart(product);
           setSku('');
        }
      } else {
        toast.error('Product not found');
      }
    } catch (err) {
      toast.error('Lookup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-[40px] border border-gray-100 shadow-xl overflow-hidden group">
      <div className="p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
              <MdQrCodeScanner size={32} />
            </div>
            <div>
              <h3 className="text-xl font-black text-gray-900 tracking-tight">Product Scanner</h3>
              <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mt-1">Terminal ID: #MARB-001</p>
            </div>
          </div>
          <button 
            onClick={() => setShowCamera(!showCamera)}
            className={`p-4 rounded-2xl transition-all ${showCamera ? 'bg-red-50 text-red-500' : 'bg-blue-900 text-white shadow-lg shadow-blue-100 hover:bg-blue-800'}`}
          >
            {showCamera ? <MdClose size={24} /> : <MdCameraAlt size={24} />}
          </button>
        </div>

        {showCamera && (
          <div className="mb-8 overflow-hidden rounded-3xl border-4 border-blue-50">
            <div id="reader" className="w-full"></div>
            <div className="bg-blue-50 p-4 text-center">
               <p className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Aim camera at product QR code</p>
            </div>
          </div>
        )}

        <form onSubmit={handleManualSubmit} className="space-y-4">
          <div className="relative">
             <input
               type="text"
               placeholder="Enter Product SKU..."
               className="w-full bg-gray-50 border border-gray-100 rounded-2xl px-6 py-4 font-black text-blue-900 placeholder:text-gray-300 outline-none focus:ring-2 focus:ring-blue-600 transition"
               value={sku}
               onChange={(e) => setSku(e.target.value)}
             />
             <MdSearch className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-300" size={24} />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-900 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
          >
            <MdAddCircle size={20} />
            {loading ? 'Validating...' : 'Identify & Add to Cart'}
          </button>
        </form>
      </div>
      
      <div className="bg-gray-50/50 p-6 flex items-center justify-center gap-4">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Optical Recognition System Ready</p>
      </div>
    </div>
  );
};

export default ProductScanner;
