import React, { useState } from 'react';
import { 
  MdShoppingCart, MdPayment, MdAdd, MdRemove, 
  MdDelete, MdPerson, MdPhone, MdLocationOn, MdWallet 
} from 'react-icons/md';

const CartPreview = ({ cart, onUpdateQuantity, onRemoveItem, onCheckout, isProcessing }) => {
  const [customerInfo, setCustomerInfo] = useState({
    name: '', contact: '', address: '', paymentMode: 'Cash'
  });

  const totalItems = cart.reduce((sum, i) => sum + (i.quantity || 0), 0);
  const totalAmount = cart.reduce((sum, i) => sum + (i.price * (i.quantity || 0)), 0);

  if (cart.length === 0) return null;

  const handleCheckoutClick = () => {
    onCheckout(customerInfo);
  };

  return (
    <div id="cart" className="bg-white rounded-[40px] border border-gray-100 shadow-2xl p-8 mb-8 sticky top-24 max-h-[90vh] flex flex-col overflow-hidden">
      <div className="flex items-center justify-between mb-8 shrink-0">
        <h2 className="font-black text-blue-900 text-2xl flex items-center gap-3">
          <MdShoppingCart className="text-blue-600" /> Active Cart
        </h2>
        <span className="px-4 py-1.5 bg-blue-50 text-blue-600 rounded-full text-xs font-black uppercase tracking-widest">
          {totalItems} Items
        </span>
      </div>

      <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-8">
        {/* Cart Items */}
        <div className="space-y-4">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Items in Cart</p>
          {cart.map((item) => (
            <div key={item.id} className="p-5 bg-gray-50 rounded-3xl border border-gray-100 group transition hover:border-blue-100 hover:bg-white hover:shadow-xl hover:shadow-blue-100/20">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="font-black text-gray-900 text-sm leading-tight group-hover:text-blue-900 transition-colors">{item.name}</h3>
                  <div className="flex items-center gap-2 mt-1.5">
                     <p className="text-xs text-gray-400 font-bold tracking-tight">₹{item.price.toLocaleString()}</p>
                     <span className="text-[9px] font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full uppercase tracking-tighter">SKU: {item.sku}</span>
                  </div>
                </div>
                <button 
                  onClick={() => onRemoveItem(item.id)}
                  className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                >
                  <MdDelete size={20} />
                </button>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4 bg-white border border-gray-100 rounded-2xl px-3 py-1.5 shadow-sm">
                  <button 
                    onClick={() => onUpdateQuantity(item.id, -1)}
                    className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition"
                  >
                    <MdRemove size={18} />
                  </button>
                  <span className="text-sm font-black w-4 text-center text-blue-900">{item.quantity}</span>
                  <button 
                    onClick={() => onUpdateQuantity(item.id, 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition"
                  >
                    <MdAdd size={18} />
                  </button>
                </div>
                <p className="font-black text-gray-900 text-base tracking-tighter">₹{(item.price * item.quantity).toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Customer Information */}
        <div className="space-y-6 pt-4 border-t border-gray-50">
           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Customer Logistics</p>
           
           <div className="space-y-4">
              <div className="relative group">
                 <div className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-blue-600 transition-colors">
                    <MdPerson size={20} />
                 </div>
                 <input 
                   type="text" 
                   placeholder="Customer Name" 
                   className="w-full pl-14 pr-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-100 transition-all font-bold text-sm"
                   value={customerInfo.name}
                   onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                 />
              </div>

              <div className="relative group">
                 <div className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-blue-600 transition-colors">
                    <MdPhone size={20} />
                 </div>
                 <input 
                   type="text" 
                   placeholder="Contact Number" 
                   className="w-full pl-14 pr-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-100 transition-all font-bold text-sm"
                   value={customerInfo.contact}
                   onChange={(e) => setCustomerInfo({...customerInfo, contact: e.target.value})}
                 />
              </div>

              <div className="relative group">
                 <div className="absolute left-5 top-6 text-gray-300 group-focus-within:text-blue-600 transition-colors">
                    <MdLocationOn size={20} />
                 </div>
                 <textarea 
                   placeholder="Shipping Address" 
                   className="w-full pl-14 pr-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-100 transition-all font-bold text-sm min-h-[100px] resize-none"
                   value={customerInfo.address}
                   onChange={(e) => setCustomerInfo({...customerInfo, address: e.target.value})}
                 />
              </div>
           </div>

           <div className="space-y-3">
              <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest ml-1">Settlement Method</label>
              <div className="grid grid-cols-2 gap-3">
                 <button 
                   onClick={() => setCustomerInfo({...customerInfo, paymentMode: 'Cash'})}
                   className={`flex items-center justify-center gap-3 py-4 rounded-2xl border-2 font-black text-xs uppercase tracking-widest transition-all ${
                     customerInfo.paymentMode === 'Cash' ? 'bg-blue-900 border-blue-900 text-white shadow-lg shadow-blue-100' : 'bg-white border-gray-100 text-gray-400 hover:border-blue-600 hover:text-blue-600'
                   }`}
                 >
                    <MdWallet size={18} /> Cash
                 </button>
                 <button 
                   onClick={() => setCustomerInfo({...customerInfo, paymentMode: 'Online'})}
                   className={`flex items-center justify-center gap-3 py-4 rounded-2xl border-2 font-black text-xs uppercase tracking-widest transition-all ${
                     customerInfo.paymentMode === 'Online' ? 'bg-blue-900 border-blue-900 text-white shadow-lg shadow-blue-100' : 'bg-white border-gray-100 text-gray-400 hover:border-blue-600 hover:text-blue-600'
                   }`}
                 >
                    <MdPayment size={18} /> Online
                 </button>
              </div>
           </div>
        </div>
      </div>

      <div className="border-t border-gray-50 pt-8 mt-6 shrink-0">
        <div className="flex justify-between items-center mb-8">
           <div className="space-y-1">
              <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Total Settlement</p>
              <span className="text-3xl font-black text-blue-900 tracking-tighter leading-none">₹{totalAmount.toLocaleString()}</span>
           </div>
           <div className="text-right">
              <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Mode</p>
              <span className="text-sm font-black text-blue-600 uppercase tracking-widest">{customerInfo.paymentMode}</span>
           </div>
        </div>
        
        <button
          onClick={handleCheckoutClick}
          disabled={isProcessing}
          className="w-full flex items-center justify-center gap-4 bg-blue-900 text-white py-5 rounded-[24px] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95 disabled:opacity-50 group overflow-hidden relative"
        >
          <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
          <MdPayment size={22} className="group-hover:rotate-12 transition-transform" />
          {isProcessing ? 'Processing Terminal...' : 'Finalize & Generate Bill'}
        </button>
      </div>
    </div>
  );
};

export default CartPreview;
