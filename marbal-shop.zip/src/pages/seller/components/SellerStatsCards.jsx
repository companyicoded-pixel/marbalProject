import React from 'react';
import { MdAttachMoney, MdDescription, MdShoppingCart, MdHourglassTop } from 'react-icons/md';

/**
 * Props
 *   stats: {
 *     todaysSales: number,
 *     todaysBills: number,
 *     cartItems: number,
 *     pendingBills: number,
 *   }
 */
const SellerStatsCards = ({ stats }) => {
  const cards = [
    {
      label: "Today's Sales",
      value: `₹${stats.todaysSales?.toLocaleString() || 0}`,
      icon: MdAttachMoney,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      label: "Today's Bills",
      value: stats.todaysBills ?? 0,
      icon: MdDescription,
      color: 'bg-blue-900 text-white',
    },
    {
      label: "Cart Items",
      value: stats.cartItems ?? 0,
      icon: MdShoppingCart,
      color: 'bg-green-50 text-green-600',
    },
    {
      label: "Pending Bills",
      value: stats.pendingBills ?? 0,
      icon: MdHourglassTop,
      color: 'bg-orange-50 text-orange-600',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((c, i) => (
        <div
          key={i}
          className="bg-white p-6 rounded-[24px] border border-gray-100 shadow-sm flex items-center gap-4 hover:shadow-md transition"
        >
          <div className={`p-4 rounded-2xl ${c.color} shadow-sm`}>
            <c.icon size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest leading-none mb-1">{c.label}</p>
            <p className="text-2xl font-black text-gray-900 tracking-tight">{c.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SellerStatsCards;
