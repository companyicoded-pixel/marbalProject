import React from 'react';
import { MdQrCodeScanner, MdShoppingCart, MdDescription, MdHistory } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';

const QuickActions = () => {
  const navigate = useNavigate();

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const actions = [
    {
      label: 'Scan Product',
      icon: MdQrCodeScanner,
      onClick: () => scrollToSection('scanner'),
      color: 'bg-indigo-50 text-indigo-600',
    },
    {
      label: 'View Cart',
      icon: MdShoppingCart,
      onClick: () => scrollToSection('cart'),
      color: 'bg-green-50 text-green-600',
    },
    {
      label: 'Billing History',
      icon: MdHistory,
      onClick: () => navigate('/seller/history'),
      color: 'bg-amber-50 text-amber-600',
    },
    {
      label: 'My Profile',
      icon: MdDescription,
      onClick: () => navigate('/seller/profile'),
      color: 'bg-purple-50 text-purple-600',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">
      {actions.map((a, i) => (
        <button
          key={i}
          onClick={a.onClick}
          className="group flex flex-col items-center bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-xl hover:border-indigo-100 transition-all active:scale-95 text-center"
        >
          <div className={`p-4 rounded-2xl ${a.color} mb-3 group-hover:scale-110 transition-transform`}>
            <a.icon size={28} />
          </div>
          <span className="text-xs font-black text-gray-400 uppercase tracking-widest group-hover:text-indigo-600 transition">
            {a.label}
          </span>
        </button>
      ))}
    </div>
  );
};

export default QuickActions;
