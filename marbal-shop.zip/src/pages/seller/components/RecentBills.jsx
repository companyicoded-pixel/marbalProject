import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdReceipt, MdAccessTime, MdArrowForward } from 'react-icons/md';

const RecentBills = ({ sellerId }) => {
  const [bills, setBills] = useState([]);

  useEffect(() => {
    if (!sellerId) return;
    
    const q = query(
      collection(db, 'bills'),
      where('sellerId', '==', sellerId)
    );

    const unsub = onSnapshot(q, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      const sorted = data.sort((a, b) => {
        const timeA = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
        const timeB = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
        return timeB - timeA;
      });
      setBills(sorted.slice(0, 4));
    });

    return () => unsub();
  }, [sellerId]);

  const statusBadge = (status) => {
    const map = {
      pending: { bg: 'bg-orange-50 text-orange-500', label: 'In Review' },
      approved: { bg: 'bg-green-50 text-green-600', label: 'Completed' },
      rejected: { bg: 'bg-red-50 text-red-500', label: 'Disputed' },
    }[status] || { bg: 'bg-gray-50 text-gray-400', label: status };
    return (
      <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${map.bg}`}>
        {map.label}
      </span>
    );
  };

  if (bills.length === 0) return (
     <div className="bg-white rounded-[40px] border border-gray-100 p-12 text-center">
        <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-gray-200">
           <MdReceipt size={32} />
        </div>
        <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">No terminal history</p>
     </div>
  );

  return (
    <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden group hover:shadow-xl transition-all duration-500">
      <div className="px-10 py-8 border-b border-gray-50 flex justify-between items-center">
        <div className="flex items-center gap-3">
           <MdAccessTime className="text-blue-600" size={20} />
           <h2 className="font-black text-blue-900 text-lg tracking-tight">Recent Activity</h2>
        </div>
        <MdArrowForward className="text-gray-200 group-hover:text-blue-600 transition-colors" size={20} />
      </div>
      <div className="p-4 space-y-2">
         {bills.map(b => (
           <div key={b.id} className="p-6 rounded-[28px] hover:bg-gray-50 transition-colors flex items-center justify-between group/item">
              <div className="flex items-center gap-5">
                 <div className="w-12 h-12 bg-gray-50 text-gray-400 rounded-2xl flex items-center justify-center font-black text-[10px] group-hover/item:bg-blue-900 group-hover/item:text-white transition-all">
                    #{b.id.slice(0, 2).toUpperCase()}
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest leading-none mb-1">Settlement</p>
                    <p className="text-base font-black text-gray-900 tracking-tighter">₹{b.totalAmount?.toLocaleString()}</p>
                 </div>
              </div>
              <div className="text-right">
                 {statusBadge(b.status)}
                 <p className="text-[9px] font-bold text-gray-300 mt-1.5 uppercase tracking-tighter">
                   {b.createdAt?.toDate ? b.createdAt.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Just now'}
                 </p>
              </div>
           </div>
         ))}
      </div>
    </div>
  );
};

export default RecentBills;
