import React from 'react';
import { MdQrCodeScanner } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';

/**
 * A large, prominent button that navigates to the QR scanner section.
 * Can be placed anywhere on the seller dashboard.
 */
const ScannerButton = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    // The scanner lives on the main dashboard, we simply scroll to it.
    // Using hash navigation for smooth scroll.
    navigate('/seller#scanner');
  };

  return (
    <button
      onClick={handleClick}
      className="w-full flex items-center justify-center gap-3 py-4 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-lg hover:bg-indigo-700 transition"
    >
      <MdQrCodeScanner size={24} />
      Scan QR Code
    </button>
  );
};

export default ScannerButton;
