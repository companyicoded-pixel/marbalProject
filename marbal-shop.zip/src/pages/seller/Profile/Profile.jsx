import React from 'react';
import { useAuth } from '../../../context/AuthContext';
import { MdPerson, MdEmail, MdSecurity, MdHistory, MdWork } from 'react-icons/md';

const Profile = () => {
  const { user, role } = useAuth();

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-10">
        <h1 className="text-4xl font-black text-gray-900 tracking-tight">My Profile</h1>
        <p className="text-sm text-gray-400 font-bold mt-1 uppercase tracking-widest">Manage your personal information</p>
      </div>

      <div className="bg-white rounded-[32px] shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-indigo-600 h-32 relative">
          <div className="absolute -bottom-12 left-8 w-24 h-24 bg-white rounded-3xl shadow-lg border-4 border-white flex items-center justify-center text-indigo-600 font-black text-3xl">
            {user?.email?.charAt(0).toUpperCase()}
          </div>
        </div>
        
        <div className="pt-16 px-8 pb-8">
          <div className="mb-8">
            <h2 className="text-2xl font-black text-gray-900">{user?.email?.split('@')[0]}</h2>
            <p className="text-sm text-indigo-600 font-bold uppercase tracking-widest">{role}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="p-3 bg-white rounded-xl text-indigo-600 shadow-sm"><MdEmail size={20} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Email Address</p>
                  <p className="text-sm font-bold text-gray-800">{user?.email}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="p-3 bg-white rounded-xl text-indigo-600 shadow-sm"><MdSecurity size={20} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">User ID</p>
                  <p className="text-xs font-mono text-gray-500">{user?.uid}</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="p-3 bg-white rounded-xl text-indigo-600 shadow-sm"><MdWork size={20} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Account Type</p>
                  <p className="text-sm font-bold text-gray-800">Operational Seller</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="p-3 bg-white rounded-xl text-indigo-600 shadow-sm"><MdHistory size={20} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Last Activity</p>
                  <p className="text-sm font-bold text-gray-800">Just Now</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
