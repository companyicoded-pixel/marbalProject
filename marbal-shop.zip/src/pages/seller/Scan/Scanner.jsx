import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import toast from 'react-hot-toast';

const Scanner = ({ onProductScanned }) => {
  const scannerRef = useRef(null);

  useEffect(() => {
    const scanner = new Html5QrcodeScanner(
      'qr-reader',
      { fps: 10, qrbox: { width: 250, height: 250 } },
      false
    );

    const onSuccess = async (decodedText) => {
      try {
        // Try by productId first, then by SKU
        const productDoc = await getDoc(doc(db, 'products', decodedText));

        if (productDoc.exists()) {
          const product = { id: productDoc.id, ...productDoc.data() };

          // Stock validation before adding to cart
          if ((product.quantity || 0) <= 0) {
            toast.error(`"${product.name}" is out of stock!`);
            return;
          }

          if ((product.quantity || 0) < 5) {
            toast.error(`⚠ Low Stock Alert: Only ${product.quantity} left!`, { duration: 4000 });
          }

          onProductScanned(product);
          toast.success(`✅ ${product.name} added to cart!`);
        } else {
          toast.error('Product not found in inventory');
        }
      } catch (err) {
        toast.error('Scan error. Try again.');
      }
    };

    const onError = () => {};

    scanner.render(onSuccess, onError);
    scannerRef.current = scanner;

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(() => {});
      }
    };
  }, []);

  return (
    <div className="rounded-2xl overflow-hidden bg-white shadow-lg">
      <div id="qr-reader" className="w-full" />
    </div>
  );
};

export default Scanner;
