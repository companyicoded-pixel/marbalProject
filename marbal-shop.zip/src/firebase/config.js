import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Updated Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDhXwUY9GWDUihdyLDRGmDUuclMsMuRSBs",
  authDomain: "sandhya-mang.firebaseapp.com",
  databaseURL: "https://sandhya-mang-default-rtdb.firebaseio.com",
  projectId: "sandhya-mang",
  storageBucket: "sandhya-mang.firebasestorage.app",
  messagingSenderId: "177779159902",
  appId: "1:177779159902:web:96d5563b603d2346f295cf",
  measurementId: "G-HP178LJ1RP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);

export { app, analytics, db, auth };
