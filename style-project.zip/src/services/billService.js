import {
  collection, addDoc, getDocs, updateDoc, deleteDoc,
  doc, serverTimestamp, increment, getDoc
} from 'firebase/firestore';
import { db } from '../firebase/config';

// ─── BILL CATEGORIES ────────────────────────────────────────
export const BILL_CATEGORIES = ['Nature', 'Engineer', 'Architect', 'General'];

// ─── CREATE BILL ────────────────────────────────────────────
export const createBill = async (billData) => {
  try {
    const docRef = await addDoc(collection(db, 'bills'), {
      sellerId: billData.sellerId,
      sellerName: billData.sellerName,
      items: billData.items,
      totalAmount: billData.totalAmount,
      category: billData.category || 'General',
      note: billData.note || '',
      status: 'pending',
      createdAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    throw error;
  }
};

// ─── APPROVE BILL → Reduce Stock + Create History ───────────
export const approveBill = async (billId, items, approvedBy) => {
  try {
    const billRef = doc(db, 'bills', billId);
    await updateDoc(billRef, {
      status: 'approved',
      approvedAt: serverTimestamp(),
      approvedBy: approvedBy || 'admin',
    });

    for (const item of items) {
      // Reduce product quantity
      const productRef = doc(db, 'products', item.id);
      await updateDoc(productRef, {
        quantity: increment(-item.quantity),
        stock: increment(-item.quantity),
      });

      // Create stock history record (OUT)
      await addDoc(collection(db, 'stockHistory'), {
        productId: item.id,
        productName: item.name,
        type: 'OUT',
        quantity: item.quantity,
        updatedBy: approvedBy || 'admin',
        billId: billId,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    throw error;
  }
};

// ─── REJECT BILL ─────────────────────────────────────────────
export const rejectBill = async (billId, rejectedBy, note) => {
  try {
    const billRef = doc(db, 'bills', billId);
    await updateDoc(billRef, {
      status: 'rejected',
      rejectedAt: serverTimestamp(),
      rejectedBy: rejectedBy || 'admin',
      rejectionNote: note || '',
    });
  } catch (error) {
    throw error;
  }
};

// ─── GET ALL BILLS ───────────────────────────────────────────
export const getBills = async () => {
  try {
    const snapshot = await getDocs(collection(db, 'bills'));
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (error) {
    throw error;
  }
};
