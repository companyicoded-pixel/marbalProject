import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase/config';

// ─── PDF INVOICE (per bill) ──────────────────────────────────
export const generateInvoice = (bill) => {
  const doc = new jsPDF();

  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('MARBLE PRO', 105, 15, { align: 'center' });
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text('TAX INVOICE', 105, 22, { align: 'center' });

  doc.setDrawColor(0, 69, 139);
  doc.setLineWidth(0.8);
  doc.line(14, 26, 196, 26);

  doc.setFontSize(9);
  doc.text(`Invoice ID: #${bill.id}`, 14, 33);
  doc.text(`Date: ${bill.approvedAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(bill.approvedAt.toDate()) : new Date().toLocaleDateString()}`, 14, 39);
  doc.text(`Seller: ${bill.sellerName || 'Staff'}`, 14, 45);
  doc.text(`Category: ${bill.category || 'General'}`, 14, 51);
  doc.text(`Status: ${bill.status?.toUpperCase()}`, 150, 33);

  const tableColumn = ['Product', 'SKU', 'Price', 'Qty', 'Subtotal'];
  const tableRows = (bill.items || []).map(item => [
    item.name,
    item.sku || item.id?.slice(0, 8),
    `₹${parseFloat(item.price).toFixed(2)}`,
    item.quantity,
    `₹${(item.price * item.quantity).toFixed(2)}`,
  ]);

  doc.autoTable({
    startY: 60,
    head: [tableColumn],
    body: tableRows,
    theme: 'grid',
    headStyles: { fillColor: [0, 69, 139], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [245, 245, 255] },
  });

  const finalY = doc.lastAutoTable.finalY + 10;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(`Grand Total: ₹${parseFloat(bill.totalAmount).toFixed(2)}`, 140, finalY);

  if (bill.note) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Note: ${bill.note}`, 14, finalY);
  }

  doc.setFontSize(8);
  doc.setTextColor(150);
  doc.text('Thank you for your business! — Marble Pro Terminal', 105, finalY + 20, { align: 'center' });

  doc.save(`Invoice_${bill.id.slice(0, 8)}.pdf`);
};

// ─── MASTER DOWNLOAD HANDLERS ────────────────────────────────
export const downloadInventoryReport = async (format = 'pdf') => {
  try {
    const snapshot = await getDocs(collection(db, 'products'));
    const products = snapshot.docs.map(d => d.data());
    
    if (format === 'pdf') {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('INVENTORY MASTER REPORT', 105, 15, { align: 'center' });
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 24);

      doc.autoTable({
        startY: 30,
        head: [['Product', 'SKU', 'Category', 'Price', 'Stock', 'Status']],
        body: products.map(p => [
          p.name, p.sku || 'N/A', p.category || 'N/A',
          `₹${p.price}`, p.quantity,
          p.quantity < 10 ? 'LOW' : 'OK'
        ]),
        theme: 'grid',
        headStyles: { fillColor: [0, 69, 139] },
      });
      doc.save('Inventory_Report.pdf');
    } else {
      const data = products.map(p => ({
        Name: p.name, SKU: p.sku || 'N/A', Category: p.category || 'N/A',
        Price: p.price, Stock: p.quantity, Status: p.quantity < 10 ? 'LOW STOCK' : 'OK'
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Inventory');
      XLSX.writeFile(wb, 'Inventory_Report.xlsx');
    }
  } catch (error) {
    console.error(error);
  }
};

export const downloadBillingReport = async (format = 'pdf') => {
  try {
    const q = query(collection(db, 'bills'), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const bills = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

    if (format === 'pdf') {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('REVENUE & BILLING LEDGER', 105, 15, { align: 'center' });
      doc.setFontSize(9);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 24);

      doc.autoTable({
        startY: 30,
        head: [['Bill ID', 'Seller', 'Category', 'Amount', 'Status', 'Date']],
        body: bills.map(b => [
          b.id.slice(0, 8), b.sellerName || 'N/A', b.category || 'General',
          `₹${b.totalAmount}`, b.status,
          b.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(b.createdAt.toDate()) : 'N/A'
        ]),
        theme: 'grid',
        headStyles: { fillColor: [0, 69, 139] },
      });
      doc.save('Billing_Report.pdf');
    } else {
      const data = bills.map(b => ({
        'Bill ID': b.id.slice(0, 8), Seller: b.sellerName || 'N/A',
        Category: b.category || 'General', Amount: b.totalAmount,
        Status: b.status,
        Date: b.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(b.createdAt.toDate()) : 'N/A'
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Bills');
      XLSX.writeFile(wb, 'Billing_Report.xlsx');
    }
  } catch (error) {
    console.error(error);
  }
};
