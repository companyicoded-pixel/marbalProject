import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logout } from '../services/authService';
import { 
  MdDashboard, 
  MdInventory, 
  MdHistory, 
  MdReceipt, 
  MdPeople, 
  MdAssessment, 
  MdSettings, 
  MdLogout,
  MdShoppingCart,
  MdTrendingDown,
  MdMenu,
  MdNotifications,
  MdPerson,
  MdLock,
  MdChevronRight
} from 'react-icons/md';
import ExpensesPage from '../pages/admin/Expenses/ExpensesPage';

import Login from '../pages/auth/Login';
import Register from '../pages/auth/Register';

// Admin Pages
import AdminDashboard from '../pages/admin/Dashboard/AdminDashboard';
import AddProduct from '../pages/admin/Products/AddProduct';
import ProductList from '../pages/admin/Products/ProductList';
import ReviewBills from '../pages/admin/Bills/ReviewBills';
import StockHistory from '../pages/admin/StockHistory/StockHistory';
import UsersPage from '../pages/admin/Users/UsersPage';
import ReportsPage from '../pages/admin/Reports/ReportsPage';
import SettingsPage from '../pages/admin/Settings/SettingsPage';

// Seller Pages
import SellerDashboard from '../pages/seller/Dashboard/SellerDashboard';
import BillingHistory from '../pages/seller/Bills/BillingHistory';
import Profile from '../pages/seller/Profile/Profile';

const SidebarLink = ({ to, icon: Icon, label, badge, hasSubmenu }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link 
      to={to} 
      className={`flex items-center justify-between px-6 py-2.5 text-[13px] font-medium transition-all duration-150 ${
        isActive 
          ? 'bg-[#EBF2FF] text-blue-700' 
          : 'text-gray-500 hover:text-blue-700 hover:bg-gray-50'
      }`}
    >
      <div className="flex items-center gap-3">
        <Icon size={18} className={isActive ? 'text-blue-700' : 'text-gray-400'} />
        <span>{label}</span>
      </div>
      <div className="flex items-center gap-2">
        {badge && (
          <span className="bg-red-500 text-white px-1.5 py-0.5 rounded text-[10px] font-bold min-w-[20px] text-center">
            {badge}
          </span>
        )}
        {hasSubmenu && (
           <MdChevronRight className={`text-gray-300 transition-transform ${isActive ? 'rotate-90' : ''}`} size={16} />
        )}
      </div>
    </Link>
  );
};

const Layout = ({ children }) => {
  const { user, role } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col md:flex-row relative">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between px-6 py-4 bg-white border-b border-gray-100 sticky top-0 z-50">
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 bg-[#0D8ABC] rounded-lg flex items-center justify-center text-white font-black text-lg">L</div>
           <span className="text-xl font-black text-[#0D8ABC] tracking-tighter">LOGO</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gray-500">
          <MdMenu size={28} />
        </button>
      </div>

      {/* Sidebar Overlay for Mobile */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside className={`
        fixed md:sticky top-0 left-0 z-[70] h-screen w-64 bg-white border-r border-gray-100 flex flex-col
        transition-transform duration-300 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="px-8 py-8 flex items-center justify-between hidden md:flex">
          <div className="flex items-center gap-2">
             <div className="w-9 h-9 bg-[#0D8ABC] rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-100">L</div>
             <span className="text-2xl font-black text-[#0D8ABC] tracking-tighter">LOGO</span>
          </div>
        </div>

        {/* User Profile Section */}
        <div className="px-4 mb-6 mt-4 md:mt-0">
           <div className="flex items-center gap-3 p-3.5 bg-[#f8fafc] border border-gray-50 rounded-2xl shadow-sm">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-white shadow-sm shrink-0">
                 <img src={`https://ui-avatars.com/api/?name=${user?.email}&background=EBF2FF&color=0D8ABC`} alt="user" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                 <p className="text-[13px] font-bold text-gray-900 truncate leading-tight mb-0.5">{user?.email?.split('@')[0]}</p>
                 <p className="text-[11px] text-gray-400 font-medium capitalize">{role}</p>
              </div>
              <div className="relative p-1 shrink-0">
                 <MdNotifications size={20} className="text-gray-300" />
                 <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-red-500 text-white text-[8px] font-black rounded-full flex items-center justify-center border-2 border-white">10</span>
              </div>
           </div>
        </div>

        <nav className="flex-1 overflow-y-auto custom-scrollbar py-2 space-y-0.5">
          {role === 'admin' ? (
            <>
              <div className="px-7 py-3 text-[10px] font-bold text-gray-300 uppercase tracking-[0.2em] opacity-80">Operations</div>
              <SidebarLink to="/admin" icon={MdDashboard} label="Dashboard" />
              <SidebarLink to="/admin/inventory" icon={MdInventory} label="Products" hasSubmenu />
              <SidebarLink to="/admin/history" icon={MdHistory} label="Stock History" hasSubmenu />
              <SidebarLink to="/admin/review-bills" icon={MdReceipt} label="Bill Approvals" badge="5" hasSubmenu />
              <SidebarLink to="/admin/expenses" icon={MdTrendingDown} label="Expenses" hasSubmenu />
              
              <div className="px-7 py-5 text-[10px] font-bold text-gray-300 uppercase tracking-[0.2em] opacity-80">Management</div>
              <SidebarLink to="/admin/users" icon={MdPeople} label="Staff Accounts" badge="32+" hasSubmenu />
              <SidebarLink to="/admin/reports" icon={MdAssessment} label="Reports" hasSubmenu />
              <SidebarLink to="/admin/settings" icon={MdSettings} label="Settings" />
            </>
          ) : (
            <>
              <div className="px-7 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] opacity-60">Terminal</div>
              <SidebarLink to="/seller" icon={MdDashboard} label="Sales Dashboard" />
              <SidebarLink to="/seller/history" icon={MdHistory} label="Billing History" hasSubmenu />
              <SidebarLink to="/seller/profile" icon={MdPerson} label="My Profile" />
            </>
          )}
        </nav>

        <div className="p-4 border-t border-gray-50 mt-auto">
          <button 
            onClick={() => logout()}
            className="flex items-center gap-3 w-full px-6 py-3 text-[13px] font-bold text-gray-400 hover:text-red-500 transition-colors group"
          >
            <MdLogout size={18} className="group-hover:translate-x-1 transition-transform" />
            <span>Logout Account</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-x-hidden h-screen bg-[#f8fafc] w-full">
        {children}
      </main>
    </div>
  );
};

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, role, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(role)) return <Navigate to="/" />;
  return <Layout>{children}</Layout>;
};

const AppRoutes = () => {
  const { role } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      {/* Admin Routes */}
      <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/inventory" element={<ProtectedRoute allowedRoles={['admin']}><ProductList /></ProtectedRoute>} />
      <Route path="/admin/add-product" element={<ProtectedRoute allowedRoles={['admin']}><AddProduct /></ProtectedRoute>} />
      <Route path="/admin/review-bills" element={<ProtectedRoute allowedRoles={['admin']}><ReviewBills /></ProtectedRoute>} />
      <Route path="/admin/history" element={<ProtectedRoute allowedRoles={['admin']}><StockHistory /></ProtectedRoute>} />
      <Route path="/admin/users" element={<ProtectedRoute allowedRoles={['admin']}><UsersPage /></ProtectedRoute>} />
      <Route path="/admin/reports" element={<ProtectedRoute allowedRoles={['admin']}><ReportsPage /></ProtectedRoute>} />
      <Route path="/admin/settings" element={<ProtectedRoute allowedRoles={['admin']}><SettingsPage /></ProtectedRoute>} />
      <Route path="/admin/expenses" element={<ProtectedRoute allowedRoles={['admin']}><ExpensesPage /></ProtectedRoute>} />
      
      {/* Seller Routes */}
      <Route path="/seller" element={<ProtectedRoute allowedRoles={['seller']}><SellerDashboard /></ProtectedRoute>} />
      <Route path="/seller/history" element={<ProtectedRoute allowedRoles={['seller']}><BillingHistory /></ProtectedRoute>} />
      <Route path="/seller/profile" element={<ProtectedRoute allowedRoles={['seller']}><Profile /></ProtectedRoute>} />
      
      <Route path="/" element={
        role === 'admin' ? <Navigate to="/admin" /> : 
        role === 'seller' ? <Navigate to="/seller" /> : 
        <Navigate to="/login" />
      } />
    </Routes>
  );
};

export default AppRoutes;
