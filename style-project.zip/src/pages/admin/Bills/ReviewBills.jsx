import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { approveBill, rejectBill, BILL_CATEGORIES } from '../../../services/billService';
import { generateInvoice } from '../../../services/reportService';
import toast from 'react-hot-toast';
import { MdCheck, MdClose, MdVisibility, MdFilterList, MdSearch } from 'react-icons/md';

const ReviewBills = () => {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [categoryFilter, setCategoryFilter] = useState('All');

  useEffect(() => {
    const q = query(collection(db, 'bills'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setBills(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleApprove = async (bill) => {
    try {
      await approveBill(bill.id, bill.items, 'Admin');
      toast.success('Bill Approved & Stock Updated');
      generateInvoice(bill);
    } catch { toast.error('Approval failed'); }
  };

  const handleReject = async (id) => {
    const note = window.prompt('Enter rejection reason:');
    if (note === null) return;
    try {
      await rejectBill(id, 'Admin', note);
      toast.success('Bill Rejected');
    } catch { toast.error('Rejection failed'); }
  };

  const filtered = bills.filter(b => 
    (filter === 'all' || b.status === filter) && 
    (categoryFilter === 'All' || b.category === categoryFilter)
  );

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      {/* Header matching image style */}
      <div className="px-10 py-10 search-container shrink-0">
        <h1 className="text-2xl font-black text-blue-900 mb-2">Billing Ledger & Approvals</h1>
        <p className="text-sm text-gray-500 mb-8">Audit and authorize pending transactions from staff terminals.</p>

        <div className="flex flex-wrap gap-3 bg-white p-2 rounded-xl shadow-sm border border-gray-100 items-center max-w-4xl">
          <div className="flex-1 flex items-center gap-3 px-4 py-2 border-r border-gray-50">
            <MdFilterList className="text-gray-400" size={20} />
            <select 
              className="w-full text-sm outline-none font-bold text-gray-600 bg-transparent"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="pending">Pending Approvals</option>
              <option value="approved">Approved Ledger</option>
              <option value="rejected">Rejected Entries</option>
              <option value="all">Complete History</option>
            </select>
          </div>
          
          <select 
            className="px-6 py-2 text-sm font-bold text-gray-500 outline-none border-r border-gray-50 bg-transparent"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="All">All Categories</option>
            {BILL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>

          <button className="bg-blue-900 text-white px-8 py-3 rounded-lg font-bold text-sm shadow-lg hover:bg-blue-800 transition">
            Filter Ledger
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Reference</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Staff / Date</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Category</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Amount</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map(bill => (
                <tr key={bill.id} className="hover:bg-blue-50/20 transition group">
                  <td className="px-8 py-6">
                    <p className="font-mono text-[10px] font-black text-gray-400">#{bill.id.slice(0, 12).toUpperCase()}</p>
                    <span className={`mt-1 inline-block px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${
                      bill.status === 'approved' ? 'bg-green-100 text-green-700' :
                      bill.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'
                    }`}>{bill.status}</span>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-sm font-bold text-gray-800">{bill.sellerName?.split('@')[0]}</p>
                    <p className="text-[10px] text-gray-400 font-medium">{bill.createdAt?.toDate().toLocaleDateString()}</p>
                  </td>
                  <td className="px-8 py-6 text-xs font-bold text-gray-500 uppercase tracking-wider">{bill.category}</td>
                  <td className="px-8 py-6 font-black text-blue-800 text-lg">₹{bill.totalAmount.toLocaleString()}</td>
                  <td className="px-8 py-6 text-right">
                    {bill.status === 'pending' ? (
                      <div className="flex justify-end gap-2">
                        <button onClick={() => handleApprove(bill)} className="p-2.5 bg-green-50 text-green-600 rounded-xl hover:bg-green-600 hover:text-white transition shadow-sm"><MdCheck size={20} /></button>
                        <button onClick={() => handleReject(bill.id)} className="p-2.5 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition shadow-sm"><MdClose size={20} /></button>
                      </div>
                    ) : (
                      <button onClick={() => generateInvoice(bill)} className="p-2.5 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition shadow-sm"><MdVisibility size={20} /></button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-20 text-center">
              <p className="text-gray-400 font-bold uppercase text-xs tracking-[0.2em]">No entries match your filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReviewBills;
