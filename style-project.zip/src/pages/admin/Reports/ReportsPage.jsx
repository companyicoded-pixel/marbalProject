import React from 'react';
import { 
  MdAssessment, MdFileDownload, MdTrendingUp, 
  MdPieChart, MdDescription, MdTableChart 
} from 'react-icons/md';
import { downloadBillingReport, downloadInventoryReport } from '../../../services/reportService';

const ReportCard = ({ title, desc, icon: Icon, onDownload, type }) => (
  <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 group">
    <div className="flex justify-between items-start mb-8">
      <div className="p-5 bg-slate-50 text-slate-900 rounded-[24px] group-hover:bg-indigo-600 group-hover:text-white transition-colors">
        <Icon size={32} />
      </div>
      <span className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-300 group-hover:text-indigo-400 transition-colors">
        {type}
      </span>
    </div>
    <h3 className="text-2xl font-black text-slate-900 tracking-tight mb-2">{title}</h3>
    <p className="text-[11px] text-slate-400 font-medium leading-relaxed mb-8">{desc}</p>
    <div className="flex gap-2">
      <button 
        onClick={() => onDownload('pdf')}
        className="flex-1 bg-slate-900 text-white py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-slate-100 hover:bg-indigo-600 transition active:scale-95 flex items-center justify-center gap-2"
      >
        <MdFileDownload size={16} /> PDF
      </button>
      <button 
        onClick={() => onDownload('excel')}
        className="flex-1 border-2 border-slate-100 text-slate-900 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:border-green-500 hover:text-green-600 transition active:scale-95 flex items-center justify-center gap-2"
      >
        <MdTableChart size={16} /> Excel
      </button>
    </div>
  </div>
);

const ReportsPage = () => {
  return (
    <div className="p-8 lg:p-12 max-w-6xl mx-auto h-screen overflow-y-auto custom-scrollbar">
      <div className="mb-12">
        <h1 className="text-4xl font-black text-slate-900 tracking-tighter">Business Analytics</h1>
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mt-1">Intelligence & Reporting Terminal</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <ReportCard 
          title="Revenue Ledger" 
          desc="Comprehensive breakdown of all approved bills, taxations, and total income generated across all staff terminals."
          icon={MdTrendingUp}
          type="Financial"
          onDownload={(format) => downloadBillingReport(format)}
        />
        <ReportCard 
          title="Inventory Matrix" 
          desc="Complete audit of marble stock, category-wise distribution, low-stock warnings, and valuation of current warehouse."
          icon={MdPieChart}
          type="Stock Control"
          onDownload={(format) => downloadInventoryReport(format)}
        />
        <ReportCard 
          title="Expense Audit" 
          desc="Detailed track of business outflow, including utilities, rent, and staff salaries for overhead analysis."
          icon={MdAssessment}
          type="Expenditure"
          onDownload={() => alert('Expense report generation coming in next update')}
        />
        <ReportCard 
          title="Sales Performance" 
          desc="Metric-based evaluation of staff performance, terminal efficiency, and high-demand product categories."
          icon={MdDescription}
          type="Operational"
          onDownload={() => alert('Sales performance metrics available on live dashboard')}
        />
      </div>

      <div className="mt-12 p-10 bg-indigo-600 rounded-[40px] text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl shadow-indigo-100">
        <div className="max-w-md">
          <h2 className="text-3xl font-black tracking-tight mb-2">Automated Insights</h2>
          <p className="text-indigo-100 text-sm font-medium opacity-80 leading-relaxed">
            Our system processes live transaction data to provide you with real-time business health indices. No manual calculation needed.
          </p>
        </div>
        <div className="flex gap-4">
           <div className="text-center bg-indigo-500/30 px-6 py-4 rounded-3xl border border-indigo-400/30">
              <p className="text-2xl font-black tracking-tighter">99.9%</p>
              <p className="text-[9px] font-black uppercase tracking-widest opacity-60">Accuracy</p>
           </div>
           <div className="text-center bg-indigo-500/30 px-6 py-4 rounded-3xl border border-indigo-400/30">
              <p className="text-2xl font-black tracking-tighter">Live</p>
              <p className="text-[9px] font-black uppercase tracking-widest opacity-60">Sync</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;
