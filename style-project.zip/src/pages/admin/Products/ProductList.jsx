import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { deleteProduct } from '../../../services/productService';
import toast from 'react-hot-toast';
import AddProductModal from './AddProductModal';
import EditProductModal from './EditProductModal';
import ProductTile from './ProductTile';
import { MdSearch, MdFilterList, MdAdd, MdViewModule, MdViewList, MdMap } from 'react-icons/md';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="p-8">Loading Inventory...</div>;

  return (
    <div className="h-full flex flex-col bg-[#f8fafc]">
      {/* Search Header from Image */}
      <div className="px-10 py-12 search-container shrink-0">
        <h1 className="text-2xl font-black text-blue-900 mb-2">Inventory Management</h1>
        <p className="text-sm text-gray-500 mb-8 max-w-2xl">
          Manage your marble stock across warehouses. Currently tracking <span className="text-blue-600 font-bold">{products.length}+</span> active SKUs in the system.
        </p>

        <div className="flex flex-wrap gap-3 bg-white p-2 rounded-xl shadow-sm border border-gray-100 items-center">
          <div className="flex-1 flex items-center gap-3 px-4 py-2 border-r border-gray-50 min-w-[200px]">
            <MdSearch className="text-gray-400" size={20} />
            <input 
              type="text" 
              placeholder="Search by Name, Category, SKU" 
              className="w-full text-sm outline-none font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <select className="px-4 py-2 text-sm font-medium text-gray-500 outline-none border-r border-gray-50 bg-transparent">
            <option>Select Types</option>
            <option>Marble</option>
            <option>Granite</option>
            <option>Quartz</option>
          </select>

          <select className="px-4 py-2 text-sm font-medium text-gray-500 outline-none border-r border-gray-50 bg-transparent">
            <option>Price Range</option>
            <option>Low to High</option>
            <option>High to Low</option>
          </select>

          <button className="p-2 text-gray-400 hover:text-blue-600">
            <MdFilterList size={20} />
          </button>

          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-900 text-white px-8 py-3 rounded-lg font-bold text-sm shadow-lg hover:bg-blue-800 transition"
          >
            Search
          </button>
          
          <button onClick={() => setIsAddModalOpen(true)} className="p-2 text-gray-400 border border-gray-100 rounded-lg hover:bg-gray-50 transition">
             <MdAdd size={24} />
          </button>
        </div>
      </div>

      {/* Grid Content */}
      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="flex justify-between items-center mb-8">
           <div className="flex gap-2 p-1 bg-gray-100 rounded-lg">
              <button className="bg-white text-blue-700 px-4 py-1.5 rounded-md text-xs font-bold flex items-center gap-2 shadow-sm">
                 <MdViewModule /> Tile
              </button>
              <button className="text-gray-500 px-4 py-1.5 text-xs font-bold flex items-center gap-2">
                 <MdViewList /> List
              </button>
              <button className="text-gray-500 px-4 py-1.5 text-xs font-bold flex items-center gap-2">
                 <MdMap /> Map
              </button>
           </div>
           <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-gray-400">Total Found: {filteredProducts.length}</span>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
           {filteredProducts.map(product => (
             <ProductTile 
               key={product.id} 
               product={product} 
               onEdit={(p) => { setSelectedProduct(p); setIsEditModalOpen(true); }}
             />
           ))}
        </div>
      </div>

      {/* Modals */}
      <AddProductModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onProductAdded={() => {}} // Modal now handles its own success UI
      />
      <EditProductModal 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)} 
        product={selectedProduct}
        onProductUpdated={() => setIsEditModalOpen(false)}
      />
    </div>
  );
};

export default ProductList;
