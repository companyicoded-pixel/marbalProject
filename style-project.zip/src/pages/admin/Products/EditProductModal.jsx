import React, { useState, useEffect } from 'react';
import { updateProduct } from '../../../services/productService';
import toast from 'react-hot-toast';
import { MdEdit, MdClose, MdSave } from 'react-icons/md';

const EditProductModal = ({ isOpen, onClose, product, onProductUpdated }) => {
  const [formData, setFormData] = useState({
    name: '', price: '', quantity: '', category: '', description: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || '',
        price: product.price || '',
        quantity: product.quantity || '',
        category: product.category || '',
        description: product.description || ''
      });
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProduct(product.id, {
        ...formData,
        price: parseFloat(formData.price),
        quantity: parseInt(formData.quantity)
      });
      toast.success('Inventory Synchronized');
      onProductUpdated();
      onClose();
    } catch { toast.error('Sync failed'); } finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-blue-900/40 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl p-10 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-blue-600"></div>
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
             <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><MdEdit size={24} /></div>
             <h2 className="text-2xl font-black text-gray-900 tracking-tight">Modify SKU</h2>
          </div>
          <button onClick={onClose} className="p-2 text-gray-300 hover:text-gray-600 transition"><MdClose size={24} /></button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-5">
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1.5 ml-1">Product Description</label>
              <input
                type="text" required
                className="w-full px-5 py-3.5 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-2 focus:ring-blue-600 outline-none font-bold text-sm transition"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="grid grid-cols-2 gap-5">
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1.5 ml-1">Market Price (₹)</label>
                <input
                  type="number" step="0.01" required
                  className="w-full px-5 py-3.5 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-2 focus:ring-blue-600 outline-none font-bold text-sm transition"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1.5 ml-1">Stock Quantity</label>
                <input
                  type="number" required
                  className="w-full px-5 py-3.5 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-2 focus:ring-blue-600 outline-none font-bold text-sm transition"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                />
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1.5 ml-1">Category Classification</label>
              <select
                className="w-full px-5 py-3.5 border border-gray-100 rounded-2xl bg-gray-50 focus:ring-2 focus:ring-blue-600 outline-none font-bold text-sm transition"
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
              >
                <option value="Marble">Marble</option>
                <option value="Granite">Granite</option>
                <option value="Quartz">Quartz</option>
                <option value="Tiles">Tiles</option>
              </select>
            </div>
          </div>
          
          <button
            type="submit" disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-blue-900 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-800 transition active:scale-95 disabled:opacity-50 mt-4"
          >
            <MdSave size={20} />
            {loading ? 'Processing...' : 'Synchronize Data'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditProductModal;
