import React from 'react';
import { MdLocationOn, MdShare, MdFullscreen, MdCircle } from 'react-icons/md';

const ProductTile = ({ product, onEdit, onDelete }) => {
  const isLowStock = (product.quantity || 0) < 10;

  return (
    <div className="bg-white rounded-xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-all group">
      {/* Image Area */}
      <div className="relative h-48 bg-gray-100 overflow-hidden">
        <img 
          src={`https://source.unsplash.com/400x300/?marble,stone,${product.category || 'texture'}`} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span className={`flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-bold ${
            isLowStock ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'
          }`}>
            <MdCircle size={8} />
            {isLowStock ? 'Low Stock' : 'Available'}
          </span>
        </div>
        <button className="absolute top-3 right-3 p-1.5 bg-white/80 backdrop-blur rounded-full text-gray-400 hover:text-blue-600 transition">
           <div className="w-4 h-4 border-2 border-current rounded-sm"></div>
        </button>
      </div>

      {/* Content Area */}
      <div className="p-5">
        <div className="flex items-center gap-1 text-gray-400 text-[10px] font-medium mb-1">
          <MdLocationOn size={14} />
          <span>Section A, Warehouse 1</span>
        </div>
        <h3 className="text-sm font-bold text-gray-900 mb-4">{product.name}</h3>

        <div className="grid grid-cols-3 gap-2 mb-6 border-b border-gray-50 pb-4">
           <div>
              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">Category</p>
              <p className="text-[11px] font-bold text-gray-700">{product.category || 'General'}</p>
           </div>
           <div>
              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">Quantity</p>
              <p className="text-[11px] font-bold text-gray-700">{product.quantity} Units</p>
           </div>
           <div>
              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">SKU</p>
              <p className="text-[11px] font-bold text-gray-700">{product.sku?.slice(0, 6) || 'N/A'}</p>
           </div>
        </div>

        <div className="flex justify-between items-center">
           <div>
              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">Market Price</p>
              <p className="text-lg font-black text-blue-700">₹{product.price?.toLocaleString()}</p>
           </div>
           <div className="flex gap-2">
              <button onClick={() => onEdit(product)} className="p-2 bg-gray-50 text-gray-400 hover:text-blue-600 rounded-lg transition">
                 <MdShare size={16} />
              </button>
              <button onClick={() => onEdit(product)} className="p-2 bg-gray-50 text-gray-400 hover:text-blue-600 rounded-lg transition">
                 <MdFullscreen size={18} />
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ProductTile;
