import React from 'react';
import { MdShoppingCart, MdPayment, MdAdd, MdRemove, MdDelete } from 'react-icons/md';

/**
 * Props
 *   cart: Array of { id, name, price, quantity }
 *   onUpdateQuantity: (id, delta) => void
 *   onRemoveItem: (id) => void
 *   onCheckout: () => void
 *   isProcessing: boolean
 */
const CartPreview = ({ cart, onUpdateQuantity, onRemoveItem, onCheckout, isProcessing }) => {
  const totalItems = cart.reduce((sum, i) => sum + (i.quantity || 0), 0);
  const totalAmount = cart.reduce((sum, i) => sum + (i.price * (i.quantity || 0)), 0);

  if (cart.length === 0) return null;

  return (
    <div id="cart" className="bg-white rounded-[32px] border border-gray-100 shadow-xl p-6 mb-8 sticky top-24">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-black text-blue-900 text-xl flex items-center gap-2">
          <MdShoppingCart className="text-blue-600" /> Active Cart
        </h2>
        <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-black uppercase tracking-widest">
          {totalItems} Items
        </span>
      </div>

      <div className="space-y-4 mb-8 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        {cart.map((item) => (
          <div key={item.id} className="p-4 bg-gray-50 rounded-2xl border border-gray-100 group transition hover:border-blue-100">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-bold text-gray-800 text-sm leading-tight">{item.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                   <p className="text-xs text-gray-400 font-medium">₹{item.price}</p>
                   <span className="text-[9px] font-black text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded uppercase">In Stock: {item.stockQuantity}</span>
                </div>
              </div>
              <button 
                onClick={() => onRemoveItem(item.id)}
                className="text-gray-300 hover:text-red-500 transition"
              >
                <MdDelete size={18} />
              </button>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-2 py-1">
                <button 
                  onClick={() => onUpdateQuantity(item.id, -1)}
                  className="p-1 hover:text-blue-600 transition"
                >
                  <MdRemove size={16} />
                </button>
                <span className="text-sm font-black w-6 text-center">{item.quantity}</span>
                <button 
                  onClick={() => onUpdateQuantity(item.id, 1)}
                  className="p-1 hover:text-blue-600 transition"
                >
                  <MdAdd size={16} />
                </button>
              </div>
              <p className="font-black text-gray-900 text-sm">₹{(item.price * item.quantity).toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t-2 border-dashed border-gray-100 pt-6">
        <div className="flex justify-between items-center mb-6">
          <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Grand Total</span>
          <span className="text-2xl font-black text-blue-900">₹{totalAmount.toLocaleString()}</span>
        </div>
        
        <button
          onClick={onCheckout}
          disabled={isProcessing}
          className="w-full flex items-center justify-center gap-3 bg-blue-900 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-blue-100 hover:bg-blue-800 transition active:scale-[0.98] disabled:opacity-50"
        >
          <MdPayment size={22} />
          {isProcessing ? 'Submitting...' : 'Checkout & Bill'}
        </button>
      </div>
    </div>
  );
};

export default CartPreview;
