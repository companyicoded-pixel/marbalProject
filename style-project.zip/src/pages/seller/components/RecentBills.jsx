import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';

/**
 * Shows a table of the seller's recent bills with status.
 * Note: Removed Firestore orderBy to avoid complex index requirements.
 * Sorting is done in-memory for immediate functionality.
 */
const RecentBills = ({ sellerId }) => {
  const [bills, setBills] = useState([]);

  useEffect(() => {
    if (!sellerId) return;
    
    // Simple query (only 1 field filter) to avoid composite index requirement
    const q = query(
      collection(db, 'bills'),
      where('sellerId', '==', sellerId)
    );

    const unsub = onSnapshot(q, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      
      // Sort in-memory by date descending
      const sorted = data.sort((a, b) => {
        const timeA = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
        const timeB = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
        return timeB - timeA;
      });

      setBills(sorted.slice(0, 5));
    }, (error) => {
      console.error("Firestore Error in RecentBills:", error);
    });

    return () => unsub();
  }, [sellerId]);

  const statusBadge = status => {
    const map = {
      pending: { bg: 'bg-orange-100 text-orange-600', label: 'Pending' },
      approved: { bg: 'bg-green-100 text-green-600', label: 'Approved' },
      rejected: { bg: 'bg-red-100 text-red-600', label: 'Rejected' },
    }[status] || { bg: 'bg-gray-100 text-gray-600', label: status };
    return (
      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest ${map.bg}`}>
        {map.label}
      </span>
    );
  };

  if (bills.length === 0) return null;

  return (
    <div className="bg-white rounded-[28px] border border-gray-100 shadow-sm overflow-hidden mb-8">
      <div className="px-6 py-4 border-b border-gray-50">
        <h2 className="font-black text-blue-900 text-base">Recent Bills</h2>
      </div>
      <table className="w-full text-left">
        <thead className="bg-gray-50/50 text-gray-400 text-[10px] uppercase font-black tracking-widest">
          <tr>
            <th className="px-6 py-3">ID</th>
            <th className="px-6 py-3">Total</th>
            <th className="px-6 py-3 text-right">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {bills.map(b => (
            <tr key={b.id} className="hover:bg-blue-50/30 transition group">
              <td className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400">#{b.id.slice(0, 8).toUpperCase()}</td>
              <td className="px-6 py-4 font-black text-gray-900 text-sm">₹{b.totalAmount?.toLocaleString()}</td>
              <td className="px-6 py-4 text-right">{statusBadge(b.status)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RecentBills;
