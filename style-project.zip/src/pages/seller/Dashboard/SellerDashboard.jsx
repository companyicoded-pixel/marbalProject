import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { useAuth } from '../../../context/AuthContext';
import { createBill } from '../../../services/billService';
import toast from 'react-hot-toast';

import { 
  MdQrCodeScanner, MdShoppingCart, MdHistory, MdPerson,
  MdSearch, MdNotifications, MdLogout, MdArrowForward
} from 'react-icons/md';

import SellerStatsCards from '../components/SellerStatsCards';
import ProductScanner from '../components/ProductScanner';
import CartPreview from '../components/CartPreview';
import RecentBills from '../components/RecentBills';

const QuickAction = ({ icon: Icon, label, onClick, color }) => (
  <button 
    onClick={onClick}
    className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col items-center gap-4 flex-1 min-w-[140px]"
  >
    <div className={`p-4 rounded-2xl ${color} group-hover:scale-110 transition-transform`}>
      <Icon size={28} />
    </div>
    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 group-hover:text-blue-900 transition-colors">{label}</span>
  </button>
);

const SellerDashboard = () => {
  const { user } = useAuth();
  const [cart, setCart] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [stats, setStats] = useState({ todaysSales: 0, todaysBills: 0, cartItems: 0, pendingBills: 0 });

  useEffect(() => {
    if (!user) return;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const qBills = query(collection(db, 'bills'), where('sellerId', '==', user.uid));
    const unsubBills = onSnapshot(qBills, (snapshot) => {
      const allBills = snapshot.docs.map(doc => doc.data());
      const todayBills = allBills.filter(b => b.createdAt?.toDate() >= today);
      
      setStats(prev => ({
        ...prev,
        todaysSales: todayBills.filter(b => b.status === 'approved').reduce((s, b) => s + (b.totalAmount || 0), 0),
        todaysBills: todayBills.length,
        pendingBills: allBills.filter(b => b.status === 'pending').length
      }));
    });

    return () => unsubBills();
  }, [user]);

  useEffect(() => {
    setStats(prev => ({ ...prev, cartItems: cart.reduce((s, i) => s + i.quantity, 0) }));
  }, [cart]);

  const handleAddToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        // Stock Validation
        if (existing.quantity >= product.quantity) {
          toast.error(`Only ${product.quantity} units available`);
          return prev;
        }
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      
      // Stock Validation for first item
      if (product.quantity <= 0) {
        toast.error('Item Out of Stock');
        return prev;
      }
      
      return [...prev, { ...product, quantity: 1, stockQuantity: product.quantity }];
    });
    toast.success(`${product.name} added to cart`);
  };

  const handleUpdateQuantity = (id, delta) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        
        // Stock Validation on increment
        if (delta > 0 && newQty > item.stockQuantity) {
           toast.error('Exceeds available stock');
           return item;
        }
        
        return { ...item, quantity: Math.max(1, newQty) };
      }
      return item;
    }));
  };

  const handleRemoveItem = (id) => setCart(prev => prev.filter(i => i.id !== id));

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setIsCreating(true);
    try {
      await createBill(user.uid, user.email?.split('@')[0] || 'Seller', cart);
      toast.success('Bill submitted for approval');
      setCart([]);
    } catch (err) {
      toast.error('Failed to create bill');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-[#f8fafc]">
      {/* Header Area */}
      <div className="px-10 py-10 search-container shrink-0">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-black text-blue-900 tracking-tight">POS Sales Terminal</h1>
            <p className="text-sm text-gray-500 mt-1">Welcome back, <span className="text-blue-600 font-bold">{user?.email?.split('@')[0]}</span>. System online and synchronized.</p>
          </div>
          <div className="flex gap-3">
             <button className="p-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-gray-400 hover:text-blue-600 transition"><MdNotifications size={24} /></button>
             <button className="p-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-gray-400 hover:text-red-500 transition"><MdLogout size={24} /></button>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="flex gap-4 bg-white p-2 rounded-[24px] shadow-xl border border-gray-100 max-w-4xl">
           <div className="flex-1 flex items-center gap-4 px-6">
              <MdSearch className="text-gray-300" size={24} />
              <input type="text" placeholder="Quick Product Search..." className="w-full bg-transparent outline-none font-medium text-gray-600" />
           </div>
           <button className="bg-blue-900 text-white px-10 py-3 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-blue-800 transition shadow-lg shadow-blue-100">Search</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
          
          <div className="xl:col-span-2 space-y-10">
            {/* Quick Actions */}
            <div className="flex flex-wrap gap-6">
              <QuickAction icon={MdQrCodeScanner} label="Scan Product" color="bg-blue-50 text-blue-600" />
              <QuickAction icon={MdShoppingCart} label="View Cart" color="bg-green-50 text-green-600" onClick={() => document.getElementById('cart')?.scrollIntoView({ behavior: 'smooth' })} />
              <QuickAction icon={MdHistory} label="Billing History" color="bg-orange-50 text-orange-500" />
              <QuickAction icon={MdPerson} label="My Profile" color="bg-purple-50 text-purple-600" />
            </div>

            <SellerStatsCards stats={stats} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-6">
                 <div className="flex justify-between items-center px-2">
                    <h2 className="text-sm font-black text-gray-900 uppercase tracking-widest">Active Scanner</h2>
                    <span className="flex items-center gap-1.5 text-[10px] font-black text-green-500 uppercase tracking-widest"><div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div> Terminal Ready</span>
                 </div>
                 <ProductScanner onAddToCart={handleAddToCart} />
              </div>
              <div className="space-y-6">
                 <RecentBills sellerId={user?.uid} />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <CartPreview 
              cart={cart} 
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onCheckout={handleCheckout} 
              isProcessing={isCreating}
            />
            
            {/* Terminal Info Card */}
            <div className="bg-blue-900 rounded-[40px] p-8 text-white shadow-2xl shadow-blue-100 relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 group-hover:scale-110 transition-transform"></div>
               <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-40 mb-4">Terminal Status</p>
               <h3 className="text-3xl font-black tracking-tighter mb-2 leading-none">Healthy</h3>
               <p className="text-sm text-blue-100 opacity-60 font-medium">All systems operational. Cloud synchronization active.</p>
               <div className="mt-8 pt-8 border-t border-white/10 flex justify-between items-center">
                  <div>
                    <p className="text-[9px] font-black uppercase opacity-40">System Version</p>
                    <p className="text-sm font-bold">Marble Pro 4.0</p>
                  </div>
                  <MdArrowForward size={24} className="opacity-40" />
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;
