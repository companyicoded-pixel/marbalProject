import { useState } from 'react';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logout } from '../services/authService';
import {
  MdDashboard, MdInventory, MdHistory, MdReceipt, MdPeople,
  MdAssessment, MdSettings, MdLogout, MdMenu, MdClose,
  MdLayers, MdTrendingDown, MdPerson, MdStorefront,
  MdNotifications, MdSearch, MdChevronRight
} from 'react-icons/md';

import Login           from '../pages/auth/Login';
import Register        from '../pages/auth/Register';
import AdminDashboard  from '../pages/admin/Dashboard/AdminDashboard';
import AddProduct      from '../pages/admin/Products/AddProduct';
import ProductList     from '../pages/admin/Products/ProductList';
import ReviewBills     from '../pages/admin/Bills/ReviewBills';
import StockHistory    from '../pages/admin/StockHistory/StockHistory';
import UsersPage       from '../pages/admin/Users/UsersPage';
import CategoriesPage  from '../pages/admin/Categories/CategoriesPage';
import ReportsPage     from '../pages/admin/Reports/ReportsPage';
import SettingsPage    from '../pages/admin/Settings/SettingsPage';
import ExpensesPage    from '../pages/admin/Expenses/ExpensesPage';
import SellerDashboard from '../pages/seller/Dashboard/SellerDashboard';
import BillingHistory  from '../pages/seller/Bills/BillingHistory';
import Profile         from '../pages/seller/Profile/Profile';

/* ─── Nav Link ─── */
const NavLink = ({ to, icon: Icon, label, badge, onClick }) => {
  const { pathname } = useLocation();
  const active = pathname === to;
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`flex items-center justify-between px-4 py-2.5 mx-2 rounded-xl text-sm font-medium transition-all duration-150 ${
        active
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40'
          : 'text-slate-300 hover:bg-white/10 hover:text-white'
      }`}
    >
      <span className="flex items-center gap-3">
        <Icon className={`text-lg flex-shrink-0 ${active ? 'text-white' : 'text-slate-400'}`} />
        <span className="truncate">{label}</span>
      </span>
      {badge && (
        <span className="text-[9px] font-bold bg-red-500 text-white px-1.5 py-0.5 rounded-full leading-none">
          {badge}
        </span>
      )}
    </Link>
  );
};

const NavSection = ({ label }) => (
  <p className="px-4 pt-5 pb-1.5 text-[9px] font-bold text-slate-500 uppercase tracking-widest">{label}</p>
);

/* ─── Top Bar ─── */
const TopBar = ({ onMenuClick, user, role }) => {
  const { pathname } = useLocation();
  const pageTitle = {
    '/admin':              'Dashboard',
    '/admin/inventory':    'Inventory',
    '/admin/categories':   'Categories',
    '/admin/history':      'Stock History',
    '/admin/review-bills': 'Review Bills',
    '/admin/expenses':     'Expenses',
    '/admin/users':        'Users',
    '/admin/reports':      'Reports',
    '/admin/settings':     'Settings',
    '/seller':             'POS Terminal',
    '/seller/history':     'Billing History',
    '/seller/profile':     'My Profile',
  }[pathname] || 'Marble Pro';

  return (
    <header className="flex-shrink-0 h-14 bg-gradient-to-r from-blue-700 to-blue-600 flex items-center justify-between px-4 shadow-lg z-30">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg text-white/80 hover:bg-white/20 transition"
        >
          <MdMenu className="text-xl" />
        </button>
        <div className="hidden lg:flex items-center gap-2 text-white/70 text-sm">
          <MdStorefront className="text-base" />
          <span className="font-medium">Marble Pro</span>
          <MdChevronRight className="text-xs" />
          <span className="text-white font-semibold">{pageTitle}</span>
        </div>
        <span className="lg:hidden text-white font-bold text-base">{pageTitle}</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2 bg-white/15 hover:bg-white/20 border border-white/20 rounded-lg px-3 py-1.5 transition cursor-pointer">
          <MdSearch className="text-white/70 text-base" />
          <span className="text-white/60 text-xs">Search…</span>
        </div>
        <button className="relative w-8 h-8 flex items-center justify-center rounded-lg text-white/80 hover:bg-white/20 transition">
          <MdNotifications className="text-lg" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-400 rounded-full border-2 border-blue-600" />
        </button>

      </div>
    </header>
  );
};

/* ─── Layout ─── */
const Layout = ({ children }) => {
  const { user, role } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-100">
      {open && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* ── Sidebar ── */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-60 flex flex-col bg-slate-900 transition-transform duration-300 ease-in-out ${
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-4 flex-shrink-0 bg-slate-950 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
              <MdStorefront className="text-white text-lg" />
            </div>
            <div>
              <span className="font-bold text-white text-base leading-tight block">Marble Pro</span>
              <span className="text-[10px] text-blue-300 font-medium">Inventory System</span>
            </div>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="lg:hidden w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:bg-white/10"
          >
            <MdClose className="text-lg" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-2">
          {role === 'admin' ? (
            <>
              <NavSection label="Operations" />
              <NavLink to="/admin"              icon={MdDashboard}    label="Dashboard"     onClick={() => setOpen(false)} />
              <NavLink to="/admin/inventory"    icon={MdInventory}    label="Inventory"     onClick={() => setOpen(false)} />
              <NavLink to="/admin/categories"   icon={MdLayers}       label="Categories"    onClick={() => setOpen(false)} />
              <NavLink to="/admin/history"      icon={MdHistory}      label="Stock History" onClick={() => setOpen(false)} />
              <NavLink to="/admin/review-bills" icon={MdReceipt}      label="Review Bills"  badge="NEW" onClick={() => setOpen(false)} />
              <NavLink to="/admin/expenses"     icon={MdTrendingDown} label="Expenses"      onClick={() => setOpen(false)} />
              <NavSection label="Management" />
              <NavLink to="/admin/users"    icon={MdPeople}     label="Users"    onClick={() => setOpen(false)} />
              <NavLink to="/admin/reports"  icon={MdAssessment} label="Reports"  onClick={() => setOpen(false)} />
              <NavLink to="/admin/settings" icon={MdSettings}   label="Settings" onClick={() => setOpen(false)} />
            </>
          ) : (
            <>
              <NavSection label="Point of Sale" />
              <NavLink to="/seller"         icon={MdDashboard} label="POS Terminal"    onClick={() => setOpen(false)} />
              <NavLink to="/seller/history" icon={MdHistory}   label="Billing History" onClick={() => setOpen(false)} />
              <NavLink to="/seller/profile" icon={MdPerson}    label="My Profile"      onClick={() => setOpen(false)} />
            </>
          )}
        </nav>

        {/* Logout */}
        <div className="p-3 flex-shrink-0 border-t border-white/5">
          <button
            onClick={() => { logout(); setOpen(false); }}
            className="flex items-center gap-3 w-full px-4 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-red-500/20 hover:text-red-300 transition-all"
          >
            <MdLogout className="text-lg flex-shrink-0" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopBar onMenuClick={() => setOpen(true)} user={user} role={role} />
        <main className="flex-1 overflow-y-auto overflow-x-hidden bg-slate-100 animate-fade-in">
          {children}
        </main>
      </div>
    </div>
  );
};

/* ─── Protected Route ─── */
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, role } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(role))
    return <Navigate to={role === 'admin' ? '/admin' : '/seller'} replace />;
  return <Layout>{children}</Layout>;
};

/* ─── Routes ─── */
export default function AppRoutes() {
  const { user, role } = useAuth();
  return (
    <Routes>
      <Route path="/login"    element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route path="/admin"              element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/inventory"    element={<ProtectedRoute allowedRoles={['admin']}><ProductList /></ProtectedRoute>} />
      <Route path="/admin/categories"   element={<ProtectedRoute allowedRoles={['admin']}><CategoriesPage /></ProtectedRoute>} />
      <Route path="/admin/add-product"  element={<ProtectedRoute allowedRoles={['admin']}><AddProduct /></ProtectedRoute>} />
      <Route path="/admin/review-bills" element={<ProtectedRoute allowedRoles={['admin']}><ReviewBills /></ProtectedRoute>} />
      <Route path="/admin/history"      element={<ProtectedRoute allowedRoles={['admin']}><StockHistory /></ProtectedRoute>} />
      <Route path="/admin/users"        element={<ProtectedRoute allowedRoles={['admin']}><UsersPage /></ProtectedRoute>} />
      <Route path="/admin/reports"      element={<ProtectedRoute allowedRoles={['admin']}><ReportsPage /></ProtectedRoute>} />
      <Route path="/admin/settings"     element={<ProtectedRoute allowedRoles={['admin']}><SettingsPage /></ProtectedRoute>} />
      <Route path="/admin/expenses"     element={<ProtectedRoute allowedRoles={['admin']}><ExpensesPage /></ProtectedRoute>} />

      <Route path="/seller"         element={<ProtectedRoute allowedRoles={['seller']}><SellerDashboard /></ProtectedRoute>} />
      <Route path="/seller/history" element={<ProtectedRoute allowedRoles={['seller']}><BillingHistory /></ProtectedRoute>} />
      <Route path="/seller/profile" element={<ProtectedRoute allowedRoles={['seller']}><Profile /></ProtectedRoute>} />

      <Route path="/" element={
        !user ? <Navigate to="/login" replace /> :
        role === 'admin' ? <Navigate to="/admin" replace /> :
        <Navigate to="/seller" replace />
      } />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
