import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { useAuth } from '../../../context/AuthContext';
import { createBill } from '../../../services/billService';
import { logout } from '../../../services/authService';
import { generateInvoice, shareOnWhatsApp } from '../../../services/reportService';
import toast from 'react-hot-toast';
import { MdQrCodeScanner, MdShoppingCart, MdHistory, MdPerson, MdCheckCircle, MdFileDownload, MdShare, MdClose } from 'react-icons/md';

import SellerStatsCards from '../components/SellerStatsCards';
import ProductScanner from '../components/ProductScanner';
import CartPreview from '../components/CartPreview';
import RecentBills from '../components/RecentBills';

const QuickBtn = ({ icon: Icon, label, onClick, iconCls, bgCls }) => (
  <button onClick={onClick}
    className="flex-1 min-w-[90px] bg-white border border-slate-200 rounded-xl p-3 flex flex-col items-center gap-2 hover:shadow-md hover:border-blue-200 transition active:scale-95">
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bgCls}`}>
      <Icon className={`text-xl ${iconCls}`} />
    </div>
    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide text-center leading-tight">{label}</span>
  </button>
);

export default function SellerDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cart, setCart] = useState([]);
  const [creating, setCreating] = useState(false);
  const [lastBill, setLastBill] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [stats, setStats] = useState({ todaysSales: 0, todaysBills: 0, cartItems: 0, pendingBills: 0 });

  useEffect(() => {
    if (!user) return;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const unsub = onSnapshot(query(collection(db, 'bills'), where('sellerId', '==', user.uid)), snap => {
      const all = snap.docs.map(d => d.data());
      const tod = all.filter(b => b.createdAt?.toDate?.() >= today);
      setStats(p => ({
        ...p,
        todaysSales: tod.filter(b => b.status === 'approved').reduce((s, b) => s + (b.totalAmount || 0), 0),
        todaysBills: tod.length,
        pendingBills: all.filter(b => b.status === 'pending').length,
      }));
    });
    return () => unsub();
  }, [user]);

  useEffect(() => {
    setStats(p => ({ ...p, cartItems: cart.reduce((s, i) => s + (i.quantity || 0), 0) }));
  }, [cart]);

  const handleAdd = product => {
    setCart(prev => {
      const ex = prev.find(i => i.id === product.id);
      if (ex) {
        if (ex.quantity >= product.quantity) { toast.error(`Only ${product.quantity} available`); return prev; }
        return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      if (product.quantity <= 0) { toast.error('Out of stock'); return prev; }
      return [...prev, { ...product, quantity: 1, stockQuantity: product.quantity }];
    });
    toast.success(`${product.name} added`);
  };

  const handleQty = (id, delta) => setCart(prev => prev.map(i => {
    if (i.id !== id) return i;
    const nq = i.quantity + delta;
    if (delta > 0 && nq > i.stockQuantity) { toast.error('Exceeds stock'); return i; }
    return { ...i, quantity: Math.max(1, nq) };
  }));

  const handleRemove = id => setCart(prev => prev.filter(i => i.id !== id));

  const handleCheckout = async info => {
    if (!cart.length) return;
    setCreating(true);
    try {
      const total = cart.reduce((s, i) => s + i.price * i.quantity, 0);
      const data = {
        sellerId: user.uid,
        sellerName: user.email?.split('@')[0] || 'Seller',
        items: cart.map(({ id, name, price, quantity, sku }) => ({ id, name, price, quantity, sku })),
        totalAmount: total, category: 'General',
        customerName: info.name || 'Walk-in',
        customerContact: info.contact || '',
        customerAddress: info.address || '',
        paymentMode: info.paymentMode || 'Cash',
      };
      const id = await createBill(data);
      setLastBill({ id, ...data });
      setShowModal(true);
      toast.success('Bill submitted!');
      setCart([]);
    } catch { toast.error('Failed to create bill'); } finally { setCreating(false); }
  };

  return (
    <div className="flex flex-col h-full">


      {/* Main scroll area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5">
        <div className="max-w-7xl mx-auto">
          {/* Quick actions */}
          <div className="flex gap-2 mb-4 flex-wrap">
            <QuickBtn icon={MdQrCodeScanner} label="Scan" iconCls="text-blue-600" bgCls="bg-blue-50" onClick={() => document.getElementById('scanner-sec')?.scrollIntoView({ behavior: 'smooth' })} />
            <QuickBtn icon={MdShoppingCart} label="Cart" iconCls="text-emerald-600" bgCls="bg-emerald-50" onClick={() => document.getElementById('cart-sec')?.scrollIntoView({ behavior: 'smooth' })} />
            <QuickBtn icon={MdHistory} label="History" iconCls="text-amber-600" bgCls="bg-amber-50" onClick={() => navigate('/seller/history')} />
            <QuickBtn icon={MdPerson} label="Profile" iconCls="text-purple-600" bgCls="bg-purple-50" onClick={() => navigate('/seller/profile')} />
          </div>

          {/* Stats */}
          <div className="mb-4">
            <SellerStatsCards stats={stats} />
          </div>

          {/* Two-column layout */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            {/* Left: scanner + recent */}
            <div className="xl:col-span-2 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div id="scanner-sec">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Scanner</p>
                  <ProductScanner onAddToCart={handleAdd} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Recent Activity</p>
                  <RecentBills sellerId={user?.uid} />
                </div>
              </div>
            </div>

            {/* Right: cart */}
            <div id="cart-sec">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Billing Cart</p>
              <CartPreview cart={cart} onUpdateQuantity={handleQty} onRemoveItem={handleRemove} onCheckout={handleCheckout} isProcessing={creating} />
            </div>
          </div>
        </div>
      </div>

      {/* Success modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-sm rounded-t-2xl sm:rounded-2xl shadow-2xl p-6 text-center animate-slide-up">
            <button onClick={() => setShowModal(false)} className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 transition">
              <MdClose className="text-xl" />
            </button>
            <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <MdCheckCircle className="text-4xl text-emerald-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 mb-1">Bill Generated!</h2>
            <p className="text-sm text-slate-500 mb-5 leading-relaxed">Transaction recorded. Download or share the invoice.</p>
            <div className="space-y-2.5">
              <button onClick={() => generateInvoice(lastBill)}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-blue-200">
                <MdFileDownload className="text-lg" /> Download PDF
              </button>
              {lastBill?.customerContact && (
                <button onClick={() => shareOnWhatsApp(lastBill)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#25d366] hover:bg-[#128c7e] text-white text-sm font-semibold rounded-xl transition">
                  <MdShare className="text-lg" /> Share on WhatsApp
                </button>
              )}
              <button onClick={() => setShowModal(false)}
                className="w-full py-2.5 text-sm font-semibold text-slate-500 hover:text-slate-700 transition">
                New Transaction
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
