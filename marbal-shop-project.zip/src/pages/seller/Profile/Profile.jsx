import React from 'react';
import { useAuth } from '../../../context/AuthContext';
import { MdEmail, MdSecurity, MdWork, MdVerifiedUser } from 'react-icons/md';

export default function Profile() {
  const { user, role } = useAuth();

  return (
    <div className="p-4 sm:p-6 max-w-2xl mx-auto space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-800">My Profile</h1>
        <p className="text-sm text-slate-500 mt-0.5">Your account information</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {/* Cover */}
        <div className="h-24 bg-gradient-to-r from-blue-600 to-blue-800 relative">
          <div className="absolute -bottom-8 left-5 w-16 h-16 bg-white rounded-2xl border-4 border-white shadow-lg flex items-center justify-center text-2xl font-bold text-blue-700">
            {user?.email?.charAt(0).toUpperCase()}
          </div>
        </div>

        <div className="pt-12 px-5 pb-5">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-slate-800">{user?.email?.split('@')[0]}</h2>
            <div className="flex items-center gap-1.5 mt-0.5">
              <MdVerifiedUser className="text-blue-600 text-sm" />
              <span className={`text-xs font-bold uppercase tracking-wide ${role==='admin' ? 'text-blue-600' : 'text-emerald-600'}`}>{role}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { icon: MdEmail,    label:'Email',        value: user?.email },
              { icon: MdWork,     label:'Account Type', value: role==='seller' ? 'Sales Operator' : 'Administrator' },
              { icon: MdSecurity, label:'User ID',      value: user?.uid?.slice(0,20)+'…', mono:true },
            ].map(({ icon: Icon, label, value, mono }) => (
              <div key={label} className="flex items-center gap-3 bg-slate-50 rounded-xl px-4 py-3 border border-slate-100">
                <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm flex-shrink-0">
                  <Icon className="text-blue-600 text-base" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">{label}</p>
                  <p className={`text-sm font-semibold text-slate-800 truncate ${mono ? 'font-mono text-xs' : ''}`}>{value}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-3 bg-blue-50 rounded-xl px-4 py-3 border border-blue-100">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <MdVerifiedUser className="text-white text-base" />
            </div>
            <div>
              <p className="text-sm font-bold text-blue-800">Account Active</p>
              <p className="text-xs text-blue-600">Your account is verified and in good standing.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
