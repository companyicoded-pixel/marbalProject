import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { useAuth } from '../../../context/AuthContext';
import { MdHistory, MdReceipt, MdDownload } from 'react-icons/md';
import { generateInvoice } from '../../../services/reportService';

const sCls = s =>
  s==='approved' ? 'bg-emerald-100 text-emerald-700' :
  s==='pending'  ? 'bg-amber-100 text-amber-700' :
                   'bg-red-100 text-red-600';

export default function BillingHistory() {
  const { user } = useAuth();
  const [bills, setBills]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(query(collection(db,'bills'), where('sellerId','==',user.uid)), snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBills(data.sort((a,b) => (b.createdAt?.toDate?.()?.getTime()||0) - (a.createdAt?.toDate?.()?.getTime()||0)));
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, [user]);

  const revenue = bills.filter(b=>b.status==='approved').reduce((s,b)=>s+(b.totalAmount||0),0);

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <MdHistory className="text-blue-600" /> Billing History
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">All your submitted bills</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label:'Total Bills',  value: bills.length,                                    cls:'text-blue-700' },
          { label:'Approved',     value: bills.filter(b=>b.status==='approved').length,   cls:'text-emerald-600' },
          { label:'Pending',      value: bills.filter(b=>b.status==='pending').length,    cls:'text-amber-600' },
          { label:'Revenue',      value:`₹${revenue.toLocaleString()}`,                   cls:'text-emerald-600' },
        ].map(({ label, value, cls }) => (
          <div key={label} className="bg-white rounded-xl border border-slate-200 p-3">
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">{label}</p>
            <p className={`text-xl font-bold ${cls}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading
          ? <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
          : <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    {['Bill ID','Customer','Date','Amount','Payment','Status',''].map(h => (
                      <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {bills.map(b => (
                    <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-slate-500">#{b.id.slice(0,10)}</td>
                      <td className="px-4 py-3 font-medium text-slate-800 max-w-[120px] truncate">{b.customerName||'Walk-in'}</td>
                      <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">
                        {b.createdAt?.toDate ? new Intl.DateTimeFormat('en-IN').format(b.createdAt.toDate()) : '—'}
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-800">₹{b.totalAmount?.toLocaleString()}</td>
                      <td className="px-4 py-3 text-xs text-slate-500">{b.paymentMode||'Cash'}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${sCls(b.status)}`}>{b.status}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {b.status==='approved' && (
                          <button onClick={() => generateInvoice(b)}
                            className="w-7 h-7 flex items-center justify-center bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-600 rounded-lg transition ml-auto">
                            <MdDownload className="text-base" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {!bills.length && (
                    <tr><td colSpan={7} className="px-4 py-12 text-center">
                      <MdReceipt className="text-4xl text-slate-300 mx-auto mb-2" />
                      <p className="text-sm text-slate-400">No bills found</p>
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
        }
      </div>
    </div>
  );
}
