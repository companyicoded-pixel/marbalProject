import React from 'react';
import { MdAttachMoney, MdDescription, MdShoppingCart, MdHourglassTop } from 'react-icons/md';

export default function SellerStatsCards({ stats }) {
  const cards = [
    { label:"Today's Sales", value:`₹${stats.todaysSales?.toLocaleString()||0}`, Icon:MdAttachMoney,  bg:'bg-blue-50',    icon:'text-blue-600',    dark:false },
    { label:"Today's Bills", value:stats.todaysBills??0,                          Icon:MdDescription,  bg:'bg-blue-600',   icon:'text-white',       dark:true  },
    { label:'Cart Items',    value:stats.cartItems??0,                             Icon:MdShoppingCart, bg:'bg-emerald-50', icon:'text-emerald-600', dark:false },
    { label:'Pending Bills', value:stats.pendingBills??0,                          Icon:MdHourglassTop, bg:'bg-amber-50',   icon:'text-amber-600',   dark:false },
  ];
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {cards.map((c, i) => (
        <div key={i} className={`rounded-xl border p-3 flex items-center gap-3 transition-shadow hover:shadow-md ${c.dark ? 'bg-blue-600 border-blue-600' : 'bg-white border-slate-200'}`}>
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${c.dark ? 'bg-white/20' : c.bg}`}>
            <c.Icon className={`text-lg ${c.dark ? 'text-white' : c.icon}`} />
          </div>
          <div className="min-w-0">
            <p className={`text-[10px] font-semibold uppercase tracking-wide truncate ${c.dark ? 'text-blue-200' : 'text-slate-500'}`}>{c.label}</p>
            <p className={`text-xl font-bold leading-tight ${c.dark ? 'text-white' : 'text-slate-800'}`}>{c.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
