import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdReceipt } from 'react-icons/md';

const sMap = {
  pending:  { cls:'bg-amber-100 text-amber-700',   label:'In Review' },
  approved: { cls:'bg-emerald-100 text-emerald-700', label:'Approved' },
  rejected: { cls:'bg-red-100 text-red-600',        label:'Rejected' },
};

export default function RecentBills({ sellerId }) {
  const [bills, setBills] = useState([]);

  useEffect(() => {
    if (!sellerId) return;
    const unsub = onSnapshot(query(collection(db,'bills'), where('sellerId','==',sellerId)), snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBills(data.sort((a,b) => (b.createdAt?.toDate?.()?.getTime()||0) - (a.createdAt?.toDate?.()?.getTime()||0)).slice(0,5));
    });
    return () => unsub();
  }, [sellerId]);

  if (!bills.length) return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 text-center">
      <MdReceipt className="text-3xl text-slate-300 mx-auto mb-2" />
      <p className="text-sm text-slate-400 font-medium">No recent bills</p>
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100">
        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
          <MdReceipt className="text-blue-600" /> Recent Bills
        </h3>
      </div>
      <div className="divide-y divide-slate-50">
        {bills.map(b => {
          const s = sMap[b.status] || { cls:'bg-slate-100 text-slate-500', label: b.status };
          return (
            <div key={b.id} className="flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-[10px] font-bold text-blue-700 flex-shrink-0">
                  #{b.id.slice(0,2).toUpperCase()}
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-sm">₹{b.totalAmount?.toLocaleString()}</p>
                  <p className="text-xs text-slate-400">{b.customerName||'Walk-in'}</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${s.cls}`}>{s.label}</span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {b.createdAt?.toDate ? b.createdAt.toDate().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}) : ''}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
