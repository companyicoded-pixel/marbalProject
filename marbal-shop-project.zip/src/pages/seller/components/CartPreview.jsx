import React, { useState } from 'react';
import { MdShoppingCart, MdPayment, MdAdd, MdRemove, MdDelete, MdPerson, MdPhone, MdLocationOn } from 'react-icons/md';

const inputCls = "w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400";

export default function CartPreview({ cart, onUpdateQuantity, onRemoveItem, onCheckout, isProcessing }) {
  const [info, setInfo] = useState({ name:'', contact:'', address:'', paymentMode:'Cash' });

  const totalItems  = cart.reduce((s,i) => s + (i.quantity||0), 0);
  const totalAmount = cart.reduce((s,i) => s + i.price*(i.quantity||0), 0);

  if (!cart.length) return (
    <div className="bg-white rounded-xl border border-slate-200 p-8 text-center">
      <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
        <MdShoppingCart className="text-3xl text-slate-300" />
      </div>
      <p className="font-semibold text-slate-500 text-sm">Cart is empty</p>
      <p className="text-xs text-slate-400 mt-1">Scan or search a product to add</p>
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 flex flex-col max-h-[85vh] sticky top-4">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 flex-shrink-0">
        <h2 className="font-bold text-slate-800 text-sm flex items-center gap-2">
          <MdShoppingCart className="text-blue-600" /> Cart
        </h2>
        <span className="text-xs font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{totalItems} items</span>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 min-h-0">
        {/* Items */}
        <div className="space-y-2">
          {cart.map(item => (
            <div key={item.id} className="bg-slate-50 rounded-xl p-3 border border-slate-100 hover:border-blue-100 hover:bg-white transition">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0 pr-2">
                  <p className="font-bold text-slate-800 text-sm truncate">{item.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <p className="text-xs font-bold text-blue-700">₹{item.price?.toLocaleString()}</p>
                    <span className="text-[9px] font-bold bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded-full uppercase">{item.sku}</span>
                  </div>
                </div>
                <button onClick={() => onRemoveItem(item.id)}
                  className="w-7 h-7 flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition flex-shrink-0">
                  <MdDelete className="text-base" />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-1.5 py-1">
                  <button onClick={() => onUpdateQuantity(item.id,-1)}
                    className="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-md transition">
                    <MdRemove className="text-sm" />
                  </button>
                  <span className="text-sm font-bold text-slate-800 w-5 text-center">{item.quantity}</span>
                  <button onClick={() => onUpdateQuantity(item.id,1)}
                    className="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-md transition">
                    <MdAdd className="text-sm" />
                  </button>
                </div>
                <p className="font-bold text-slate-800 text-sm">₹{(item.price*item.quantity).toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Customer info */}
        <div className="border-t border-slate-100 pt-3 space-y-2.5">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Customer Details</p>
          {[
            { icon: MdPerson,      key:'name',    type:'text',  ph:'Customer name' },
            { icon: MdPhone,       key:'contact', type:'tel',   ph:'Contact number' },
          ].map(({ icon: Icon, key, type, ph }) => (
            <div key={key} className="relative">
              <Icon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-base" />
              <input type={type} placeholder={ph} className={inputCls}
                value={info[key]} onChange={e => setInfo(p => ({ ...p, [key]: e.target.value }))} />
            </div>
          ))}
          <div className="relative">
            <MdLocationOn className="absolute left-3 top-3 text-slate-400 text-base" />
            <textarea placeholder="Address (optional)" rows={2}
              className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400 resize-none"
              value={info.address} onChange={e => setInfo(p => ({ ...p, address: e.target.value }))} />
          </div>

          {/* Payment mode */}
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5">Payment Mode</p>
            <div className="grid grid-cols-2 gap-2">
              {['Cash','Online'].map(m => (
                <button key={m} onClick={() => setInfo(p => ({ ...p, paymentMode: m }))}
                  className={`py-2 rounded-xl text-xs font-bold uppercase tracking-wide border-2 transition ${info.paymentMode===m ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-200 text-slate-500 hover:border-blue-400'}`}>
                  {m}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-100 p-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">Total</p>
            <p className="text-2xl font-bold text-blue-700">₹{totalAmount.toLocaleString()}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">Mode</p>
            <p className="text-sm font-bold text-slate-700">{info.paymentMode}</p>
          </div>
        </div>
        <button onClick={() => onCheckout(info)} disabled={isProcessing}
          className="w-full flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl transition disabled:opacity-50 active:scale-95 shadow-md shadow-blue-200">
          {isProcessing ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <MdPayment className="text-lg" />}
          {isProcessing ? 'Processing…' : 'Generate Bill'}
        </button>
      </div>
    </div>
  );
}
