import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { getProductBySKU } from '../../../services/productService';
import { MdQrCodeScanner, MdAddCircle, MdSearch, MdCameraAlt, MdClose } from 'react-icons/md';
import toast from 'react-hot-toast';

export default function ProductScanner({ onAddToCart }) {
  const [sku, setSku]           = useState('');
  const [loading, setLoading]   = useState(false);
  const [showCam, setShowCam]   = useState(false);
  const scannerRef = useRef(null);

  useEffect(() => {
    if (showCam) {
      const s = new Html5QrcodeScanner('qr-reader', { fps:10, qrbox:{width:220,height:220}, rememberLastUsedCamera:true });
      s.render(async text => {
        if (loading) return;
        setLoading(true);
        try {
          const p = await getProductBySKU(text);
          if (p) { if (p.quantity<=0) toast.error('Out of stock!'); else { onAddToCart(p); setShowCam(false); } }
          else toast.error('Unknown SKU');
        } catch { toast.error('Lookup failed'); } finally { setLoading(false); }
      }, () => {});
      scannerRef.current = s;
    } else {
      scannerRef.current?.clear();
      scannerRef.current = null;
    }
    return () => { scannerRef.current?.clear(); };
  }, [showCam]);

  const handleManual = async e => {
    e.preventDefault();
    if (!sku.trim()) return;
    setLoading(true);
    try {
      const p = await getProductBySKU(sku.trim());
      if (p) { if (p.quantity<=0) toast.error('Out of stock!'); else { onAddToCart(p); setSku(''); } }
      else toast.error('Product not found');
    } catch { toast.error('Lookup failed'); } finally { setLoading(false); }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-blue-50 rounded-xl flex items-center justify-center">
              <MdQrCodeScanner className="text-blue-600 text-xl" />
            </div>
            <div>
              <p className="font-bold text-slate-800 text-sm">Product Scanner</p>
              <p className="text-[10px] text-slate-400 uppercase tracking-wide">Scan or enter SKU</p>
            </div>
          </div>
          <button onClick={() => setShowCam(v => !v)}
            className={`w-9 h-9 flex items-center justify-center rounded-xl transition ${showCam ? 'bg-red-100 text-red-500' : 'bg-blue-600 text-white shadow-md shadow-blue-200'}`}>
            {showCam ? <MdClose className="text-lg" /> : <MdCameraAlt className="text-lg" />}
          </button>
        </div>

        {showCam && (
          <div className="mb-4 rounded-xl overflow-hidden border-2 border-blue-100">
            <div id="qr-reader" className="w-full" />
            <div className="bg-blue-50 py-2 text-center">
              <p className="text-[10px] font-semibold text-blue-700 uppercase tracking-wide">Aim at product QR code</p>
            </div>
          </div>
        )}

        <form onSubmit={handleManual} className="space-y-2.5">
          <div className="relative">
            <input type="text" placeholder="Enter SKU manually…"
              className="w-full pl-4 pr-10 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400"
              value={sku} onChange={e => setSku(e.target.value)} />
            <MdSearch className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-lg" />
          </div>
          <button type="submit" disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition disabled:opacity-50 active:scale-95">
            {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <MdAddCircle className="text-lg" />}
            {loading ? 'Searching…' : 'Add to Cart'}
          </button>
        </form>
      </div>
      <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
        <span className="w-2 h-2 bg-emerald-500 rounded-full pulse-dot" />
        <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">Scanner Ready</p>
      </div>
    </div>
  );
}
