import { useEffect, useState } from 'react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { Link } from 'react-router-dom';
import {
  MdTrendingUp, MdTrendingDown, MdInventory, MdArrowForward,
  MdReceipt, MdPeople, MdArrowUpward, MdArrowDownward, MdWarning
} from 'react-icons/md';

const statusCls = s =>
  s === 'approved' ? 'bg-emerald-100 text-emerald-700' :
    s === 'pending' ? 'bg-amber-100 text-amber-700' :
      'bg-red-100 text-red-600';

const StatCard = ({ icon: Icon, label, value, sub, gradient, to }) => (
  <Link
    to={to || '#'}
    className={`block rounded-2xl p-5 text-white shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all ${gradient}`}
  >
    <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center mb-4">
      <Icon className="text-2xl" />
    </div>
    <p className="text-xs font-semibold uppercase tracking-wider text-white/80 mb-1">{label}</p>
    <p className="text-3xl font-bold">{value}</p>
    {sub && <p className="text-xs text-white/70 mt-1">{sub}</p>}
  </Link>
);

export default function AdminDashboard() {
  const [stats, setStats] = useState({ products: 0, pending: 0, revenue: 0, lowStock: 0, expenses: 0 });
  const [recentBills, setRecentBills] = useState([]);

  useEffect(() => {
    const u1 = onSnapshot(collection(db, 'bills'), snap => {
      const all = snap.docs.map(d => d.data());
      setStats(p => ({
        ...p,
        pending: all.filter(b => b.status === 'pending').length,
        revenue: all.filter(b => b.status === 'approved').reduce((s, b) => s + (b.totalAmount || 0), 0),
      }));
    });
    const u2 = onSnapshot(collection(db, 'expenses'), snap => {
      setStats(p => ({ ...p, expenses: snap.docs.reduce((s, d) => s + (d.data().amount || 0), 0) }));
    });
    const u3 = onSnapshot(collection(db, 'products'), snap => {
      const prods = snap.docs.map(d => d.data());
      setStats(p => ({ ...p, products: prods.length, lowStock: prods.filter(x => (x.quantity || 0) < 10).length }));
    });
    const u4 = onSnapshot(
      query(collection(db, 'bills'), orderBy('createdAt', 'desc'), limit(6)),
      snap => setRecentBills(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    );
    return () => { u1(); u2(); u3(); u4(); };
  }, []);

  const profit = stats.revenue - stats.expenses;
  const stockPct = stats.products > 0
    ? Math.round(((stats.products - stats.lowStock) / stats.products) * 100)
    : 100;

  return (
    <div className="p-4 sm:p-6 bg-slate-100 min-h-full">
      <div className="max-w-7xl mx-auto space-y-5">



        {/* ── Stat Cards ── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={MdReceipt} label="Total Revenue" value={`₹${stats.revenue.toLocaleString()}`} sub="Approved bills" gradient="bg-gradient-to-br from-purple-600 to-purple-700" to="/admin/reports" />
          <StatCard icon={MdTrendingDown} label="Total Expenses" value={`₹${stats.expenses.toLocaleString()}`} sub="All time costs" gradient="bg-gradient-to-br from-blue-600 to-blue-700" to="/admin/expenses" />
          <StatCard icon={MdPeople} label="Pending Bills" value={stats.pending} sub="Awaiting approval" gradient="bg-gradient-to-br from-violet-600 to-purple-700" to="/admin/review-bills" />
          <StatCard icon={MdWarning} label="Low Stock Items" value={stats.lowStock} sub="Need restocking" gradient="bg-gradient-to-br from-purple-500 to-violet-600" to="/admin/inventory" />
        </div>

        {/* ── Profit Banner ── */}
        <div className={`rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6 border ${profit >= 0 ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${profit >= 0 ? 'bg-emerald-100' : 'bg-red-100'}`}>
            {profit >= 0
              ? <MdArrowUpward className="text-emerald-600 text-xl" />
              : <MdArrowDownward className="text-red-500 text-xl" />}
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Net Profit / Loss</p>
            <p className={`text-2xl font-bold ${profit >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>
              {profit >= 0 ? '+' : ''}₹{profit.toLocaleString()}
            </p>
          </div>
          <div className="sm:ml-auto flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <span>Revenue: <strong className="text-emerald-600">₹{stats.revenue.toLocaleString()}</strong></span>
            <span>Expenses: <strong className="text-red-500">₹{stats.expenses.toLocaleString()}</strong></span>
          </div>
        </div>

        {/* ── Bottom Grid ── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">

          {/* Recent Bills */}
          <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <h2 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
                <span className="w-1 h-4 bg-blue-600 rounded-full" />
                Recent Bills
              </h2>
              <Link to="/admin/review-bills" className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1">
                View all <MdArrowForward className="text-xs" />
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="table-main">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    {['Invoice ID', 'Customer', 'Status', 'Amount'].map(h => (
                      <th key={h} className="table-header">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {recentBills.map(b => (
                    <tr key={b.id} className="table-row">
                      <td className="table-cell font-mono text-xs text-blue-600 font-semibold">#{b.id.slice(0, 8).toUpperCase()}</td>
                      <td className="table-cell font-medium text-slate-700 max-w-[140px] truncate">{b.customerName || 'Walk-in'}</td>
                      <td className="table-cell">
                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${statusCls(b.status)}`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="table-cell font-bold text-slate-800">₹{b.totalAmount?.toLocaleString()}</td>
                    </tr>
                  ))}
                  {!recentBills.length && (
                    <tr>
                      <td colSpan={4} className="px-5 py-10 text-center text-sm text-slate-400">No bills yet</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Panel */}
          <div className="flex flex-col gap-4">

            {/* Inventory Health */}
            <div className="bg-gradient-to-br from-blue-700 to-blue-900 rounded-2xl p-5 text-white shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MdInventory className="text-lg" />
                </div>
                <div>
                  <p className="font-bold text-sm">Inventory Health</p>
                  <p className="text-blue-200 text-xs">{stats.products} SKUs · {stats.lowStock} low stock</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between text-xs text-blue-200 mb-1.5">
                  <span>Stock health</span>
                  <span>{stockPct}%</span>
                </div>
                {/* Progress bar — width set via Tailwind arbitrary value */}
                <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-white rounded-full transition-all duration-700"
                    style={{ width: `${stockPct}%` }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Link to="/admin/review-bills" className="flex-1 bg-white text-blue-700 text-xs font-bold py-2 rounded-xl text-center hover:bg-blue-50 transition">
                  Review Bills
                </Link>
                <Link to="/admin/reports" className="px-3 border border-white/30 rounded-xl hover:bg-white/10 transition flex items-center justify-center">
                  <MdTrendingUp className="text-base" />
                </Link>
              </div>
            </div>

            {/* Profit card */}
            <div className={`rounded-2xl p-4 text-white shadow-lg ${profit >= 0 ? 'bg-gradient-to-br from-emerald-500 to-emerald-600' : 'bg-gradient-to-br from-red-500 to-red-600'}`}>
              <p className="text-xs font-semibold uppercase tracking-wide text-white/80 mb-1">Net Profit / Loss</p>
              <p className="text-2xl font-bold">{profit >= 0 ? '+' : ''}₹{profit.toLocaleString()}</p>
              <div className="mt-3 pt-3 border-t border-white/20 flex justify-between text-xs text-white/80">
                <span>Revenue: <strong className="text-white">₹{stats.revenue.toLocaleString()}</strong></span>
                <span>Costs: <strong className="text-white">₹{stats.expenses.toLocaleString()}</strong></span>
              </div>
            </div>

            {/* Pending alert */}
            {stats.pending > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
                <p className="text-xs font-semibold text-amber-600 uppercase tracking-wide mb-1">Pending Approval</p>
                <p className="text-2xl font-bold text-amber-700">{stats.pending} bills</p>
                <Link to="/admin/review-bills" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-amber-600 hover:underline">
                  Review now <MdArrowForward className="text-xs" />
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
