import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdTrendingUp, MdTrendingDown, MdHistory, MdSearch } from 'react-icons/md';

export default function StockHistory() {
  const [logs, setLogs]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'stockHistory'), orderBy('createdAt', 'desc'), limit(100)),
      snap => {
        setLogs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const inCount  = logs.filter(l => l.type === 'IN').length;
  const outCount = logs.filter(l => l.type === 'OUT').length;

  const filtered = logs.filter(l => {
    const matchType = typeFilter === 'ALL' || l.type === typeFilter;
    const matchSearch = !search || l.productName?.toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  return (
    <div className="flex flex-col h-full">

      {/* ── Header ── */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-4 flex-shrink-0 space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Stock History</h1>
          <p className="text-sm text-slate-500 mt-0.5">Real-time stock movement log</p>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-3">
          {[
            { label: 'Total Inward',  count: inCount,  Icon: MdTrendingUp,   cls: 'text-emerald-600', bg: 'bg-emerald-50', filter: 'IN' },
            { label: 'Total Outward', count: outCount, Icon: MdTrendingDown, cls: 'text-red-500',     bg: 'bg-red-50',     filter: 'OUT' },
          ].map(({ label, count, Icon, cls, bg, filter }) => (
            <button
              key={label}
              onClick={() => setTypeFilter(typeFilter === filter ? 'ALL' : filter)}
              className={`flex items-center gap-3 border rounded-xl px-4 py-2.5 transition hover:shadow-sm ${
                typeFilter === filter ? 'border-slate-400 bg-slate-50' : 'bg-white border-slate-200'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${bg}`}>
                <Icon className={`text-base ${cls}`} />
              </div>
              <div className="text-left">
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">{label}</p>
                <p className="text-lg font-bold text-slate-800 leading-tight">{count}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Search & filter */}
        <div className="flex flex-wrap gap-2">
          <div className="flex-1 min-w-[180px] flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition">
            <MdSearch className="text-slate-400 text-lg flex-shrink-0" />
            <input
              type="text"
              placeholder="Search product…"
              className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="flex p-1 bg-slate-100 rounded-xl gap-1">
            {['ALL', 'IN', 'OUT'].map(t => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  typeFilter === t ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {t === 'ALL' ? 'All' : t === 'IN' ? 'Stock In' : 'Stock Out'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Table ── */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">

          {/* Desktop table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  {['Type', 'Product', 'Qty', 'Operator', 'Time'].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {loading && (
                  <tr>
                    <td colSpan={5} className="px-4 py-10 text-center">
                      <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    </td>
                  </tr>
                )}
                {!loading && filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-12 text-center">
                      <MdHistory className="text-4xl text-slate-300 mx-auto mb-2" />
                      <p className="text-sm text-slate-400">No history recorded</p>
                    </td>
                  </tr>
                )}
                {filtered.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                        log.type === 'IN' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'
                      }`}>
                        {log.type === 'IN'
                          ? <MdTrendingUp className="text-xs" />
                          : <MdTrendingDown className="text-xs" />}
                        {log.type === 'IN' ? 'Stock In' : 'Stock Out'}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-800">{log.productName}</td>
                    <td className={`px-4 py-3 font-bold text-base ${log.type === 'IN' ? 'text-emerald-600' : 'text-red-500'}`}>
                      {log.type === 'IN' ? '+' : '−'}{log.quantity}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-500">{log.updatedBy}</td>
                    <td className="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">
                      {log.createdAt?.toDate().toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile card list */}
          <div className="sm:hidden">
            {loading ? (
              <div className="p-8 flex justify-center">
                <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center">
                <MdHistory className="text-4xl text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-400">No history recorded</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {filtered.map(log => (
                  <div key={log.id} className="p-4 flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      log.type === 'IN' ? 'bg-emerald-50' : 'bg-red-50'
                    }`}>
                      {log.type === 'IN'
                        ? <MdTrendingUp className="text-emerald-600 text-lg" />
                        : <MdTrendingDown className="text-red-500 text-lg" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-800 text-sm truncate">{log.productName}</p>
                      <p className="text-xs text-slate-400">{log.updatedBy} · {log.createdAt?.toDate().toLocaleDateString()}</p>
                    </div>
                    <span className={`font-bold text-base flex-shrink-0 ${log.type === 'IN' ? 'text-emerald-600' : 'text-red-500'}`}>
                      {log.type === 'IN' ? '+' : '−'}{log.quantity}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {filtered.length > 0 && (
          <p className="text-xs text-slate-400 text-center mt-3">
            Showing {filtered.length} of {logs.length} entries
          </p>
        )}
      </div>
    </div>
  );
}
