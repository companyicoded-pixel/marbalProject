import { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { addExpense, deleteExpense } from '../../../services/expenseService';
import toast from 'react-hot-toast';
import {
  MdAdd, MdDelete, MdReceiptLong, MdTrendingDown, MdClose,
  MdAttachMoney, MdCategory, MdCalendarToday, MdSearch
} from 'react-icons/md';

const CATS = ['Utility', 'Salary', 'Rent', 'Transport', 'Others'];

const CAT_CONFIG = {
  Utility:   { pill: 'bg-blue-100 text-blue-700',    dot: 'bg-blue-500',    bar: 'bg-blue-500',    icon: '⚡' },
  Salary:    { pill: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500', bar: 'bg-emerald-500', icon: '👤' },
  Rent:      { pill: 'bg-amber-100 text-amber-700',   dot: 'bg-amber-500',   bar: 'bg-amber-500',   icon: '🏠' },
  Transport: { pill: 'bg-purple-100 text-purple-700', dot: 'bg-purple-500',  bar: 'bg-purple-500',  icon: '🚗' },
  Others:    { pill: 'bg-slate-100 text-slate-600',   dot: 'bg-slate-400',   bar: 'bg-slate-400',   icon: '📦' },
};

const cfg = c => CAT_CONFIG[c] || CAT_CONFIG.Others;

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [modal, setModal]       = useState(false);
  const [filterCat, setFilterCat] = useState('All');
  const [search, setSearch]     = useState('');
  const [form, setForm]         = useState({ title: '', amount: '', category: 'Utility' });

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'expenses'), orderBy('createdAt', 'desc')),
      snap => {
        setExpenses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.title.trim() || !form.amount) { toast.error('Please fill all fields'); return; }
    try {
      await addExpense({ ...form, amount: parseFloat(form.amount) });
      toast.success('Expense recorded');
      setModal(false);
      setForm({ title: '', amount: '', category: 'Utility' });
    } catch { toast.error('Failed to record expense'); }
  };

  const handleDelete = async id => {
    if (!window.confirm('Delete this expense?')) return;
    try { await deleteExpense(id); toast.success('Expense deleted'); }
    catch { toast.error('Failed to delete'); }
  };

  const total    = expenses.reduce((s, e) => s + (e.amount || 0), 0);
  const avg      = expenses.length > 0 ? total / expenses.length : 0;
  const highest  = expenses.reduce((m, e) => Math.max(m, e.amount || 0), 0);

  const categoryTotals = CATS.map(cat => ({
    cat,
    total: expenses.filter(e => e.category === cat).reduce((s, e) => s + (e.amount || 0), 0),
    count: expenses.filter(e => e.category === cat).length,
  }));

  const filtered = expenses.filter(e => {
    const matchCat = filterCat === 'All' || e.category === filterCat;
    const matchSearch = !search || e.title?.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const fmt = n => n.toLocaleString('en-IN', { maximumFractionDigits: 0 });

  return (
    <div className="min-h-screen p-4 sm:p-6 bg-slate-50">
      <div className="max-w-6xl mx-auto space-y-5">

        {/* ── Page Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Expenses</h1>
            <p className="text-sm text-slate-500 mt-0.5">Track and manage business costs</p>
          </div>
          <button
            onClick={() => setModal(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-white text-sm font-semibold rounded-xl transition-all shadow-lg active:scale-95 bg-gradient-to-br from-violet-600 to-blue-600"
          >
            <MdAdd className="text-lg" /> Record Expense
          </button>
        </div>

        {/* ── Stat Cards ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            {
              label: 'Total Expenses',
              value: `₹${fmt(total)}`,
              sub: `${expenses.length} entries`,
              icon: MdTrendingDown,
              gradient: 'bg-gradient-to-br from-purple-600 to-purple-700',
            },
            {
              label: 'Average per Entry',
              value: `₹${fmt(avg)}`,
              sub: 'Per expense',
              icon: MdReceiptLong,
              gradient: 'bg-gradient-to-br from-blue-600 to-blue-700',
            },
            {
              label: 'Highest Expense',
              value: `₹${fmt(highest)}`,
              sub: 'Single entry',
              icon: MdAttachMoney,
              gradient: 'bg-gradient-to-br from-purple-700 to-purple-800',
            },
          ].map(({ label, value, sub, icon: Icon, gradient }) => (
            <div key={label} className={`rounded-xl p-5 text-white shadow-lg ${gradient}`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mb-3">
                <Icon className="text-xl" />
              </div>
              <p className="text-xs font-semibold uppercase tracking-wider opacity-90 mb-1">{label}</p>
              <p className="text-3xl font-bold mb-1">{value}</p>
              <p className="text-xs opacity-80">{sub}</p>
            </div>
          ))}
        </div>

        {/* ── Category Breakdown ── */}
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 mb-4">
            <MdCategory className="text-slate-400 text-lg" />
            <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Category Breakdown</h2>
            {filterCat !== 'All' && (
              <button
                onClick={() => setFilterCat('All')}
                className="ml-auto text-xs font-semibold text-blue-600 hover:underline"
              >
                Clear filter
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {categoryTotals.map(({ cat, total: catTotal, count }) => {
              const pct = total > 0 ? (catTotal / total) * 100 : 0;
              const active = filterCat === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setFilterCat(active ? 'All' : cat)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                    active
                      ? 'border-slate-400 bg-slate-50 shadow-sm'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-base leading-none">{cfg(cat).icon}</span>
                    <span className={`text-xs font-bold uppercase tracking-wide ${cfg(cat).pill.split(' ')[1]}`}>{cat}</span>
                  </div>
                  <p className="text-sm font-bold text-slate-800">₹{fmt(catTotal)}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{count} entries</p>
                  <div className="mt-2 h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${cfg(cat).bar}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── Expenses Table ── */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          {/* Table header */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 px-4 py-3 border-b border-slate-100">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <MdReceiptLong className="text-slate-400 text-lg flex-shrink-0" />
              <h2 className="text-sm font-bold text-slate-700">
                {filterCat === 'All' ? 'All Expenses' : filterCat}
              </h2>
              <span className="text-xs font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                {filtered.length}
              </span>
            </div>
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition w-full sm:w-56">
              <MdSearch className="text-slate-400 text-base flex-shrink-0" />
              <input
                type="text"
                placeholder="Search expenses…"
                className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>

          {/* Desktop table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  {['Description', 'Category', 'Amount', 'Date', ''].map(h => (
                    <th
                      key={h}
                      className={`px-4 py-2.5 text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap ${h === 'Amount' ? 'text-right' : h === '' ? 'text-center w-12' : 'text-left'}`}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-10 text-center">
                      <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-12 text-center">
                      <MdReceiptLong className="text-4xl text-slate-300 mx-auto mb-2" />
                      <p className="text-sm text-slate-400">
                        {expenses.length === 0 ? 'No expenses recorded yet' : 'No expenses match your filter'}
                      </p>
                    </td>
                  </tr>
                ) : (
                  filtered.map(ex => (
                    <tr key={ex.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-4 py-3 font-medium text-slate-800">{ex.title}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full ${cfg(ex.category).pill}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${cfg(ex.category).dot}`} />
                          {ex.category}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-bold text-red-600 text-right">
                        ₹{ex.amount?.toLocaleString('en-IN')}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">
                        <span className="flex items-center gap-1.5">
                          <MdCalendarToday className="text-slate-300 text-xs" />
                          {ex.createdAt?.toDate
                            ? new Intl.DateTimeFormat('en-IN', { year: 'numeric', month: 'short', day: 'numeric' }).format(ex.createdAt.toDate())
                            : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleDelete(ex.id)}
                          className="w-8 h-8 inline-flex items-center justify-center text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition opacity-0 group-hover:opacity-100"
                        >
                          <MdDelete className="text-base" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile card list */}
          <div className="sm:hidden">
            {loading ? (
              <div className="p-8 flex justify-center">
                <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center">
                <MdReceiptLong className="text-4xl text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-400">
                  {expenses.length === 0 ? 'No expenses recorded yet' : 'No expenses match your filter'}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {filtered.map(ex => (
                  <div key={ex.id} className="p-4 hover:bg-slate-50 transition-colors">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 truncate">{ex.title}</p>
                        <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                          <MdCalendarToday className="text-xs" />
                          {ex.createdAt?.toDate
                            ? new Intl.DateTimeFormat('en-IN', { year: 'numeric', month: 'short', day: 'numeric' }).format(ex.createdAt.toDate())
                            : '—'}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDelete(ex.id)}
                        className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition flex-shrink-0"
                      >
                        <MdDelete className="text-base" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full ${cfg(ex.category).pill}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${cfg(ex.category).dot}`} />
                        {ex.category}
                      </span>
                      <p className="font-bold text-red-600">₹{ex.amount?.toLocaleString('en-IN')}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Add Expense Modal ── */}
      {modal && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4 animate-fade-in"
          onClick={e => e.target === e.currentTarget && setModal(false)}
        >
          <div className="bg-white w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden animate-slide-up">
            {/* Modal header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-red-50 rounded-xl flex items-center justify-center">
                  <MdTrendingDown className="text-red-500 text-xl" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-base">Record Expense</h2>
                  <p className="text-xs text-slate-400">Add a new business cost</p>
                </div>
              </div>
              <button
                onClick={() => setModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
              >
                <MdClose className="text-xl" />
              </button>
            </div>

            {/* Modal form */}
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                  Description
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Electricity bill, Office supplies"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition placeholder:text-slate-400"
                  value={form.title}
                  onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Amount (₹)
                  </label>
                  <input
                    type="number"
                    required
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition placeholder:text-slate-400"
                    value={form.amount}
                    onChange={e => setForm(p => ({ ...p, amount: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                    Category
                  </label>
                  <select
                    className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition"
                    value={form.category}
                    onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  >
                    {CATS.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              {/* Category preview */}
              <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border ${cfg(form.category).pill.replace('text-', 'border-').split(' ')[0]} bg-opacity-50`}>
                <span className="text-base">{cfg(form.category).icon}</span>
                <span className={`text-xs font-semibold ${cfg(form.category).pill.split(' ')[1]}`}>
                  {form.category} expense
                </span>
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-white text-sm font-semibold rounded-xl transition active:scale-95 shadow-md bg-gradient-to-br from-violet-600 to-blue-600"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
