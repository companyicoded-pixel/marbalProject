import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { approveBill, rejectBill, BILL_CATEGORIES } from '../../../services/billService';
import { generateInvoice, shareOnWhatsApp } from '../../../services/reportService';
import toast from 'react-hot-toast';
import { MdCheck, MdClose, MdVisibility, MdSearch, MdShare, MdReceipt, MdFilterList } from 'react-icons/md';

const statusCls = s =>
  s==='approved' ? 'bg-emerald-100 text-emerald-700' :
  s==='pending'  ? 'bg-amber-100 text-amber-700' :
                   'bg-red-100 text-red-600';

export default function ReviewBills() {
  const [bills, setBills]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [filter, setFilter]     = useState('pending');
  const [catFilter, setCatFilter] = useState('All');
  const [search, setSearch]     = useState('');

  useEffect(() => {
    const unsub = onSnapshot(query(collection(db,'bills'), orderBy('createdAt','desc')), snap => {
      setBills(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleApprove = async bill => {
    try { await approveBill(bill.id, bill.items, 'Admin'); toast.success('Approved!'); generateInvoice(bill); }
    catch { toast.error('Approval failed'); }
  };
  const handleReject = async id => {
    const note = window.prompt('Rejection reason:');
    if (note === null) return;
    try { await rejectBill(id, 'Admin', note); toast.success('Rejected'); }
    catch { toast.error('Failed'); }
  };

  const filtered = bills.filter(b =>
    (filter==='all' || b.status===filter) &&
    (catFilter==='All' || b.category===catFilter) &&
    (b.customerName?.toLowerCase().includes(search.toLowerCase()) || b.customerContact?.includes(search))
  );

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-white border-b border-slate-200 px-4 sm:px-6 py-4 flex-shrink-0">
        <h1 className="text-xl font-bold text-slate-800 mb-1">Review Bills</h1>
        <p className="text-sm text-slate-500 mb-4">Approve or reject submitted bills</p>
        <div className="flex flex-wrap gap-2">
          <div className="flex-1 min-w-[160px] flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500 transition">
            <MdSearch className="text-slate-400 text-lg flex-shrink-0" />
            <input type="text" placeholder="Search customer…" className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2">
            <MdFilterList className="text-slate-400 text-base" />
            <select className="text-sm outline-none bg-transparent text-slate-700 font-medium cursor-pointer"
              value={filter} onChange={e => setFilter(e.target.value)}>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              <option value="all">All</option>
            </select>
          </div>
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2">
            <select className="text-sm outline-none bg-transparent text-slate-700 font-medium cursor-pointer"
              value={catFilter} onChange={e => setCatFilter(e.target.value)}>
              <option value="All">All Categories</option>
              {BILL_CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Bills */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
        {loading && <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>}

        {!loading && filtered.map(bill => (
          <div key={bill.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
            <div className="p-4 flex flex-wrap gap-4 items-start">
              {/* ID & status */}
              <div className="min-w-[130px]">
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">Bill Ref</p>
                <p className="font-mono text-xs font-bold text-slate-700 mb-2">#{bill.id.slice(0,10).toUpperCase()}</p>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${statusCls(bill.status)}`}>{bill.status}</span>
              </div>

              {/* Customer */}
              <div className="flex-1 min-w-[140px]">
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">Customer</p>
                <p className="font-bold text-slate-800 text-sm">{bill.customerName || 'Walk-in'}</p>
                <p className="text-xs text-slate-500">{bill.customerContact || '—'}</p>
                <p className="text-xs text-slate-400 italic truncate max-w-[200px]">{bill.customerAddress || '—'}</p>
              </div>

              {/* Details */}
              <div className="min-w-[120px] hidden sm:block">
                <div className="space-y-1">
                  {[['Payment', bill.paymentMode||'Cash'], ['Date', bill.createdAt?.toDate().toLocaleDateString()], ['Seller', bill.sellerName]].map(([k,v]) => (
                    <div key={k} className="flex justify-between gap-3">
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">{k}</span>
                      <span className="text-xs font-semibold text-slate-700">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Amount & actions */}
              <div className="flex flex-col items-end gap-3 ml-auto">
                <div className="text-right">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase">Amount</p>
                  <p className="text-2xl font-bold text-blue-700">₹{bill.totalAmount?.toLocaleString()}</p>
                </div>
                <div className="flex gap-2">
                  {bill.status === 'pending' ? (
                    <>
                      <button onClick={() => handleApprove(bill)} className="w-9 h-9 flex items-center justify-center bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl transition active:scale-95">
                        <MdCheck className="text-lg" />
                      </button>
                      <button onClick={() => handleReject(bill.id)} className="w-9 h-9 flex items-center justify-center bg-red-500 hover:bg-red-600 text-white rounded-xl transition active:scale-95">
                        <MdClose className="text-lg" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => generateInvoice(bill)} className="w-9 h-9 flex items-center justify-center bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-600 rounded-xl transition active:scale-95">
                        <MdVisibility className="text-lg" />
                      </button>
                      {bill.customerContact && (
                        <button onClick={() => shareOnWhatsApp(bill)} className="w-9 h-9 flex items-center justify-center bg-emerald-50 hover:bg-emerald-500 hover:text-white text-emerald-600 rounded-xl transition active:scale-95">
                          <MdShare className="text-lg" />
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Items */}
            {bill.items?.length > 0 && (
              <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-1.5">
                {bill.items.map((item, i) => (
                  <span key={i} className="text-[10px] font-semibold bg-white border border-slate-200 text-slate-600 px-2 py-0.5 rounded-full">
                    {item.name} ×{item.quantity}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}

        {!loading && filtered.length === 0 && (
          <div className="text-center py-16">
            <MdReceipt className="text-5xl text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-400 font-medium">No bills found</p>
          </div>
        )}
      </div>
    </div>
  );
}
