import React, { useEffect, useState } from 'react';
import {
  collection, onSnapshot, addDoc, deleteDoc, doc,
  query, orderBy, serverTimestamp
} from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdAdd, MdDelete, MdLayers, MdSearch } from 'react-icons/md';
import toast from 'react-hot-toast';

export default function CategoriesPage() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [newCat, setNewCat]         = useState('');
  const [search, setSearch]         = useState('');
  const [adding, setAdding]         = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'categories'), orderBy('createdAt', 'desc')),
      snap => {
        setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const handleAdd = async e => {
    e.preventDefault();
    if (!newCat.trim()) return;
    if (categories.some(c => c.name.toLowerCase() === newCat.trim().toLowerCase())) {
      toast.error('Category already exists');
      return;
    }
    setAdding(true);
    try {
      await addDoc(collection(db, 'categories'), { name: newCat.trim(), createdAt: serverTimestamp() });
      setNewCat('');
      toast.success('Category added');
    } catch { toast.error('Failed to add'); }
    finally { setAdding(false); }
  };

  const handleDelete = async id => {
    if (!window.confirm('Delete this category?')) return;
    try { await deleteDoc(doc(db, 'categories', id)); toast.success('Category removed'); }
    catch { toast.error('Failed to delete'); }
  };

  const filtered = categories.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-5">

      {/* ── Header ── */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Categories</h1>
        <p className="text-sm text-slate-500 mt-0.5">Manage product categories</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

        {/* ── Add Form ── */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 h-fit">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-md shadow-blue-200">
              <MdAdd className="text-white text-xl" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">Add Category</h2>
              <p className="text-xs text-slate-400">{categories.length} categories total</p>
            </div>
          </div>

          <form onSubmit={handleAdd} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">
                Category Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Italian Granite"
                className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400"
                value={newCat}
                onChange={e => setNewCat(e.target.value)}
              />
            </div>
            <button
              type="submit"
              disabled={adding || !newCat.trim()}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition active:scale-95"
            >
              {adding ? 'Adding…' : 'Add Category'}
            </button>
          </form>
        </div>

        {/* ── Category List ── */}
        <div className="space-y-3">
          {/* Search */}
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition">
            <MdSearch className="text-slate-400 text-lg flex-shrink-0" />
            <input
              type="text"
              placeholder="Search categories…"
              className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          {/* List */}
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-xl">
                <MdLayers className="text-3xl text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-400">
                  {categories.length === 0 ? 'No categories yet' : 'No matches found'}
                </p>
              </div>
            ) : (
              filtered.map((cat, i) => (
                <div
                  key={cat.id}
                  className="flex items-center justify-between bg-white border border-slate-200 rounded-xl px-4 py-3 hover:border-blue-300 hover:shadow-sm transition group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MdLayers className="text-blue-600 text-base" />
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800 text-sm">{cat.name}</span>
                      <p className="text-[10px] text-slate-400">#{i + 1}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDelete(cat.id)}
                    className="w-7 h-7 flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition opacity-0 group-hover:opacity-100"
                  >
                    <MdDelete className="text-base" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
