import React from 'react';
import { MdSettings, MdColorLens, MdNotificationsActive, MdSecurity, MdLanguage, MdHelpOutline, MdChevronRight } from 'react-icons/md';

const Item = ({ icon: Icon, title, desc, action, iconBg = 'bg-blue-50', iconColor = 'text-blue-600' }) => (
  <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:shadow-md hover:border-blue-200 transition cursor-pointer group">
    <div className="flex items-center gap-3">
      <div className={`w-10 h-10 ${iconBg} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform`}>
        <Icon className={`text-xl ${iconColor}`} />
      </div>
      <div>
        <p className="font-semibold text-slate-800 text-sm">{title}</p>
        <p className="text-xs text-slate-500 mt-0.5">{desc}</p>
      </div>
    </div>
    <div className="flex items-center gap-2 flex-shrink-0">
      {action && <span className="text-xs font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">{action}</span>}
      <MdChevronRight className="text-slate-300 text-lg" />
    </div>
  </div>
);

export default function SettingsPage() {
  return (
    <div className="p-4 sm:p-6 max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Settings</h1>
        <p className="text-sm text-slate-500 mt-0.5">System preferences & configuration</p>
      </div>

      {[
        {
          section: 'Personalization',
          items: [
            { icon: MdColorLens,           title: 'Visual Theme',    desc: 'Adjust interface appearance',          action: 'Default',      iconBg:'bg-purple-50', iconColor:'text-purple-600' },
            { icon: MdLanguage,            title: 'Region & Language', desc: 'Currency and date format settings',  action: 'English (IN)', iconBg:'bg-cyan-50',   iconColor:'text-cyan-600' },
          ]
        },
        {
          section: 'Security',
          items: [
            { icon: MdSecurity,            title: 'Two-Factor Auth',  desc: 'Enhance login security',              action: 'Enabled',      iconBg:'bg-emerald-50', iconColor:'text-emerald-600' },
            { icon: MdNotificationsActive, title: 'Notifications',    desc: 'Low-stock and sale alerts',           iconBg:'bg-amber-50',   iconColor:'text-amber-600' },
          ]
        },
        {
          section: 'Support',
          items: [
            { icon: MdHelpOutline,         title: 'System Diagnostics', desc: 'Run a health check on the system', action: 'Run Audit',    iconBg:'bg-slate-100', iconColor:'text-slate-500' },
          ]
        },
      ].map(({ section, items }) => (
        <div key={section}>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">{section}</p>
          <div className="space-y-2">
            {items.map(item => <Item key={item.title} {...item} />)}
          </div>
        </div>
      ))}

      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl p-5 text-white">
        <p className="text-xs text-blue-300 uppercase tracking-wide font-semibold mb-1">Software Version</p>
        <p className="text-2xl font-bold mb-2">Marble Pro v4.6.2</p>
        <p className="text-sm text-blue-200 leading-relaxed">All transactions are end-to-end encrypted and audited by the central server.</p>
      </div>
    </div>
  );
}
