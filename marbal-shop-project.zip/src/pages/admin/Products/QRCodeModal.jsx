import React from 'react';
import { MdClose, MdPrint } from 'react-icons/md';
import { QRCodeSVG } from 'qrcode.react';

export default function QRCodeModal({ isOpen, onClose, product }) {
  if (!isOpen || !product) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-xs rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden animate-slide-up">
        <div className="h-1 bg-blue-600" />
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800">Product QR Code</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 transition">
            <MdClose className="text-xl" />
          </button>
        </div>
        <div className="p-5 text-center">
          <p className="text-sm font-semibold text-slate-700 mb-4">{product.name}</p>
          <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 flex flex-col items-center mb-4">
            <div className="bg-white p-3 rounded-xl shadow-md mb-3">
              <QRCodeSVG value={product.sku} size={150} />
            </div>
            <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide mb-1">SKU Code</p>
            <p className="font-bold text-blue-700 font-mono">{product.sku}</p>
          </div>
          <button onClick={() => window.print()}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition">
            <MdPrint className="text-lg" /> Print Label
          </button>
        </div>
      </div>
    </div>
  );
}
