import React, { useEffect, useState, useRef } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import toast from 'react-hot-toast';
import AddProductModal from './AddProductModal';
import EditProductModal from './EditProductModal';
import ProductTile from './ProductTile';
import QRCodeModal from './QRCodeModal';
import { MdSearch, MdFilterList, MdAdd, MdViewModule, MdViewList, MdFileDownload } from 'react-icons/md';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import QRCode from 'qrcode';

export default function ProductList() {
  const [products, setProducts]         = useState([]);
  const [loading, setLoading]           = useState(true);
  const [isAddOpen, setIsAddOpen]       = useState(false);
  const [isEditOpen, setIsEditOpen]     = useState(false);
  const [isQROpen, setIsQROpen]         = useState(false);
  const [selected, setSelected]         = useState(null);
  const [search, setSearch]             = useState('');
  const [viewMode, setViewMode]         = useState('grid');
  const [downloading, setDownloading]   = useState(false);
  const [categories, setCategories]     = useState([]);
  const [catFilter, setCatFilter]       = useState('All');
  const canvasRef = useRef(null);

  useEffect(() => {
    const u1 = onSnapshot(query(collection(db,'products'), orderBy('createdAt','desc')), snap => {
      setProducts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    const u2 = onSnapshot(query(collection(db,'categories'), orderBy('createdAt','desc')), snap => {
      setCategories(snap.docs.map(d => d.data().name));
    });
    return () => { u1(); u2(); };
  }, []);

  const downloadAllQRs = async () => {
    if (!products.length) return;
    setDownloading(true);
    const doc = new jsPDF();
    const canvas = canvasRef.current;
    doc.setFontSize(18); doc.setFont('helvetica','bold'); doc.setTextColor(37,99,235);
    doc.text('PRODUCT LABEL SHEET', 105, 16, { align:'center' });
    doc.setFontSize(9); doc.setFont('helvetica','normal'); doc.setTextColor(150);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 105, 23, { align:'center' });
    doc.line(20, 27, 190, 27);
    let x=20, y=38, qrSize=44, margin=14, perPage=9;
    for (let i=0; i<products.length; i++) {
      const p = products[i];
      if (i>0 && i%perPage===0) { doc.addPage(); x=20; y=38; }
      try {
        await QRCode.toCanvas(canvas, p.sku, { margin:1, width:200, color:{ dark:'#2563eb', light:'#ffffff' } });
        const img = canvas.toDataURL('image/png');
        doc.setDrawColor(230); doc.setFillColor(252,252,252);
        doc.roundedRect(x-2, y-8, qrSize+4, qrSize+22, 3, 3, 'FD');
        doc.setFontSize(8); doc.setFont('helvetica','bold'); doc.setTextColor(0);
        doc.text(p.name.substring(0,22), x, y-2);
        doc.setFontSize(7); doc.setFont('helvetica','normal'); doc.setTextColor(100);
        doc.text(`SKU: ${p.sku}`, x, y+2);
        doc.addImage(img, 'PNG', x, y+4, qrSize, qrSize);
        x += qrSize+margin;
        if (x>160) { x=20; y+=qrSize+margin+14; }
      } catch {}
    }
    doc.save(`Labels_${Date.now()}.pdf`);
    setDownloading(false);
    toast.success('Labels downloaded!');
  };

  const filtered = products.filter(p => {
    const q = search.toLowerCase();
    return (p.name?.toLowerCase().includes(q) || p.category?.toLowerCase().includes(q) || p.sku?.toLowerCase().includes(q))
      && (catFilter === 'All' || p.category === catFilter);
  });

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="flex flex-col h-full">
      <canvas ref={canvasRef} className="hidden" />

      {/* Header */}
      <div className="bg-gradient-to-r from-blue-50 to-white border-b border-slate-200 px-4 sm:px-6 py-4 flex-shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h1 className="text-xl font-bold text-slate-800">Inventory</h1>
            <p className="text-sm text-slate-500">{products.length} products</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={downloadAllQRs} disabled={downloading}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border border-slate-200 bg-white text-slate-600 hover:border-blue-400 hover:text-blue-600 rounded-xl transition disabled:opacity-50">
              <MdFileDownload className="text-base" />
              <span className="hidden sm:inline">{downloading ? 'Generating…' : 'Labels'}</span>
            </button>
            <button onClick={() => setIsAddOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition shadow-md shadow-blue-200">
              <MdAdd className="text-base" /> Add Product
            </button>
          </div>
        </div>

        {/* Search & filter */}
        <div className="flex gap-2 flex-wrap">
          <div className="flex-1 min-w-[180px] flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition">
            <MdSearch className="text-slate-400 text-lg flex-shrink-0" />
            <input type="text" placeholder="Search name, SKU, category…" className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2">
            <MdFilterList className="text-slate-400 text-base" />
            <select className="text-sm outline-none bg-transparent text-slate-700 font-medium cursor-pointer"
              value={catFilter} onChange={e => setCatFilter(e.target.value)}>
              <option value="All">All Categories</option>
              {categories.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="px-4 sm:px-6 py-3 flex items-center justify-between bg-white border-b border-slate-100 flex-shrink-0">
        <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
          {[{ m:'grid', I:MdViewModule }, { m:'list', I:MdViewList }].map(({ m, I }) => (
            <button key={m} onClick={() => setViewMode(m)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-semibold transition ${viewMode===m ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
              <I className="text-base" /> {m.charAt(0).toUpperCase()+m.slice(1)}
            </button>
          ))}
        </div>
        <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">{filtered.length} results</span>
      </div>

      {/* Products */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        {filtered.length === 0
          ? <div className="text-center py-16 text-slate-400 text-sm">No products found</div>
          : <div className={viewMode === 'grid'
              ? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3'
              : 'flex flex-col gap-2'}>
              {filtered.map(p => (
                <ProductTile key={p.id} product={p} viewMode={viewMode}
                  onEdit={x => { setSelected(x); setIsEditOpen(true); }}
                  onViewQR={x => { setSelected(x); setIsQROpen(true); }} />
              ))}
            </div>
        }
      </div>

      <AddProductModal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} onProductAdded={() => {}} />
      <EditProductModal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} product={selected} onProductUpdated={() => setIsEditOpen(false)} />
      <QRCodeModal isOpen={isQROpen} onClose={() => setIsQROpen(false)} product={selected} />
    </div>
  );
}
