import React from 'react';
import { MdQrCodeScanner, MdEdit } from 'react-icons/md';

export default function ProductTile({ product, onEdit, onViewQR, viewMode }) {
  const low = (product.quantity || 0) < 10;

  if (viewMode === 'list') return (
    <div className="bg-white rounded-xl border border-slate-200 p-3 flex items-center gap-3 hover:shadow-md transition-shadow">
      <div className="w-12 h-12 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
        <img src={product.image || `https://ui-avatars.com/api/?name=${product.name}&background=dbeafe&color=2563eb&bold=true`}
          alt={product.name} className="w-full h-full object-cover" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
          <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded-full uppercase">{product.category}</span>
          <span className="text-[10px] text-slate-400 font-mono">#{product.sku}</span>
        </div>
        <p className="font-bold text-slate-800 text-sm truncate">{product.name}</p>
      </div>
      <div className="hidden sm:flex items-center gap-6 border-x border-slate-100 px-4 flex-shrink-0">
        <div className="text-center">
          <p className="text-[10px] text-slate-400 font-semibold uppercase">Price</p>
          <p className="font-bold text-blue-700 text-sm">₹{product.price?.toLocaleString()}</p>
        </div>
        <div className="text-center">
          <p className="text-[10px] text-slate-400 font-semibold uppercase">Stock</p>
          <p className={`font-bold text-sm ${low ? 'text-red-500' : 'text-slate-800'}`}>{product.quantity}</p>
        </div>
      </div>
      <div className="flex gap-1.5 flex-shrink-0">
        <button onClick={() => onViewQR(product)} className="w-8 h-8 flex items-center justify-center bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-500 rounded-lg transition">
          <MdQrCodeScanner className="text-base" />
        </button>
        <button onClick={() => onEdit(product)} className="w-8 h-8 flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
          <MdEdit className="text-base" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative h-40 bg-slate-100 overflow-hidden">
        <img src={product.image || `https://ui-avatars.com/api/?name=${product.name}&background=dbeafe&color=2563eb&bold=true&size=256`}
          alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        <div className="absolute top-2 left-2">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${low ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white'}`}>
            {low ? 'Low Stock' : 'In Stock'}
          </span>
        </div>
        <div className="absolute top-2 right-2">
          <span className="text-[10px] font-semibold bg-white/90 text-slate-700 px-2 py-0.5 rounded-full">{product.category}</span>
        </div>
      </div>
      <div className="p-3">
        <p className="font-bold text-slate-800 text-sm leading-tight mb-2 truncate">{product.name}</p>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="bg-slate-50 rounded-lg p-2">
            <p className="text-[10px] text-slate-400 font-semibold uppercase">Stock</p>
            <p className={`font-bold text-sm ${low ? 'text-red-500' : 'text-slate-800'}`}>{product.quantity} <span className="text-[10px] text-slate-400">units</span></p>
          </div>
          <div className="bg-slate-50 rounded-lg p-2">
            <p className="text-[10px] text-slate-400 font-semibold uppercase">SKU</p>
            <p className="font-bold text-xs text-slate-700 font-mono truncate">{product.sku?.slice(0,10)}</p>
          </div>
        </div>
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <p className="text-lg font-bold text-blue-700">₹{product.price?.toLocaleString()}</p>
          <div className="flex gap-1.5">
            <button onClick={() => onViewQR(product)} className="w-8 h-8 flex items-center justify-center bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-500 rounded-lg transition">
              <MdQrCodeScanner className="text-base" />
            </button>
            <button onClick={() => onEdit(product)} className="w-8 h-8 flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
              <MdEdit className="text-base" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
