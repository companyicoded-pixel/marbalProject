import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { addProduct } from '../../../services/productService';
import toast from 'react-hot-toast';
import { MdAdd, MdDownload, MdQrCode } from 'react-icons/md';

const inputCls = 'w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all placeholder:text-slate-400';
const labelCls = 'block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5';

export default function AddProduct() {
  const [formData,    setFormData]    = useState({ name: '', price: '', stock: '', category: '', description: '' });
  const [generatedId, setGeneratedId] = useState('');
  const [loading,     setLoading]     = useState(false);

  const set = (key, val) => setFormData(p => ({ ...p, [key]: val }));

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      const id = await addProduct(formData);
      setGeneratedId(id);
      toast.success('Product added successfully!');
      setFormData({ name: '', price: '', stock: '', category: '', description: '' });
    } catch {
      toast.error('Error adding product');
    } finally {
      setLoading(false);
    }
  };

  const downloadQR = () => {
    const svg    = document.getElementById('ProductQR');
    const data   = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx    = canvas.getContext('2d');
    const img    = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      const a = document.createElement('a');
      a.download = `${formData.name || 'product'}-QR.png`;
      a.href = canvas.toDataURL('image/png');
      a.click();
    };
    img.src = `data:image/svg+xml;base64,${btoa(data)}`;
  };

  return (
    <div className="p-4 sm:p-6 bg-slate-100 min-h-full">
      <div className="max-w-4xl mx-auto space-y-5">

        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Add New Product</h1>
          <p className="text-sm text-slate-500 mt-0.5">Fill in the details to add a product to inventory.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

          {/* ── Form Card ── */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-md shadow-blue-200">
                <MdAdd className="text-white text-xl" />
              </div>
              <div>
                <h2 className="font-bold text-slate-800">Product Details</h2>
                <p className="text-xs text-slate-400">All fields marked * are required</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className={labelCls}>Product Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Italian Marble Slab"
                  className={inputCls}
                  value={formData.name}
                  onChange={e => set('name', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Price (₹) *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    className={inputCls}
                    value={formData.price}
                    onChange={e => set('price', e.target.value)}
                  />
                </div>
                <div>
                  <label className={labelCls}>Stock Qty *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="0"
                    className={inputCls}
                    value={formData.stock}
                    onChange={e => set('stock', e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className={labelCls}>Category</label>
                <input
                  type="text"
                  placeholder="e.g. Granite, Marble"
                  className={inputCls}
                  value={formData.category}
                  onChange={e => set('category', e.target.value)}
                />
              </div>

              <div>
                <label className={labelCls}>Description</label>
                <textarea
                  rows={3}
                  placeholder="Optional product description…"
                  className={`${inputCls} resize-none`}
                  value={formData.description}
                  onChange={e => set('description', e.target.value)}
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`w-full flex items-center justify-center gap-2 py-3 text-white text-sm font-bold rounded-xl transition-all active:scale-95 shadow-lg shadow-blue-200 ${
                  loading
                    ? 'bg-blue-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700'
                }`}
              >
                {loading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Adding Product…
                  </>
                ) : (
                  <>
                    <MdAdd className="text-lg" />
                    Add Product & Generate QR
                  </>
                )}
              </button>
            </form>
          </div>

          {/* ── QR Card ── */}
          <div className="bg-white rounded-2xl border-2 border-dashed border-slate-200 shadow-sm p-6 flex flex-col items-center justify-center min-h-64">
            {generatedId ? (
              <div className="text-center w-full">
                <div className="flex items-center gap-2 justify-center mb-5">
                  <MdQrCode className="text-blue-600 text-lg" />
                  <p className="text-sm font-bold text-slate-800">Product QR Code</p>
                </div>
                <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-100 inline-block mb-5">
                  <QRCodeSVG id="ProductQR" value={generatedId} size={180} />
                </div>
                <p className="text-xs text-slate-400 mb-4 font-mono break-all px-2">{generatedId}</p>
                <button
                  onClick={downloadQR}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white text-sm font-semibold rounded-xl border border-blue-200 hover:border-blue-600 transition-all"
                >
                  <MdDownload className="text-base" />
                  Download QR
                </button>
              </div>
            ) : (
              <div className="text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <MdQrCode className="text-slate-400 text-3xl" />
                </div>
                <p className="text-sm font-semibold text-slate-600">QR code will appear here</p>
                <p className="text-xs text-slate-400 mt-1">after adding the product</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
