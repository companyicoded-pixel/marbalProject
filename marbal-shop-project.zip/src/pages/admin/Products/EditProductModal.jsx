import React, { useState, useEffect } from 'react';
import { updateProduct } from '../../../services/productService';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import toast from 'react-hot-toast';
import { MdClose, MdSave } from 'react-icons/md';

const inputCls = "w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400";
const labelCls = "block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide";

export default function EditProductModal({ isOpen, onClose, product, onProductUpdated }) {
  const [form, setForm]       = useState({ name:'', price:'', quantity:'', category:'', description:'' });
  const [cats, setCats]       = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const q = query(collection(db,'categories'), orderBy('createdAt','desc'));
    const unsub = onSnapshot(q, snap => setCats(snap.docs.map(d => d.data().name)));
    return () => unsub();
  }, [isOpen]);

  useEffect(() => {
    if (product) setForm({ name: product.name||'', price: product.price||'', quantity: product.quantity||'', category: product.category||'', description: product.description||'' });
  }, [product]);

  if (!isOpen || !product) return null;

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProduct(product.id, { ...form, price: parseFloat(form.price), quantity: parseInt(form.quantity) });
      toast.success('Product updated!');
      onProductUpdated();
      onClose();
    } catch { toast.error('Update failed'); } finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden animate-slide-up">
        <div className="h-1 bg-blue-600" />
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800">Edit Product</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 transition">
            <MdClose className="text-xl" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className={labelCls}>Product Name</label>
            <input type="text" required className={inputCls} value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Price (₹)</label>
              <input type="number" step="0.01" required className={inputCls} value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} />
            </div>
            <div>
              <label className={labelCls}>Quantity</label>
              <input type="number" required className={inputCls} value={form.quantity} onChange={e => setForm(p => ({ ...p, quantity: e.target.value }))} />
            </div>
          </div>
          <div>
            <label className={labelCls}>Category</label>
            <select className={inputCls} value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}>
              {cats.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>Description</label>
            <textarea className={inputCls} rows={2} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
          </div>
          <button type="submit" disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition disabled:opacity-50">
            {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <MdSave className="text-lg" />}
            {loading ? 'Saving…' : 'Save Changes'}
          </button>
        </form>
      </div>
    </div>
  );
}
