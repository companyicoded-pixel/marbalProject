import React, { useState, useEffect } from 'react';
import { addProduct } from '../../../services/productService';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import toast from 'react-hot-toast';
import { MdClose, MdCloudUpload, MdCheckCircle, MdPrint, MdImage } from 'react-icons/md';
import { QRCodeSVG } from 'qrcode.react';

const inputCls = "w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400";
const labelCls = "block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide";

export default function AddProductModal({ isOpen, onClose, onProductAdded }) {
  const [form, setForm]       = useState({ name:'', price:'', quantity:'', category:'', description:'', image:'' });
  const [cats, setCats]       = useState([]);
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(null);

  useEffect(() => {
    if (!isOpen) return;
    const q = query(collection(db,'categories'), orderBy('createdAt','desc'));
    const unsub = onSnapshot(q, snap => {
      const c = snap.docs.map(d => d.data().name);
      setCats(c);
      if (c.length && !form.category) setForm(p => ({ ...p, category: c[0] }));
    });
    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImg = e => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onloadend = () => setForm(p => ({ ...p, image: r.result }));
    r.readAsDataURL(f);
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.category) { toast.error('Select a category first'); return; }
    setLoading(true);
    try {
      const p = await addProduct({ ...form, price: parseFloat(form.price), quantity: parseInt(form.quantity) });
      setCreated(p);
      toast.success('Product added!');
      onProductAdded();
      setForm({ name:'', price:'', quantity:'', category: cats[0]||'', description:'', image:'' });
    } catch { toast.error('Failed to add product'); } finally { setLoading(false); }
  };

  const handleClose = () => { setCreated(null); onClose(); };

  const printQR = () => {
    const w = window.open('','_blank');
    const svg = document.getElementById('new-product-qr').outerHTML;
    w.document.write(`<html><body style="display:flex;flex-direction:column;align-items:center;padding:40px;font-family:sans-serif"><h2>${created.name}</h2>${svg}<p style="font-size:18px;font-weight:bold;margin-top:12px">SKU: ${created.sku}</p><script>window.onload=()=>{window.print();window.close()}<\/script></body></html>`);
    w.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden animate-slide-up">
        <div className="h-1 bg-blue-600" />

        {created ? (
          <div className="p-6 text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MdCheckCircle className="text-4xl text-emerald-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 mb-1">Product Added!</h2>
            <p className="text-xs text-slate-500 mb-5 font-mono">SKU: {created.sku}</p>
            <div className="bg-slate-50 rounded-xl p-5 flex flex-col items-center mb-5 border border-slate-200">
              <div className="bg-white p-3 rounded-xl shadow-md mb-3">
                <QRCodeSVG id="new-product-qr" value={created.sku} size={140} />
              </div>
              <p className="text-xs text-slate-500 font-semibold uppercase tracking-wide">Scan to identify</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={printQR} className="flex items-center justify-center gap-2 py-2.5 border-2 border-slate-200 text-slate-600 hover:border-blue-500 hover:text-blue-600 rounded-xl text-sm font-semibold transition">
                <MdPrint /> Print
              </button>
              <button onClick={handleClose} className="py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition">
                Done
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <h2 className="font-bold text-slate-800">Add New Product</h2>
              <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 transition">
                <MdClose className="text-xl" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Image upload */}
              <div className="relative border-2 border-dashed border-slate-200 rounded-xl p-4 text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/30 transition group">
                <input type="file" accept="image/*" onChange={handleImg} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                {form.image
                  ? <img src={form.image} alt="preview" className="w-16 h-16 object-cover rounded-xl mx-auto" />
                  : <div className="flex flex-col items-center gap-1.5">
                      <MdImage className="text-3xl text-slate-300 group-hover:text-blue-400 transition" />
                      <p className="text-xs text-slate-400 font-medium">Click to upload image</p>
                    </div>
                }
              </div>

              <div>
                <label className={labelCls}>Product Name</label>
                <input type="text" required className={inputCls} placeholder="e.g. Italian Statuario White"
                  value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Price (₹)</label>
                  <input type="number" step="0.01" required className={inputCls} placeholder="0.00"
                    value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} />
                </div>
                <div>
                  <label className={labelCls}>Quantity</label>
                  <input type="number" required className={inputCls} placeholder="0"
                    value={form.quantity} onChange={e => setForm(p => ({ ...p, quantity: e.target.value }))} />
                </div>
              </div>
              <div>
                <label className={labelCls}>Category</label>
                <select className={inputCls} value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}>
                  {cats.length ? cats.map(c => <option key={c}>{c}</option>) : <option disabled>No categories — create one first</option>}
                </select>
              </div>
              <div>
                <label className={labelCls}>Description</label>
                <textarea className={inputCls} rows={2} placeholder="Optional notes…"
                  value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
              </div>
              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition disabled:opacity-50">
                {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <MdCloudUpload className="text-lg" />}
                {loading ? 'Saving…' : 'Add Product'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
