import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase/config';
import { MdPersonAdd, MdShield, MdBadge, MdDelete, MdPeople, MdSearch, MdAdminPanelSettings, MdStorefront } from 'react-icons/md';

export default function UsersPage() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'users'), orderBy('createdAt', 'desc')),
      snap => {
        setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const filtered = users.filter(u =>
    !search ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.name?.toLowerCase().includes(search.toLowerCase())
  );

  const admins  = users.filter(u => u.role === 'admin').length;
  const sellers = users.filter(u => u.role === 'seller').length;

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-5">

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Staff Accounts</h1>
          <p className="text-sm text-slate-500 mt-0.5">Manage system users and roles</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-blue-200 active:scale-95">
          <MdPersonAdd className="text-lg" /> Add User
        </button>
      </div>

      {/* ── Stats ── */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total',   count: users.length, icon: MdPeople,              cls: 'text-blue-700',    bg: 'bg-blue-50' },
          { label: 'Admins',  count: admins,        icon: MdAdminPanelSettings,  cls: 'text-purple-700',  bg: 'bg-purple-50' },
          { label: 'Sellers', count: sellers,       icon: MdStorefront,          cls: 'text-emerald-700', bg: 'bg-emerald-50' },
        ].map(({ label, count, icon: Icon, cls, bg }) => (
          <div key={label} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${bg}`}>
              <Icon className={`text-xl ${cls}`} />
            </div>
            <div>
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide">{label}</p>
              <p className="text-xl font-bold text-slate-800 leading-tight">{count}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2.5 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition">
        <MdSearch className="text-slate-400 text-lg flex-shrink-0" />
        <input
          type="text"
          placeholder="Search by name or email…"
          className="flex-1 text-sm outline-none bg-transparent placeholder:text-slate-400"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        {search && (
          <button onClick={() => setSearch('')} className="text-xs text-slate-400 hover:text-slate-600 font-semibold">
            Clear
          </button>
        )}
      </div>

      {/* ── User Grid ── */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-slate-200 rounded-xl">
          <MdPeople className="text-5xl text-slate-300 mx-auto mb-3" />
          <p className="text-sm text-slate-400 font-medium">
            {users.length === 0 ? 'No users yet' : 'No users match your search'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(user => (
            <div
              key={user.id}
              className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md transition-shadow group relative"
            >
              {/* Delete button */}
              <button className="absolute top-3 right-3 w-7 h-7 flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition opacity-0 group-hover:opacity-100">
                <MdDelete className="text-base" />
              </button>

              {/* Avatar + name */}
              <div className="flex items-center gap-3 mb-3 pr-8">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg font-bold flex-shrink-0 ${
                  user.role === 'admin'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-200'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {user.email?.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="font-bold text-slate-800 text-sm truncate">
                    {user.name || user.email?.split('@')[0]}
                  </p>
                  <span className={`text-[10px] font-bold uppercase tracking-wide ${
                    user.role === 'admin' ? 'text-blue-600' : 'text-emerald-600'
                  }`}>
                    {user.role}
                  </span>
                </div>
              </div>

              {/* Details */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-1.5">
                  <MdBadge className="text-slate-400 text-sm flex-shrink-0" />
                  <span className="text-xs text-slate-500 truncate">{user.email}</span>
                </div>
                <div className={`flex items-center gap-2 rounded-lg px-3 py-1.5 ${
                  user.role === 'admin' ? 'bg-blue-50' : 'bg-emerald-50'
                }`}>
                  <MdShield className={`text-sm flex-shrink-0 ${user.role === 'admin' ? 'text-blue-400' : 'text-emerald-400'}`} />
                  <span className={`text-xs font-semibold uppercase tracking-wide ${
                    user.role === 'admin' ? 'text-blue-600' : 'text-emerald-600'
                  }`}>
                    {user.role === 'admin' ? 'Admin Access' : 'Seller Access'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
