import React, { useState, useEffect } from 'react';
import { getReportData, downloadBillingReport } from '../../../services/reportService';
import {
  MdAssessment, MdFileDownload, MdTrendingUp, MdAccountBalance,
  MdCheckCircle, MdPending, MdReceipt
} from 'react-icons/md';

const PERIODS = ['daily', 'weekly', 'monthly', 'yearly'];

export default function ReportsPage() {
  const [type, setType]       = useState('daily');
  const [data, setData]       = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getReportData(type).then(r => { setData(r); setLoading(false); });
  }, [type]);

  const approved = data.filter(b => b.status === 'approved');
  const pending  = data.filter(b => b.status === 'pending');
  const revenue  = approved.reduce((s, b) => s + b.totalAmount, 0);
  const pendingAmt = pending.reduce((s, b) => s + b.totalAmount, 0);
  const maxAmt   = Math.max(...data.map(b => b.totalAmount || 0), 1);

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-5">

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports</h1>
          <p className="text-sm text-slate-500 mt-0.5">Revenue & billing analysis</p>
        </div>
        {/* Period toggle */}
        <div className="flex p-1 bg-slate-100 rounded-xl gap-1">
          {PERIODS.map(t => (
            <button
              key={t}
              onClick={() => setType(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition ${
                type === t ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { label: 'Revenue',      value: `₹${revenue.toLocaleString()}`,    icon: MdTrendingUp,   cls: 'text-emerald-600', bg: 'bg-emerald-50', sub: `${approved.length} approved` },
          { label: 'Pending',      value: `₹${pendingAmt.toLocaleString()}`, icon: MdPending,      cls: 'text-amber-600',   bg: 'bg-amber-50',   sub: `${pending.length} bills` },
          { label: 'Transactions', value: data.length,                       icon: MdReceipt,      cls: 'text-blue-700',    bg: 'bg-blue-50',    sub: `In ${type} window` },
        ].map(({ label, value, icon: Icon, cls, bg, sub }) => (
          <div key={label} className="bg-white rounded-xl border border-slate-200 p-4 flex items-start gap-3 hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${bg}`}>
              <Icon className={`text-xl ${cls}`} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{label}</p>
              <p className={`text-2xl font-bold mt-0.5 leading-tight ${cls}`}>{value}</p>
              <p className="text-xs text-slate-400 mt-0.5">{sub}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Main Content ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
              <MdAssessment className="text-blue-600" /> Settlement Distribution
            </h3>
            <button
              onClick={() => downloadBillingReport('pdf')}
              className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition"
            >
              <MdFileDownload className="text-base" /> Export PDF
            </button>
          </div>

          <div className="p-4">
            {loading ? (
              <div className="flex justify-center py-10">
                <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : data.length === 0 ? (
              <div className="text-center py-10">
                <MdAssessment className="text-4xl text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-400">No data for this period</p>
              </div>
            ) : (
              <div className="space-y-3">
                {data.slice(0, 8).map(bill => (
                  <div key={bill.id}>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${bill.status === 'approved' ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                        <span className="font-medium text-slate-600 truncate max-w-[150px]">
                          {bill.customerName || 'Walk-in'}
                        </span>
                      </div>
                      <span className="font-bold text-slate-700 flex-shrink-0 ml-2">
                        ₹{bill.totalAmount?.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${bill.status === 'approved' ? 'bg-emerald-500' : 'bg-amber-400'}`}
                        style={{ width: `${Math.min((bill.totalAmount / maxAmt) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
                {data.length > 8 && (
                  <p className="text-xs text-slate-400 text-center pt-1">+{data.length - 8} more transactions</p>
                )}
              </div>
            )}
          </div>

          {/* Legend */}
          <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-xs text-slate-500">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Approved
            </span>
            <span className="flex items-center gap-1.5 text-xs text-slate-500">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> Pending
            </span>
          </div>
        </div>

        {/* Summary card */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl p-5 text-white flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 bg-white/15 rounded-xl flex items-center justify-center mb-4">
              <MdAccountBalance className="text-xl" />
            </div>
            <h3 className="font-bold text-lg">Revenue Summary</h3>
            <p className="text-blue-200 text-sm mt-1">{data.length} transactions · {type}</p>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <p className="text-blue-300 text-xs uppercase tracking-wide mb-1">Net Revenue</p>
              <p className="text-3xl font-bold">₹{revenue.toLocaleString()}</p>
            </div>

            <div className="space-y-2">
              {[
                { label: 'Approved', count: approved.length, cls: 'text-emerald-300' },
                { label: 'Pending',  count: pending.length,  cls: 'text-amber-300' },
              ].map(({ label, count, cls }) => (
                <div key={label} className="flex justify-between text-sm">
                  <span className="text-blue-200">{label}</span>
                  <span className={`font-bold ${cls}`}>{count}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => downloadBillingReport('xlsx')}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-white/15 hover:bg-white/25 border border-white/30 text-white text-xs font-semibold rounded-xl transition"
            >
              <MdFileDownload className="text-base" /> Export Excel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
