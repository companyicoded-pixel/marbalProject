import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { register } from '../../services/authService';
import toast from 'react-hot-toast';
import { MdEmail, MdLock, MdPerson, MdStorefront } from 'react-icons/md';

export default function Register() {
  const [name, setName]         = useState('');
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(email, password, 'seller', name);
      toast.success('Account created!');
      navigate('/login');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ label, icon: Icon, ...props }) => (
    <div>
      <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">{label}</label>
      <div className="relative">
        <Icon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-lg" />
        <input
          {...props}
          className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition placeholder:text-slate-400"
        />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-sm animate-slide-up">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-blue-600 rounded-2xl shadow-lg shadow-blue-200 mb-3">
            <MdStorefront className="text-white text-3xl" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Marble Pro</h1>
          <p className="text-sm text-slate-500 mt-1">Billing & Inventory System</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/60 border border-slate-100 p-6">
          <h2 className="text-lg font-bold text-slate-800 mb-1">Create Account</h2>
          <p className="text-sm text-slate-500 mb-5">Register as a seller</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field label="Full Name" icon={MdPerson} type="text" required placeholder="John Doe" value={name} onChange={e => setName(e.target.value)} />
            <Field label="Email" icon={MdEmail} type="email" required placeholder="you@company.com" value={email} onChange={e => setEmail(e.target.value)} />
            <Field label="Password" icon={MdLock} type="password" required placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />

            <button
              type="submit" disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-semibold rounded-xl shadow-md shadow-blue-200 transition disabled:opacity-50 mt-2"
            >
              {loading && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
              {loading ? 'Creating…' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-5">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-600 font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
