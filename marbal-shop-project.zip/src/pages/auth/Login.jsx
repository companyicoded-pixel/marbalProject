import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../../services/authService';
import toast from 'react-hot-toast';
import {
  MdEmail, MdLock, MdLogin, MdStorefront,
  MdVisibility, MdVisibilityOff, MdInventory, MdReceipt, MdAssessment, MdPeople
} from 'react-icons/md';

const FEATURES = [
  { icon: MdInventory,  text: 'Real-time inventory tracking' },
  { icon: MdReceipt,    text: 'Instant billing & invoicing' },
  { icon: MdAssessment, text: 'Detailed reports & analytics' },
  { icon: MdPeople,     text: 'Multi-user role management' },
];

export default function Login() {
  const [email,        setEmail]        = useState('');
  const [password,     setPassword]     = useState('');
  const [loading,      setLoading]      = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) { toast.error('Please fill in all fields'); return; }
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-100">

      {/* ── Left branding panel ── */}
      <div className="hidden lg:flex w-5/12 xl:w-2/5 flex-col justify-between p-10 bg-gradient-to-br from-[#1e2a4a] via-blue-700 to-violet-700 text-white relative overflow-hidden flex-shrink-0">
        {/* Decorative blobs */}
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 right-8 w-40 h-40 bg-white/5 rounded-full blur-2xl" />

        {/* Logo */}
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center border border-white/30 flex-shrink-0">
              <MdStorefront className="text-white text-2xl" />
            </div>
            <div>
              <h1 className="text-xl font-bold leading-tight">Marble Pro</h1>
              <p className="text-blue-200 text-xs">Inventory Management</p>
            </div>
          </div>

          <h2 className="text-3xl xl:text-4xl font-bold leading-tight mb-4">
            Manage your store<br />smarter & faster
          </h2>
          <p className="text-blue-200 text-sm leading-relaxed max-w-xs">
            Complete billing, inventory, and reporting solution for your marble & stone business.
          </p>
        </div>

        {/* Features */}
        <div className="relative z-10 space-y-3">
          {FEATURES.map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/15 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="text-white text-base" />
              </div>
              <span className="text-sm text-blue-100">{text}</span>
            </div>
          ))}
        </div>

        <p className="relative z-10 text-blue-300/70 text-xs">© 2025 Marble Pro. All rights reserved.</p>
      </div>

      {/* ── Right form panel ── */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10 bg-slate-100">
        <div className="w-full max-w-md animate-slide-up">

          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg bg-gradient-to-br from-blue-600 to-violet-600">
              <MdStorefront className="text-white text-2xl" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Marble Pro</h1>
              <p className="text-slate-500 text-xs">Inventory Management</p>
            </div>
          </div>

          {/* Card */}
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
            {/* Card top accent */}
            <div className="h-1.5 bg-gradient-to-r from-blue-600 via-violet-600 to-purple-600" />

            <div className="p-8">
              <div className="mb-7">
                <h2 className="text-2xl font-bold text-slate-900">Welcome back</h2>
                <p className="text-slate-500 text-sm mt-1">Sign in to your account to continue</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">

                {/* Email */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5 uppercase tracking-wider">
                    Email Address
                  </label>
                  <div className="relative group">
                    <MdEmail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-lg group-focus-within:text-blue-600 transition-colors" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="w-full pl-11 pr-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all placeholder:text-slate-400"
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5 uppercase tracking-wider">
                    Password
                  </label>
                  <div className="relative group">
                    <MdLock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-lg group-focus-within:text-blue-600 transition-colors" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-11 pr-12 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all placeholder:text-slate-400"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors p-0.5"
                    >
                      {showPassword
                        ? <MdVisibilityOff className="text-lg" />
                        : <MdVisibility className="text-lg" />}
                    </button>
                  </div>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full flex items-center justify-center gap-2 py-3 text-white text-sm font-bold rounded-xl shadow-lg shadow-blue-200 transition-all active:scale-95 mt-2 ${
                    loading
                      ? 'bg-blue-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700'
                  }`}
                >
                  {loading ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Signing in…
                    </>
                  ) : (
                    <>
                      <MdLogin className="text-lg" />
                      Sign In
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 pt-5 border-t border-slate-100 text-center">
                <p className="text-sm text-slate-500">
                  New to Marble Pro?{' '}
                  <Link to="/register" className="font-bold text-blue-600 hover:text-violet-600 transition-colors">
                    Create account
                  </Link>
                </p>
              </div>
            </div>
          </div>

          <p className="text-center text-slate-400 text-xs mt-6">
            Secure login · All data encrypted
          </p>
        </div>
      </div>
    </div>
  );
}
